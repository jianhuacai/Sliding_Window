`timescale 1ns / 1ps

// ==========================================
// Layer 2 核心運算模組
// ==========================================
module Layer2 (
    input  wire        clk,
    input  wire        reset,
    input  wire        calc_start,

    // 📦 讀取特徵圖 (Inter_BRAM) - 接收 Layer 1 結果
    output wire [31:0] in_bram_addr,
    input  wire [31:0] in_bram_dout,
    output wire [3:0]  in_bram_we,
    
    // 📦 寫入結果 (Shared_Image_BRAM) - 覆寫原圖
    output wire [31:0] out_bram_addr,
    output wire [31:0] out_bram_din,
    output wire [3:0]  out_bram_we,

    output wire        calc_done
);

    // ==========================================
    // 📐 硬體參數與跨距設定 (HWC 排列)
    // ==========================================
    localparam IMG_W  = 62; // 輸入尺寸 62x62
    localparam OUT_W  = 30; // 輸出尺寸 30x30
    localparam IN_CH  = 16;
    localparam OUT_CH = 32;

    // 🌟 跨距計算 (1 個像素包含 16 個 32-bit 通道 = 64 Bytes)
    // 💡 註：這裡假設你的 Inter_BRAM 每個 Address 依然是跳 4 Bytes (32-bit 寬度)
    localparam PIXEL_BYTES   = IN_CH * 4;                 // 64 Bytes
    localparam ROW_BYTES     = IMG_W * PIXEL_BYTES;       // 62 * 64 = 3968 Bytes
    localparam WIN_NEXT_ROW  = ROW_BYTES - (3 * PIXEL_BYTES); // 換行退回
    localparam POOL_STRIDE_X = 2 * PIXEL_BYTES;           // Stride = 2    
    localparam POOL_STRIDE_Y = 2 * ROW_BYTES;             // Stride = 2

    // ==========================================
    // ⚙️ 狀態機定義 (加入累加與管線化狀態)
    // ==========================================
    localparam IDLE        = 4'd0,
               IMG_READ    = 4'd1,  
               READ_WAIT   = 4'd2,
               CONV_START  = 4'd3,  
               CONV_WAIT   = 4'd4,  
               ACCUM       = 4'd5,  // 累加 16 個通道
               NEXT_IN_CH  = 4'd6,  // 切換讀取下一個輸入通道
               POOL_STG1   = 4'd7,  // ReLU + 找兩兩最大值
               POOL_STG2   = 4'd8,  // 找最終最大值 (切斷 Critical Path)
               SCALE_STG   = 4'd9,  // 乘上 Scale 並右移 (切斷 Critical Path)
               BRAM_WRITE  = 4'd10, // 寫入 BRAM
               NEXT_OUT_CH = 4'd11, // 切換下一個輸出通道
               NEXT_WIN    = 4'd12, // 空間視窗滑動
               DONE        = 4'd13;

    reg [3:0] state, next_state;

    reg [5:0] col_cnt, row_cnt; 
    reg [4:0] out_ch_cnt; // 0~31
    reg [4:0] in_ch_cnt;  // 0~15
    reg [4:0] re_count;   // 0~15 (讀取 4x4 像素)
    
    reg [31:0] win_base_ptr;  
    reg [31:0] row_start_ptr; 
    reg [31:0] read_ptr_byte;
    reg [31:0] write_ptr_byte;

    // 資料暫存區
    reg  [7:0]  img_buf [0:15]; 
    reg signed [31:0] acc_res [0:3];  

    assign calc_done = (state == DONE);
    
    // BRAM 控制訊號
    assign in_bram_we    = 4'b0000; // 永遠只讀
    assign in_bram_addr  = read_ptr_byte;
    
    assign out_bram_we   = (state == BRAM_WRITE) ? 4'b1111 : 4'b0000;
    assign out_bram_addr = write_ptr_byte;
    assign out_bram_din  = out_data;

    reg  [7:0] ch_scale;
    always @(*) begin
        case(out_ch_cnt)
            5'd0:  ch_scale = 8'd244;
            5'd1:  ch_scale = 8'd121;
            5'd2:  ch_scale = 8'd191;
            5'd3:  ch_scale = 8'd120;
            5'd4:  ch_scale = 8'd135;
            5'd5:  ch_scale = 8'd122;
            5'd6:  ch_scale = 8'd62;
            5'd7:  ch_scale = 8'd149;
            5'd8:  ch_scale = 8'd77;
            5'd9:  ch_scale = 8'd56;
            5'd10: ch_scale = 8'd141;
            5'd11: ch_scale = 8'd112;
            5'd12: ch_scale = 8'd230;
            5'd13: ch_scale = 8'd148;
            5'd14: ch_scale = 8'd86;
            5'd15: ch_scale = 8'd105;
            5'd16: ch_scale = 8'd138;
            5'd17: ch_scale = 8'd123;
            5'd18: ch_scale = 8'd256;
            5'd19: ch_scale = 8'd118;
            5'd20: ch_scale = 8'd70;
            5'd21: ch_scale = 8'd116;
            5'd22: ch_scale = 8'd206;
            5'd23: ch_scale = 8'd188;
            5'd24: ch_scale = 8'd136;
            5'd25: ch_scale = 8'd274;
            5'd26: ch_scale = 8'd88;
            5'd27: ch_scale = 8'd226;
            5'd28: ch_scale = 8'd95;
            5'd29: ch_scale = 8'd97;
            5'd30: ch_scale = 8'd57;
            5'd31: ch_scale = 8'd101;
            default: ch_scale = 8'd0; // 測試用
        endcase
    end

    // ==========================================
    // ⚔️ 2. 例化 4 個 L2 卷積模組 (共用權重)
    // ==========================================
    wire signed [31:0] conv_res [0:3];
    wire [3:0]  conv_dones;
    wire        start_conv = (state == CONV_START);

    conv window1 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[0]), .p1(img_buf[1]), .p2(img_buf[2]), .p3(img_buf[4]), .p4(img_buf[5]), .p5(img_buf[6]), .p6(img_buf[8]), .p7(img_buf[9]), .p8(img_buf[10]), .result(conv_res[0]), .done(conv_dones[0]));
    conv window2 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[1]), .p1(img_buf[2]), .p2(img_buf[3]), .p3(img_buf[5]), .p4(img_buf[6]), .p5(img_buf[7]), .p6(img_buf[9]), .p7(img_buf[10]), .p8(img_buf[11]), .result(conv_res[1]), .done(conv_dones[1]));
    conv window3 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[4]), .p1(img_buf[5]), .p2(img_buf[6]), .p3(img_buf[8]), .p4(img_buf[9]), .p5(img_buf[10]), .p6(img_buf[12]), .p7(img_buf[13]), .p8(img_buf[14]), .result(conv_res[2]), .done(conv_dones[2]));
    conv window4 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[5]), .p1(img_buf[6]), .p2(img_buf[7]), .p3(img_buf[9]), .p4(img_buf[10]), .p5(img_buf[11]), .p6(img_buf[13]), .p7(img_buf[14]), .p8(img_buf[15]), .result(conv_res[3]), .done(conv_dones[3]));

    // ==========================================
    // ⚙️ 3. 狀態機控制
    // ==========================================
    always @(posedge clk or negedge reset) begin
        if(!reset) state <= IDLE;
        else       state <= next_state;
    end

    always @(*) begin
        case(state)
            IDLE:        next_state = (calc_start) ? IMG_READ : IDLE;
            IMG_READ:    next_state = (re_count == 15) ? READ_WAIT : IMG_READ; 
            READ_WAIT:   next_state = CONV_START; // 這個狀態主要是為了確保資料已經穩定在 img_buf 中
            CONV_START:  next_state = CONV_WAIT;
            CONV_WAIT:   next_state = (&conv_dones) ? ACCUM : CONV_WAIT;
            ACCUM:       next_state = NEXT_IN_CH;
            NEXT_IN_CH:  next_state = (in_ch_cnt == IN_CH - 1) ? POOL_STG1 : IMG_READ; 
            POOL_STG1:   next_state = POOL_STG2;   
            POOL_STG2:   next_state = SCALE_STG;   
            SCALE_STG:   next_state = BRAM_WRITE;  
            BRAM_WRITE:  next_state = NEXT_OUT_CH; 
            NEXT_OUT_CH: next_state = (out_ch_cnt == OUT_CH - 1) ? NEXT_WIN : IMG_READ;
            NEXT_WIN:    next_state = (col_cnt == OUT_W-1 && row_cnt == OUT_W-1) ? DONE : IMG_READ;
            DONE:        next_state = IDLE; // 等待頂層重置
            default:     next_state = IDLE;
        endcase
    end

    // ==========================================
    // 🧮 4. 記憶體指標與 BRAM 讀取捕捉
    // ==========================================
    reg [4:0] cap_idx;
    reg       cap_img_en;

    always @(posedge clk or negedge reset) begin
        if(!reset) begin
            read_ptr_byte <= 0; write_ptr_byte <= 0; 
            re_count <= 0; col_cnt <= 0; row_cnt <= 0; 
            out_ch_cnt <= 0; in_ch_cnt <= 0;
            win_base_ptr <= 0; row_start_ptr <= 0;
            cap_idx <= 0; cap_img_en <= 0;
            acc_res[0] <= 0; acc_res[1] <= 0; acc_res[2] <= 0; acc_res[3] <= 0;
        end else begin
            cap_idx    <= re_count;
            cap_img_en <= (state == IMG_READ);
            if (cap_img_en) img_buf[cap_idx] <= in_bram_dout[7:0]; 

            case(state)
                IDLE: begin
                    re_count <= 0; col_cnt <= 0; row_cnt <= 0; 
                    out_ch_cnt <= 0; in_ch_cnt <= 0;
                    win_base_ptr   <= 0; 
                    row_start_ptr  <= 0;
                    read_ptr_byte  <= 0;
                    write_ptr_byte <= 0;
                end

                IMG_READ: begin
                    if (re_count == 15) re_count <= 0;
                    else begin
                        re_count <= re_count + 1;
                        if ((re_count & 2'b11) == 2'b11) 
                             read_ptr_byte <= read_ptr_byte + WIN_NEXT_ROW; 
                        else read_ptr_byte <= read_ptr_byte + PIXEL_BYTES;
                    end
                end

                ACCUM: begin
                    acc_res[0] <= acc_res[0] + conv_res[0];
                    acc_res[1] <= acc_res[1] + conv_res[1];
                    acc_res[2] <= acc_res[2] + conv_res[2];
                    acc_res[3] <= acc_res[3] + conv_res[3];
                end

                NEXT_IN_CH: begin
                    if (in_ch_cnt != IN_CH - 1) begin
                        in_ch_cnt <= in_ch_cnt + 1;
                        read_ptr_byte <= win_base_ptr + ((in_ch_cnt + 1) * 4);
                    end
                end

                NEXT_OUT_CH: begin
                    write_ptr_byte <= write_ptr_byte + 4; 
                    in_ch_cnt <= 0; 
                    
                    acc_res[0] <= 0; acc_res[1] <= 0; acc_res[2] <= 0; acc_res[3] <= 0;

                    if (out_ch_cnt == OUT_CH - 1) out_ch_cnt <= 0;
                    else begin 
                        out_ch_cnt <= out_ch_cnt + 1;
                        read_ptr_byte <= win_base_ptr; 
                    end
                end

                NEXT_WIN: begin
                    if (col_cnt == OUT_W - 1) begin
                        col_cnt <= 0;
                        row_cnt <= row_cnt + 1;
                        row_start_ptr <= row_start_ptr + POOL_STRIDE_Y;
                        win_base_ptr  <= row_start_ptr + POOL_STRIDE_Y;
                        read_ptr_byte <= row_start_ptr + POOL_STRIDE_Y;
                    end else begin
                        col_cnt <= col_cnt + 1;
                        win_base_ptr  <= win_base_ptr + POOL_STRIDE_X;
                        read_ptr_byte <= win_base_ptr + POOL_STRIDE_X;
                    end
                end
            endcase
        end
    end

    // ==========================================
    // 🏆 5. Pipelined: ReLU, Max Pooling 與 Scale
    // ==========================================
    reg  [31:0] pair_data1, pair_data2;     
    reg  [31:0] current_max_reg;            
    reg  [31:0] out_data;


// 用最高位 (MSB) 判斷：如果是 1 (負數) 就給 0，如果是 0 (正數) 就保留原值
    wire  [31:0] relu_0 = acc_res[0][31] ? 32'd0 : acc_res[0]; 
    wire  [31:0] relu_1 = acc_res[1][31] ? 32'd0 : acc_res[1]; 
    wire  [31:0] relu_2 = acc_res[2][31] ? 32'd0 : acc_res[2]; 
    wire  [31:0] relu_3 = acc_res[3][31] ? 32'd0 : acc_res[3];


    (* use_dsp = "yes" *) wire [39:0] scaled_result = current_max_reg * ch_scale;

    always @(posedge clk) begin
        if(state == POOL_STG1) begin
            pair_data1 <= (relu_0 > relu_1) ? relu_0 : relu_1;
            pair_data2 <= (relu_2 > relu_3) ? relu_2 : relu_3;
        end
        if(state == POOL_STG2) begin
            current_max_reg <= (pair_data1 > pair_data2) ? pair_data1 : pair_data2;
        end
        if(state == SCALE_STG) begin
            out_data <= scaled_result >> 16;
        end
    end


    // ==========================================
    // 🧠 1. 權重與 Scale (純組合邏輯)
    // ==========================================
    reg signed [7:0] w0, w1, w2, w3, w4, w5, w6, w7, w8;
    always @(posedge clk) begin
        case(out_ch_cnt * 16 + in_ch_cnt) 
              0: begin w0<=  35; w1<= -20; w2<= -18; w3<= -14; w4<= -35; w5<= -36; w6<=  19; w7<=  17; w8<= -33; end // OUT:0 IN:0
              1: begin w0<= -39; w1<=  -6; w2<=  32; w3<=   2; w4<= -15; w5<=  12; w6<= -27; w7<= -28; w8<=   9; end // OUT:0 IN:1
              2: begin w0<=  58; w1<=  12; w2<=  -3; w3<=  41; w4<=  80; w5<=  59; w6<=   4; w7<=  81; w8<=  89; end // OUT:0 IN:2
              3: begin w0<=  30; w1<=   9; w2<= -37; w3<=  46; w4<= -11; w5<= -23; w6<=  32; w7<=  -6; w8<=  30; end // OUT:0 IN:3
              4: begin w0<=  62; w1<=  17; w2<=  18; w3<=  48; w4<=   6; w5<= -49; w6<=  91; w7<= 107; w8<=  46; end // OUT:0 IN:4
              5: begin w0<=   5; w1<=  -7; w2<= -27; w3<=  28; w4<=  18; w5<=  22; w6<=  24; w7<=  10; w8<=  16; end // OUT:0 IN:5
              6: begin w0<=  21; w1<= -31; w2<=  -8; w3<=  28; w4<=   3; w5<= -10; w6<=  -8; w7<=  31; w8<=  41; end // OUT:0 IN:6
              7: begin w0<= -18; w1<= -21; w2<=  11; w3<=  -4; w4<= -46; w5<=  28; w6<=  18; w7<= -46; w8<= -38; end // OUT:0 IN:7
              8: begin w0<= -33; w1<=   9; w2<=  28; w3<= -46; w4<=  -8; w5<=  28; w6<= -32; w7<= -38; w8<= -37; end // OUT:0 IN:8
              9: begin w0<= -16; w1<=  -7; w2<=  -7; w3<=  23; w4<=  -4; w5<=  -2; w6<=  42; w7<=  18; w8<=  -8; end // OUT:0 IN:9
             10: begin w0<=  53; w1<=  98; w2<=  -7; w3<= -13; w4<= 127; w5<=  69; w6<= -37; w7<=  32; w8<=  52; end // OUT:0 IN:10
             11: begin w0<= -11; w1<=  66; w2<= -10; w3<=  -3; w4<=  92; w5<=   6; w6<= -31; w7<=  18; w8<=  10; end // OUT:0 IN:11
             12: begin w0<= -51; w1<=  39; w2<=  26; w3<= -17; w4<=  12; w5<=  54; w6<=  -9; w7<=   3; w8<=  26; end // OUT:0 IN:12
             13: begin w0<= -24; w1<=  21; w2<=   6; w3<=  23; w4<=  16; w5<=  33; w6<= -15; w7<=   1; w8<=  21; end // OUT:0 IN:13
             14: begin w0<=  19; w1<=  12; w2<=  -5; w3<= -21; w4<= -14; w5<=   1; w6<=  -3; w7<=   3; w8<= -17; end // OUT:0 IN:14
             15: begin w0<=  26; w1<=  -7; w2<=   5; w3<=  -2; w4<= -23; w5<=   2; w6<=  -2; w7<=  -1; w8<= -23; end // OUT:0 IN:15
             16: begin w0<=  22; w1<= -51; w2<= -61; w3<= -28; w4<= -48; w5<= -35; w6<=  -7; w7<=  31; w8<= -59; end // OUT:1 IN:0
             17: begin w0<= -25; w1<=  40; w2<=  23; w3<=  17; w4<= -28; w5<=   5; w6<= -74; w7<= -68; w8<= -52; end // OUT:1 IN:1
             18: begin w0<=  69; w1<=  43; w2<=  27; w3<=  37; w4<=  55; w5<= -39; w6<= -79; w7<= -21; w8<=  51; end // OUT:1 IN:2
             19: begin w0<=   6; w1<=  24; w2<=  10; w3<=  33; w4<=  30; w5<=  11; w6<= -28; w7<= -63; w8<=  40; end // OUT:1 IN:3
             20: begin w0<=  42; w1<=  12; w2<= -10; w3<= 114; w4<=  69; w5<=  -8; w6<=  73; w7<= 111; w8<=  -2; end // OUT:1 IN:4
             21: begin w0<= -19; w1<=   7; w2<=  39; w3<= -45; w4<=   3; w5<=  21; w6<=   6; w7<=  30; w8<=  15; end // OUT:1 IN:5
             22: begin w0<= -65; w1<=  17; w2<= -81; w3<= -70; w4<=  -9; w5<= -24; w6<=   2; w7<= -69; w8<=  -5; end // OUT:1 IN:6
             23: begin w0<= -19; w1<= -21; w2<= -77; w3<=  49; w4<= -40; w5<= -52; w6<= -58; w7<= -36; w8<=  29; end // OUT:1 IN:7
             24: begin w0<=   3; w1<= -20; w2<=  19; w3<=   4; w4<=   6; w5<=  32; w6<= -71; w7<= -70; w8<=  55; end // OUT:1 IN:8
             25: begin w0<= -50; w1<= -14; w2<= -46; w3<= -31; w4<= -80; w5<= -68; w6<=  31; w7<= -56; w8<=   2; end // OUT:1 IN:9
             26: begin w0<=  62; w1<=  10; w2<= -16; w3<=  20; w4<=  70; w5<=  17; w6<= -87; w7<= -24; w8<= 127; end // OUT:1 IN:10
             27: begin w0<= -44; w1<= -41; w2<= -66; w3<=  -9; w4<= -24; w5<=   8; w6<= -83; w7<= -67; w8<=   1; end // OUT:1 IN:11
             28: begin w0<= -17; w1<= -73; w2<=   8; w3<= -47; w4<= -19; w5<= -20; w6<= -49; w7<= -66; w8<= -68; end // OUT:1 IN:12
             29: begin w0<= -76; w1<= -76; w2<= -55; w3<= -83; w4<=  33; w5<= -30; w6<= -38; w7<= -73; w8<= -82; end // OUT:1 IN:13
             30: begin w0<=  25; w1<= -24; w2<= -41; w3<= -21; w4<=  21; w5<=  51; w6<=  17; w7<=   6; w8<=  -2; end // OUT:1 IN:14
             31: begin w0<=  38; w1<=  26; w2<=  30; w3<= -35; w4<=   4; w5<=  28; w6<=  27; w7<= -41; w8<= -14; end // OUT:1 IN:15
             32: begin w0<= -14; w1<= -31; w2<= -42; w3<= -18; w4<= -27; w5<= -22; w6<= -11; w7<=   9; w8<=   9; end // OUT:2 IN:0
             33: begin w0<=  17; w1<=  11; w2<=  23; w3<=  -6; w4<=  46; w5<=  15; w6<=  18; w7<= -50; w8<= -46; end // OUT:2 IN:1
             34: begin w0<=   5; w1<=  45; w2<=  59; w3<=  56; w4<=  86; w5<=  53; w6<= -37; w7<= -39; w8<= -37; end // OUT:2 IN:2
             35: begin w0<= -21; w1<= -13; w2<= -15; w3<=  -7; w4<=  27; w5<=  34; w6<=  23; w7<=   1; w8<= -30; end // OUT:2 IN:3
             36: begin w0<=  36; w1<=  26; w2<= -10; w3<=  18; w4<=  65; w5<=   7; w6<=  -9; w7<= -21; w8<= -10; end // OUT:2 IN:4
             37: begin w0<=  30; w1<= -15; w2<=   7; w3<= -38; w4<=  -2; w5<=  -2; w6<=  31; w7<= -37; w8<=  -2; end // OUT:2 IN:5
             38: begin w0<=  37; w1<=  40; w2<=  34; w3<= -15; w4<= -30; w5<=  17; w6<= -21; w7<=  32; w8<=  -7; end // OUT:2 IN:6
             39: begin w0<= -20; w1<=  33; w2<=  39; w3<= -42; w4<=  34; w5<=   6; w6<=  -3; w7<=  -5; w8<=  18; end // OUT:2 IN:7
             40: begin w0<=  23; w1<=   2; w2<=   9; w3<= -29; w4<= -42; w5<= -48; w6<= -23; w7<= -34; w8<= -38; end // OUT:2 IN:8
             41: begin w0<= -61; w1<=   7; w2<=  14; w3<=  17; w4<=  21; w5<=  16; w6<= -16; w7<=  10; w8<=  16; end // OUT:2 IN:9
             42: begin w0<=  18; w1<=  38; w2<=  19; w3<=  32; w4<=  94; w5<=  84; w6<=   0; w7<= -38; w8<= -21; end // OUT:2 IN:10
             43: begin w0<=  50; w1<=  36; w2<=  48; w3<=  52; w4<=  -4; w5<=   7; w6<=  12; w7<= -40; w8<=  49; end // OUT:2 IN:11
             44: begin w0<=  -7; w1<= 123; w2<=  99; w3<=  27; w4<= 123; w5<= 127; w6<=  75; w7<=  88; w8<=  80; end // OUT:2 IN:12
             45: begin w0<= -30; w1<=  18; w2<=  21; w3<=  28; w4<=  31; w5<=   9; w6<= -12; w7<= -37; w8<=  -1; end // OUT:2 IN:13
             46: begin w0<=  -4; w1<=  -1; w2<=  -5; w3<=  21; w4<=  11; w5<= -13; w6<=  11; w7<=   1; w8<= -32; end // OUT:2 IN:14
             47: begin w0<= -27; w1<=  -8; w2<= -37; w3<= -32; w4<=  33; w5<= -33; w6<=  -9; w7<= -37; w8<=   7; end // OUT:2 IN:15
             48: begin w0<=   7; w1<=  22; w2<=  30; w3<=  19; w4<=  39; w5<= -36; w6<= -58; w7<= -53; w8<=  17; end // OUT:3 IN:0
             49: begin w0<= -45; w1<=  41; w2<= -93; w3<= -71; w4<= -36; w5<=  16; w6<=  31; w7<=  60; w8<= -28; end // OUT:3 IN:1
             50: begin w0<=  15; w1<=  81; w2<= -48; w3<=  -6; w4<= -28; w5<= -34; w6<=   0; w7<=  49; w8<= -18; end // OUT:3 IN:2
             51: begin w0<=  42; w1<=  11; w2<= -68; w3<=  54; w4<= -33; w5<=  30; w6<=   0; w7<= -47; w8<= -47; end // OUT:3 IN:3
             52: begin w0<=   0; w1<= 112; w2<=  63; w3<= -14; w4<=  30; w5<=  41; w6<= -42; w7<= -13; w8<=   2; end // OUT:3 IN:4
             53: begin w0<= -36; w1<=  33; w2<= -14; w3<=  39; w4<= -38; w5<= -26; w6<= -48; w7<=  -2; w8<=  59; end // OUT:3 IN:5
             54: begin w0<= -54; w1<= -50; w2<= -32; w3<=  49; w4<=  -6; w5<= -31; w6<=  13; w7<= -65; w8<= -85; end // OUT:3 IN:6
             55: begin w0<=  30; w1<=  51; w2<= -23; w3<=  68; w4<=  40; w5<=  51; w6<= -57; w7<=  42; w8<=  67; end // OUT:3 IN:7
             56: begin w0<= -55; w1<= -52; w2<= -55; w3<=  -2; w4<=  60; w5<=  15; w6<=  50; w7<= 105; w8<=   4; end // OUT:3 IN:8
             57: begin w0<= -66; w1<=  19; w2<= -50; w3<= -44; w4<=  57; w5<=  33; w6<= -47; w7<=  33; w8<=  35; end // OUT:3 IN:9
             58: begin w0<=  83; w1<=  90; w2<=  -5; w3<= 127; w4<=  75; w5<= -76; w6<=  63; w7<= -10; w8<=  81; end // OUT:3 IN:10
             59: begin w0<= -30; w1<=  33; w2<=-106; w3<=  79; w4<=  23; w5<=-107; w6<= -34; w7<=  60; w8<=  -8; end // OUT:3 IN:11
             60: begin w0<=  11; w1<=  28; w2<=  20; w3<= -45; w4<=  53; w5<=  17; w6<= -24; w7<=  60; w8<=  53; end // OUT:3 IN:12
             61: begin w0<= -27; w1<=  31; w2<=  27; w3<=  13; w4<=  41; w5<=  32; w6<=  17; w7<=   8; w8<=  47; end // OUT:3 IN:13
             62: begin w0<=  58; w1<=  18; w2<= -50; w3<=  60; w4<= -46; w5<=  52; w6<=  54; w7<= -42; w8<=  58; end // OUT:3 IN:14
             63: begin w0<= -41; w1<=  53; w2<= -54; w3<= -14; w4<= -48; w5<=  11; w6<= -18; w7<= -54; w8<=  -5; end // OUT:3 IN:15
             64: begin w0<=  98; w1<=  80; w2<=  -7; w3<= -27; w4<=  75; w5<=  47; w6<= -77; w7<= -60; w8<= -85; end // OUT:4 IN:0
             65: begin w0<= -95; w1<=-111; w2<= -50; w3<=   3; w4<= -20; w5<=   8; w6<=  47; w7<=  -1; w8<= -29; end // OUT:4 IN:1
             66: begin w0<= -70; w1<= -30; w2<= -47; w3<= -99; w4<= -54; w5<= -54; w6<=  61; w7<=  50; w8<=  41; end // OUT:4 IN:2
             67: begin w0<=  17; w1<=  11; w2<=  51; w3<= -73; w4<=   7; w5<=  25; w6<= -57; w7<= -86; w8<=  21; end // OUT:4 IN:3
             68: begin w0<= -12; w1<= 127; w2<=  11; w3<= -19; w4<= -31; w5<=  19; w6<=  44; w7<= -85; w8<= -21; end // OUT:4 IN:4
             69: begin w0<=  50; w1<=   4; w2<= -14; w3<= -41; w4<=  -2; w5<=  -5; w6<= -52; w7<= -17; w8<=  15; end // OUT:4 IN:5
             70: begin w0<= -33; w1<=  -6; w2<= -57; w3<=  30; w4<= -19; w5<= -12; w6<=  19; w7<=  60; w8<= -25; end // OUT:4 IN:6
             71: begin w0<=  80; w1<= -28; w2<=  31; w3<=  15; w4<=  55; w5<= -16; w6<= -74; w7<=  -2; w8<=-101; end // OUT:4 IN:7
             72: begin w0<= -69; w1<= -73; w2<= -38; w3<=  59; w4<=  46; w5<=  30; w6<=  71; w7<=  80; w8<=  87; end // OUT:4 IN:8
             73: begin w0<=  95; w1<=  52; w2<=  86; w3<= -50; w4<= -16; w5<= -63; w6<= -35; w7<= -52; w8<= -75; end // OUT:4 IN:9
             74: begin w0<= -18; w1<= -13; w2<=   6; w3<=   6; w4<=  21; w5<= -21; w6<= -40; w7<= -43; w8<=  65; end // OUT:4 IN:10
             75: begin w0<=  15; w1<= -11; w2<= -39; w3<= -27; w4<=  -6; w5<= -14; w6<= -41; w7<=  44; w8<=  13; end // OUT:4 IN:11
             76: begin w0<=  73; w1<= -62; w2<=   9; w3<=  26; w4<=  22; w5<= -67; w6<= -36; w7<=  17; w8<= -69; end // OUT:4 IN:12
             77: begin w0<=  20; w1<=  -4; w2<=  10; w3<= -10; w4<=  32; w5<= -22; w6<=  36; w7<=  28; w8<= -15; end // OUT:4 IN:13
             78: begin w0<=   0; w1<=   8; w2<= -37; w3<=  28; w4<=  50; w5<=  37; w6<=  22; w7<= -47; w8<=   9; end // OUT:4 IN:14
             79: begin w0<=  38; w1<=  43; w2<=  44; w3<= -36; w4<=  33; w5<=  -4; w6<=   8; w7<=  36; w8<=  16; end // OUT:4 IN:15
             80: begin w0<= 116; w1<=  83; w2<= -20; w3<= -10; w4<= -73; w5<= -62; w6<=  26; w7<= -28; w8<=-115; end // OUT:5 IN:0
             81: begin w0<=  19; w1<= -37; w2<=  41; w3<=   2; w4<=  -2; w5<=  34; w6<= -51; w7<=  22; w8<= -43; end // OUT:5 IN:1
             82: begin w0<=  23; w1<= -29; w2<=  12; w3<= -97; w4<= -81; w5<=  18; w6<= -14; w7<= -28; w8<= -23; end // OUT:5 IN:2
             83: begin w0<=  18; w1<=  38; w2<= -32; w3<= -26; w4<= -54; w5<= -69; w6<= -31; w7<= -36; w8<= -51; end // OUT:5 IN:3
             84: begin w0<= -54; w1<= -37; w2<=-128; w3<=-101; w4<= -57; w5<= -60; w6<= -50; w7<= -52; w8<= -88; end // OUT:5 IN:4
             85: begin w0<=  57; w1<= -25; w2<= -23; w3<=  -1; w4<= -54; w5<=  37; w6<= -24; w7<=  59; w8<=  37; end // OUT:5 IN:5
             86: begin w0<= -22; w1<=  -4; w2<= -44; w3<= -47; w4<=  20; w5<=  55; w6<= -58; w7<=  47; w8<= -60; end // OUT:5 IN:6
             87: begin w0<= -24; w1<= -54; w2<= -45; w3<= -13; w4<=-100; w5<=   3; w6<= -36; w7<= -16; w8<=  12; end // OUT:5 IN:7
             88: begin w0<= -79; w1<= -36; w2<= -28; w3<=  28; w4<= -31; w5<=  54; w6<= -11; w7<= -22; w8<= -44; end // OUT:5 IN:8
             89: begin w0<= -13; w1<= -68; w2<= -82; w3<=  22; w4<= -65; w5<= -53; w6<= -47; w7<= -69; w8<= -54; end // OUT:5 IN:9
             90: begin w0<= -40; w1<=  -3; w2<=  -6; w3<= -84; w4<= -33; w5<= -50; w6<= -51; w7<= -40; w8<= -53; end // OUT:5 IN:10
             91: begin w0<=  25; w1<=  93; w2<= -41; w3<=  54; w4<= -33; w5<=  -4; w6<=  -6; w7<= -29; w8<=  50; end // OUT:5 IN:11
             92: begin w0<=  81; w1<= -22; w2<=  12; w3<=  67; w4<=   9; w5<=  36; w6<=  11; w7<= -53; w8<=-115; end // OUT:5 IN:12
             93: begin w0<=  17; w1<=  42; w2<= -15; w3<=  -9; w4<=  32; w5<= -18; w6<= -34; w7<=  12; w8<=  30; end // OUT:5 IN:13
             94: begin w0<= -58; w1<=  49; w2<= -36; w3<= -55; w4<=  20; w5<=  33; w6<=  41; w7<=  -7; w8<= -35; end // OUT:5 IN:14
             95: begin w0<=  -4; w1<=  18; w2<=  41; w3<=  58; w4<=  52; w5<=   9; w6<=  26; w7<=  50; w8<=   5; end // OUT:5 IN:15
             96: begin w0<=  -6; w1<= -10; w2<=-128; w3<=-119; w4<=  74; w5<=  11; w6<= -50; w7<=  32; w8<=  18; end // OUT:6 IN:0
             97: begin w0<= -85; w1<= -20; w2<=  50; w3<=   9; w4<= -22; w5<=  19; w6<= -85; w7<= -93; w8<= -40; end // OUT:6 IN:1
             98: begin w0<= -84; w1<= -23; w2<= -67; w3<= -99; w4<=  95; w5<= -93; w6<= -44; w7<= -42; w8<=  80; end // OUT:6 IN:2
             99: begin w0<=-105; w1<=   1; w2<=  62; w3<=-121; w4<=  73; w5<=-118; w6<=   4; w7<= -91; w8<= -81; end // OUT:6 IN:3
            100: begin w0<=  90; w1<= -19; w2<= -12; w3<=  38; w4<=  88; w5<=   1; w6<=  89; w7<= -39; w8<= -37; end // OUT:6 IN:4
            101: begin w0<= -45; w1<= -70; w2<=   9; w3<=  58; w4<= -48; w5<=  -1; w6<= -71; w7<=  -2; w8<=  69; end // OUT:6 IN:5
            102: begin w0<=  80; w1<= -11; w2<= -81; w3<= -50; w4<= 106; w5<=-119; w6<=  96; w7<=  28; w8<= -59; end // OUT:6 IN:6
            103: begin w0<= -16; w1<=  39; w2<=  10; w3<=  35; w4<=  32; w5<=-121; w6<=  38; w7<= 112; w8<= -57; end // OUT:6 IN:7
            104: begin w0<= -40; w1<=-112; w2<= -49; w3<= -60; w4<=  47; w5<=  74; w6<= -24; w7<= -66; w8<=  46; end // OUT:6 IN:8
            105: begin w0<=  46; w1<=  76; w2<= -56; w3<= -79; w4<=  57; w5<= -84; w6<=  58; w7<=  53; w8<= -67; end // OUT:6 IN:9
            106: begin w0<=  88; w1<=  77; w2<=  56; w3<= -16; w4<= -47; w5<= -19; w6<=  51; w7<= -74; w8<=  71; end // OUT:6 IN:10
            107: begin w0<=  17; w1<=  82; w2<=  35; w3<=  43; w4<=  37; w5<=  20; w6<=  65; w7<= -96; w8<=  14; end // OUT:6 IN:11
            108: begin w0<=  82; w1<= -64; w2<=  65; w3<= -54; w4<=  31; w5<= -78; w6<= -20; w7<= -13; w8<=  37; end // OUT:6 IN:12
            109: begin w0<= -33; w1<= -84; w2<= -84; w3<=  94; w4<=-122; w5<=  44; w6<=-116; w7<= 111; w8<=  24; end // OUT:6 IN:13
            110: begin w0<=  10; w1<=  75; w2<=  66; w3<= -67; w4<= -82; w5<= -37; w6<=  79; w7<=  68; w8<= -25; end // OUT:6 IN:14
            111: begin w0<= -81; w1<=  59; w2<=  -7; w3<=-104; w4<=  71; w5<=-106; w6<= -50; w7<=  65; w8<= -47; end // OUT:6 IN:15
            112: begin w0<=  -5; w1<=  -5; w2<= -71; w3<=  41; w4<= -34; w5<= -36; w6<=  21; w7<=  19; w8<= -63; end // OUT:7 IN:0
            113: begin w0<= -18; w1<=  33; w2<= -24; w3<=  10; w4<= -46; w5<= -54; w6<=   1; w7<=  16; w8<= -33; end // OUT:7 IN:1
            114: begin w0<=  46; w1<=  55; w2<=  53; w3<= -52; w4<= -27; w5<=  20; w6<= -30; w7<= -21; w8<=   9; end // OUT:7 IN:2
            115: begin w0<=   3; w1<=  -4; w2<= -27; w3<= -26; w4<=  47; w5<=  -4; w6<=  40; w7<= -58; w8<= -28; end // OUT:7 IN:3
            116: begin w0<= 127; w1<=  91; w2<=  -4; w3<= 112; w4<=  96; w5<=  45; w6<= -28; w7<=  28; w8<=  14; end // OUT:7 IN:4
            117: begin w0<= -32; w1<= -46; w2<= -35; w3<= -29; w4<= -17; w5<= -31; w6<= -30; w7<= -10; w8<=  11; end // OUT:7 IN:5
            118: begin w0<=  35; w1<= -50; w2<= -30; w3<= -53; w4<=  17; w5<=  -8; w6<=  33; w7<=  -6; w8<=  30; end // OUT:7 IN:6
            119: begin w0<=  53; w1<=  20; w2<=  -4; w3<=  54; w4<=  36; w5<= -47; w6<=  50; w7<= -18; w8<= -20; end // OUT:7 IN:7
            120: begin w0<= -15; w1<= -18; w2<=   3; w3<= -52; w4<= -10; w5<=  34; w6<=  19; w7<= -33; w8<= -42; end // OUT:7 IN:8
            121: begin w0<=   1; w1<=  -2; w2<=   1; w3<=  24; w4<= -25; w5<= -54; w6<= -57; w7<= -33; w8<=   0; end // OUT:7 IN:9
            122: begin w0<=  76; w1<=  93; w2<=  49; w3<=  -2; w4<=  70; w5<=  37; w6<=  79; w7<=  30; w8<= -13; end // OUT:7 IN:10
            123: begin w0<= -41; w1<=  -7; w2<=  42; w3<=  48; w4<=  25; w5<=  54; w6<=  68; w7<= -21; w8<=  -3; end // OUT:7 IN:11
            124: begin w0<=   2; w1<=  53; w2<=  48; w3<= -14; w4<=  11; w5<= -24; w6<=  26; w7<= -54; w8<= -18; end // OUT:7 IN:12
            125: begin w0<= -12; w1<= -58; w2<=   0; w3<= -22; w4<= -70; w5<=  17; w6<=  -1; w7<=  19; w8<=   3; end // OUT:7 IN:13
            126: begin w0<= -47; w1<=  36; w2<=  -1; w3<=  31; w4<= -46; w5<=  14; w6<=  46; w7<=   5; w8<=  11; end // OUT:7 IN:14
            127: begin w0<=   5; w1<=  16; w2<=   9; w3<= -32; w4<= -34; w5<= -15; w6<= -44; w7<=  27; w8<= -31; end // OUT:7 IN:15
            128: begin w0<=   6; w1<= -30; w2<=  31; w3<=  -7; w4<=  30; w5<=   6; w6<= -42; w7<=  14; w8<= -73; end // OUT:8 IN:0
            129: begin w0<= -72; w1<= -18; w2<= -31; w3<=  22; w4<=   6; w5<=  59; w6<= -29; w7<= -47; w8<= -36; end // OUT:8 IN:1
            130: begin w0<=  11; w1<= -48; w2<=  26; w3<= -47; w4<= -58; w5<=   7; w6<= -19; w7<= -53; w8<= -88; end // OUT:8 IN:2
            131: begin w0<=  37; w1<=  37; w2<=  36; w3<=  34; w4<=  29; w5<= -66; w6<= -46; w7<= -18; w8<=  35; end // OUT:8 IN:3
            132: begin w0<=   2; w1<= -84; w2<= -17; w3<=  55; w4<=  28; w5<= -67; w6<=  50; w7<= -11; w8<=  65; end // OUT:8 IN:4
            133: begin w0<=  25; w1<= -36; w2<=  28; w3<= -16; w4<=  21; w5<=  14; w6<=  71; w7<=  39; w8<= -64; end // OUT:8 IN:5
            134: begin w0<= -59; w1<= -54; w2<= -89; w3<=  -3; w4<= -90; w5<= -58; w6<=  45; w7<= -53; w8<=  22; end // OUT:8 IN:6
            135: begin w0<=  59; w1<= -59; w2<= -36; w3<=  34; w4<= -45; w5<=  68; w6<= -16; w7<=  -6; w8<=  69; end // OUT:8 IN:7
            136: begin w0<= -27; w1<= -88; w2<=-103; w3<=  67; w4<= -92; w5<= -53; w6<=  10; w7<=   2; w8<= -87; end // OUT:8 IN:8
            137: begin w0<=  -6; w1<= -43; w2<=-119; w3<=-105; w4<= -95; w5<= -58; w6<=   8; w7<=  24; w8<=   7; end // OUT:8 IN:9
            138: begin w0<=  -5; w1<= -61; w2<= -36; w3<= -76; w4<=  -3; w5<= -63; w6<= -95; w7<=   9; w8<= -86; end // OUT:8 IN:10
            139: begin w0<=  -9; w1<=   0; w2<= -27; w3<=  12; w4<= -55; w5<=-109; w6<= -18; w7<= -80; w8<= -18; end // OUT:8 IN:11
            140: begin w0<=  35; w1<=  66; w2<=  55; w3<= -22; w4<= -86; w5<= -65; w6<=-127; w7<= -61; w8<=-104; end // OUT:8 IN:12
            141: begin w0<=  28; w1<=  36; w2<=  40; w3<=  38; w4<= -18; w5<= -22; w6<=   8; w7<= -18; w8<=  32; end // OUT:8 IN:13
            142: begin w0<= -57; w1<= -43; w2<= -24; w3<=   2; w4<=  -5; w5<= -81; w6<= -81; w7<= -10; w8<= -27; end // OUT:8 IN:14
            143: begin w0<=  19; w1<=  63; w2<= -92; w3<= -31; w4<= -55; w5<=  87; w6<= -26; w7<= -55; w8<=  33; end // OUT:8 IN:15
            144: begin w0<=-115; w1<=  -7; w2<=-120; w3<=-113; w4<= -57; w5<= 118; w6<= 125; w7<=  15; w8<= -25; end // OUT:9 IN:0
            145: begin w0<= -63; w1<= -78; w2<=  43; w3<=-117; w4<= -29; w5<=-114; w6<=-108; w7<= -52; w8<= 107; end // OUT:9 IN:1
            146: begin w0<=  12; w1<= -64; w2<=-126; w3<=-119; w4<=  16; w5<= -63; w6<= -53; w7<=-111; w8<=  26; end // OUT:9 IN:2
            147: begin w0<=-111; w1<=  -8; w2<=  99; w3<=-120; w4<=-114; w5<=  35; w6<=  81; w7<= -79; w8<=  33; end // OUT:9 IN:3
            148: begin w0<=  56; w1<= -37; w2<= -72; w3<= 114; w4<=  20; w5<= -88; w6<=  29; w7<= -76; w8<= -18; end // OUT:9 IN:4
            149: begin w0<= 103; w1<=  45; w2<= 104; w3<= -31; w4<=  77; w5<=  -9; w6<=  87; w7<=  94; w8<= -63; end // OUT:9 IN:5
            150: begin w0<=-108; w1<= -35; w2<=  25; w3<= -35; w4<= -17; w5<=  83; w6<= -58; w7<= -50; w8<= -83; end // OUT:9 IN:6
            151: begin w0<=-108; w1<=  92; w2<= -98; w3<= -49; w4<=  70; w5<=  -5; w6<= -99; w7<= -49; w8<=  47; end // OUT:9 IN:7
            152: begin w0<= -83; w1<=  53; w2<=  34; w3<=   2; w4<= -66; w5<= 104; w6<= -37; w7<=-121; w8<= -45; end // OUT:9 IN:8
            153: begin w0<= -75; w1<=  45; w2<=  41; w3<=   6; w4<=  63; w5<=-117; w6<= -21; w7<=  30; w8<= 109; end // OUT:9 IN:9
            154: begin w0<=  21; w1<=  88; w2<= -68; w3<=  -1; w4<= 103; w5<=  24; w6<= -41; w7<= -26; w8<= 115; end // OUT:9 IN:10
            155: begin w0<=-119; w1<=  23; w2<=  63; w3<=  -7; w4<= -77; w5<= -55; w6<=  48; w7<= -69; w8<=-104; end // OUT:9 IN:11
            156: begin w0<= -87; w1<=-128; w2<= -90; w3<=-113; w4<=  33; w5<=-127; w6<=  10; w7<= -55; w8<= -74; end // OUT:9 IN:12
            157: begin w0<= -94; w1<=-103; w2<= -79; w3<=  64; w4<=  -1; w5<=  28; w6<= -25; w7<=  39; w8<= -86; end // OUT:9 IN:13
            158: begin w0<=  32; w1<=  85; w2<=  37; w3<=-121; w4<=  78; w5<=  52; w6<=-116; w7<= -53; w8<=-108; end // OUT:9 IN:14
            159: begin w0<=  25; w1<=  99; w2<= -14; w3<=  42; w4<=  87; w5<=-112; w6<=   0; w7<= -16; w8<= -55; end // OUT:9 IN:15
            160: begin w0<=  49; w1<=  32; w2<=  52; w3<=  48; w4<= -17; w5<=   1; w6<= -52; w7<=  12; w8<= -83; end // OUT:10 IN:0
            161: begin w0<= -68; w1<= -60; w2<=-106; w3<=   5; w4<= -49; w5<=  27; w6<=  12; w7<=  16; w8<=  11; end // OUT:10 IN:1
            162: begin w0<= -35; w1<= -50; w2<= -57; w3<= -66; w4<= -96; w5<= -92; w6<=-111; w7<=   8; w8<=  29; end // OUT:10 IN:2
            163: begin w0<=  18; w1<= -38; w2<= -41; w3<=  12; w4<=  27; w5<= -65; w6<= -48; w7<= -83; w8<= -75; end // OUT:10 IN:3
            164: begin w0<=  21; w1<= -17; w2<=  12; w3<= -35; w4<= -50; w5<=  -1; w6<= -73; w7<= -14; w8<= -58; end // OUT:10 IN:4
            165: begin w0<= -40; w1<=  19; w2<=  28; w3<= -32; w4<=  -2; w5<= -15; w6<=  34; w7<= -21; w8<=  -8; end // OUT:10 IN:5
            166: begin w0<= -69; w1<= -24; w2<= -85; w3<= -65; w4<=  38; w5<= -34; w6<=   3; w7<=  61; w8<=   2; end // OUT:10 IN:6
            167: begin w0<= -44; w1<=  35; w2<=  12; w3<=  65; w4<=   9; w5<=  59; w6<= -16; w7<= -80; w8<=   2; end // OUT:10 IN:7
            168: begin w0<= -73; w1<= -20; w2<= -26; w3<= -32; w4<= -11; w5<=  -4; w6<=   5; w7<=  -6; w8<=  21; end // OUT:10 IN:8
            169: begin w0<=  46; w1<= -14; w2<=  39; w3<=  16; w4<= -12; w5<= -22; w6<= -89; w7<= -89; w8<= -51; end // OUT:10 IN:9
            170: begin w0<= -18; w1<= -44; w2<= -30; w3<=  36; w4<= -90; w5<=  33; w6<=   4; w7<= -90; w8<=  24; end // OUT:10 IN:10
            171: begin w0<=-112; w1<=-111; w2<= -55; w3<=  69; w4<= 112; w5<=  92; w6<= 127; w7<=  52; w8<=  72; end // OUT:10 IN:11
            172: begin w0<=  11; w1<= -24; w2<= -29; w3<= -27; w4<= -82; w5<= -82; w6<= -17; w7<= -26; w8<= -82; end // OUT:10 IN:12
            173: begin w0<= -29; w1<= -49; w2<= -22; w3<= -19; w4<=  -3; w5<=  17; w6<=  23; w7<=  25; w8<=   3; end // OUT:10 IN:13
            174: begin w0<= -33; w1<=  -3; w2<=  38; w3<= -37; w4<=  16; w5<= -29; w6<= -42; w7<= -28; w8<=  41; end // OUT:10 IN:14
            175: begin w0<=  22; w1<=  12; w2<= -33; w3<=  -5; w4<=  50; w5<=  -8; w6<=  51; w7<= -36; w8<= -43; end // OUT:10 IN:15
            176: begin w0<=  11; w1<=   3; w2<= -64; w3<=  16; w4<= -39; w5<= -18; w6<= -31; w7<= -97; w8<= -86; end // OUT:11 IN:0
            177: begin w0<=  42; w1<=   7; w2<=  34; w3<= -44; w4<= -21; w5<=  50; w6<=  14; w7<=  35; w8<=  50; end // OUT:11 IN:1
            178: begin w0<=  29; w1<=  58; w2<= -34; w3<=  10; w4<=  -8; w5<= -13; w6<=  64; w7<=  25; w8<= 124; end // OUT:11 IN:2
            179: begin w0<=  70; w1<=   6; w2<=  55; w3<= -53; w4<= -65; w5<= -90; w6<=  -3; w7<= -14; w8<= -72; end // OUT:11 IN:3
            180: begin w0<=  41; w1<=  19; w2<= -24; w3<= -89; w4<= -36; w5<= -37; w6<=  61; w7<=  33; w8<=  -8; end // OUT:11 IN:4
            181: begin w0<= -53; w1<=  26; w2<=  33; w3<= -12; w4<= -47; w5<=  -8; w6<=   2; w7<= -54; w8<= -13; end // OUT:11 IN:5
            182: begin w0<=  47; w1<=  56; w2<=  31; w3<= -71; w4<= -19; w5<= -37; w6<=  21; w7<= -56; w8<=  54; end // OUT:11 IN:6
            183: begin w0<= -43; w1<= -26; w2<=  62; w3<= -53; w4<= -51; w5<=  36; w6<= -82; w7<= -27; w8<=  15; end // OUT:11 IN:7
            184: begin w0<= -48; w1<= -46; w2<= -30; w3<=   7; w4<=  76; w5<= 127; w6<= -27; w7<= 115; w8<=  45; end // OUT:11 IN:8
            185: begin w0<=  33; w1<= -12; w2<= -58; w3<= -87; w4<=  26; w5<= -44; w6<= -43; w7<=  13; w8<= -71; end // OUT:11 IN:9
            186: begin w0<= 125; w1<=  62; w2<=  55; w3<=  21; w4<=  31; w5<=  46; w6<=  32; w7<= 111; w8<= 100; end // OUT:11 IN:10
            187: begin w0<=  44; w1<= -24; w2<= -21; w3<=  71; w4<= -12; w5<= -23; w6<= -11; w7<=  89; w8<=  38; end // OUT:11 IN:11
            188: begin w0<=  53; w1<=  49; w2<=  78; w3<=  -4; w4<=  43; w5<=  92; w6<= -29; w7<=  22; w8<= 103; end // OUT:11 IN:12
            189: begin w0<= -31; w1<= -47; w2<=  53; w3<=  -8; w4<=  38; w5<= -48; w6<=  32; w7<=  16; w8<=   0; end // OUT:11 IN:13
            190: begin w0<=  46; w1<=  45; w2<=  25; w3<=  -4; w4<=  46; w5<=  -9; w6<= -28; w7<=  -9; w8<=   1; end // OUT:11 IN:14
            191: begin w0<= -21; w1<= -30; w2<= -54; w3<= -24; w4<=  -3; w5<= -27; w6<= -36; w7<= -11; w8<= -37; end // OUT:11 IN:15
            192: begin w0<=  48; w1<=  55; w2<=  31; w3<=  23; w4<=   1; w5<= -37; w6<= -14; w7<= -43; w8<= -61; end // OUT:12 IN:0
            193: begin w0<= -19; w1<= -75; w2<= -25; w3<= -45; w4<=  14; w5<=  24; w6<=  17; w7<=  41; w8<=  30; end // OUT:12 IN:1
            194: begin w0<= -53; w1<= -18; w2<=-108; w3<= -42; w4<= -81; w5<=  30; w6<=  54; w7<=  87; w8<=  72; end // OUT:12 IN:2
            195: begin w0<= -19; w1<=  37; w2<=   7; w3<=  18; w4<=   5; w5<= -55; w6<= -29; w7<= -22; w8<=  -5; end // OUT:12 IN:3
            196: begin w0<=  12; w1<= -23; w2<=  -9; w3<= -34; w4<= -43; w5<= -63; w6<=  19; w7<=  34; w8<= -15; end // OUT:12 IN:4
            197: begin w0<= -16; w1<=  20; w2<= -31; w3<=   2; w4<= -20; w5<=  25; w6<=  -6; w7<= -29; w8<= -31; end // OUT:12 IN:5
            198: begin w0<= -25; w1<= -49; w2<= -10; w3<=   7; w4<=   9; w5<= -14; w6<=  -2; w7<=   3; w8<=  33; end // OUT:12 IN:6
            199: begin w0<=  19; w1<=  -4; w2<=  10; w3<=  20; w4<=   3; w5<=   4; w6<=  -6; w7<= -72; w8<= -33; end // OUT:12 IN:7
            200: begin w0<= -34; w1<= -18; w2<= -28; w3<=   0; w4<=   2; w5<=  47; w6<=   4; w7<=   4; w8<=  11; end // OUT:12 IN:8
            201: begin w0<=   3; w1<=  33; w2<=  -9; w3<=  14; w4<= -34; w5<= -64; w6<= -28; w7<=   7; w8<=  13; end // OUT:12 IN:9
            202: begin w0<= -69; w1<= -30; w2<= -92; w3<= -24; w4<=  21; w5<= -38; w6<=   1; w7<=  17; w8<=  18; end // OUT:12 IN:10
            203: begin w0<= -74; w1<= -15; w2<=  23; w3<=  11; w4<=  45; w5<=  27; w6<=  11; w7<=  61; w8<= -13; end // OUT:12 IN:11
            204: begin w0<=  -2; w1<=  -9; w2<=-128; w3<=  11; w4<= -36; w5<=  23; w6<= -27; w7<=  -1; w8<=  51; end // OUT:12 IN:12
            205: begin w0<= -52; w1<= -46; w2<= -41; w3<= -33; w4<=  -1; w5<=  -7; w6<=   6; w7<=   5; w8<=  11; end // OUT:12 IN:13
            206: begin w0<=   5; w1<=   4; w2<=  16; w3<=  26; w4<=   6; w5<= -24; w6<= -16; w7<=   2; w8<=  22; end // OUT:12 IN:14
            207: begin w0<= -27; w1<=  20; w2<=  -8; w3<=  20; w4<=  16; w5<=  12; w6<=  -8; w7<=  30; w8<= -29; end // OUT:12 IN:15
            208: begin w0<= -37; w1<=  35; w2<=   3; w3<=  -5; w4<= -44; w5<=  28; w6<=  35; w7<=  43; w8<=   4; end // OUT:13 IN:0
            209: begin w0<=-125; w1<= -93; w2<= -51; w3<= -28; w4<= -78; w5<= -21; w6<= -99; w7<= -56; w8<= -87; end // OUT:13 IN:1
            210: begin w0<=  -9; w1<=  32; w2<= -54; w3<= -96; w4<=-102; w5<=-128; w6<= -99; w7<= -69; w8<= -23; end // OUT:13 IN:2
            211: begin w0<=  25; w1<= -12; w2<=  24; w3<=  16; w4<= -31; w5<=  17; w6<=  -6; w7<= -64; w8<=  17; end // OUT:13 IN:3
            212: begin w0<=  40; w1<=  79; w2<=  12; w3<= -16; w4<=  16; w5<= -10; w6<=   7; w7<=  21; w8<=   9; end // OUT:13 IN:4
            213: begin w0<= -42; w1<=   4; w2<=  21; w3<= -34; w4<=  41; w5<= -45; w6<=  31; w7<= -35; w8<= -28; end // OUT:13 IN:5
            214: begin w0<= -42; w1<=  13; w2<= -52; w3<= -63; w4<=  11; w5<=  22; w6<= -31; w7<= -13; w8<=   7; end // OUT:13 IN:6
            215: begin w0<=  20; w1<=  25; w2<= -35; w3<=  18; w4<= -30; w5<=  19; w6<=  -5; w7<=  41; w8<=  55; end // OUT:13 IN:7
            216: begin w0<= -24; w1<=  18; w2<=  28; w3<=  19; w4<=  -1; w5<= -56; w6<= -31; w7<=   0; w8<=  87; end // OUT:13 IN:8
            217: begin w0<= -14; w1<=  -8; w2<=  22; w3<=  36; w4<= -20; w5<=  33; w6<= -30; w7<= -23; w8<=  38; end // OUT:13 IN:9
            218: begin w0<= -10; w1<=  11; w2<=   3; w3<= -26; w4<= -29; w5<= -37; w6<= -57; w7<= -22; w8<= -42; end // OUT:13 IN:10
            219: begin w0<= -76; w1<= -28; w2<= -75; w3<= -86; w4<= -57; w5<= -65; w6<= -88; w7<= -17; w8<= -33; end // OUT:13 IN:11
            220: begin w0<=   9; w1<= -69; w2<=   6; w3<=-112; w4<= -33; w5<= -37; w6<= -14; w7<=  -9; w8<= -45; end // OUT:13 IN:12
            221: begin w0<=  -8; w1<= -20; w2<=  17; w3<= -35; w4<= -15; w5<= -18; w6<= -38; w7<= -21; w8<= -14; end // OUT:13 IN:13
            222: begin w0<=   0; w1<=  38; w2<=  36; w3<= -35; w4<= -32; w5<=  18; w6<= -23; w7<=  37; w8<= -30; end // OUT:13 IN:14
            223: begin w0<=  -5; w1<= -34; w2<=  15; w3<= -38; w4<=  37; w5<= -31; w6<= -38; w7<=  11; w8<=   4; end // OUT:13 IN:15
            224: begin w0<=   6; w1<=  10; w2<=  -4; w3<= -65; w4<= -43; w5<= -10; w6<= -51; w7<=  17; w8<=  -8; end // OUT:14 IN:0
            225: begin w0<= -77; w1<= -14; w2<=  31; w3<= -30; w4<= -22; w5<=-101; w6<= -63; w7<=   5; w8<=  41; end // OUT:14 IN:1
            226: begin w0<=  -4; w1<= -99; w2<= -44; w3<= -39; w4<= -82; w5<=  49; w6<= -56; w7<= -64; w8<= -48; end // OUT:14 IN:2
            227: begin w0<= -23; w1<=-128; w2<=-109; w3<=  16; w4<= -62; w5<= -10; w6<=-125; w7<=  16; w8<=-121; end // OUT:14 IN:3
            228: begin w0<=  11; w1<= -92; w2<= -31; w3<= -33; w4<= 100; w5<=  42; w6<=  65; w7<=  62; w8<=  76; end // OUT:14 IN:4
            229: begin w0<= -25; w1<=  10; w2<= -84; w3<=   6; w4<= -23; w5<=   8; w6<=  15; w7<=  55; w8<=  40; end // OUT:14 IN:5
            230: begin w0<=  19; w1<= -40; w2<=-110; w3<=  13; w4<= -43; w5<= -30; w6<= -83; w7<=  26; w8<= -98; end // OUT:14 IN:6
            231: begin w0<= -25; w1<= -73; w2<= -97; w3<= -16; w4<= -64; w5<=   6; w6<=  13; w7<= -54; w8<= -45; end // OUT:14 IN:7
            232: begin w0<= -62; w1<= -28; w2<=   7; w3<= -31; w4<= -83; w5<= -23; w6<= -22; w7<= -82; w8<=  14; end // OUT:14 IN:8
            233: begin w0<= -77; w1<=  45; w2<= -54; w3<=-110; w4<=  -7; w5<= -18; w6<= -75; w7<= -42; w8<= -70; end // OUT:14 IN:9
            234: begin w0<= -83; w1<=  -2; w2<=  24; w3<=   8; w4<=  80; w5<= -26; w6<= -89; w7<= -80; w8<=  19; end // OUT:14 IN:10
            235: begin w0<= -83; w1<= -46; w2<= -41; w3<=   4; w4<= -37; w5<=  45; w6<= -26; w7<=   0; w8<= -99; end // OUT:14 IN:11
            236: begin w0<= -39; w1<=-121; w2<= -86; w3<=   6; w4<= -23; w5<= -97; w6<=   4; w7<= -51; w8<= -75; end // OUT:14 IN:12
            237: begin w0<=  27; w1<= -83; w2<= -29; w3<=-111; w4<= -67; w5<= -15; w6<= -42; w7<=  13; w8<= -65; end // OUT:14 IN:13
            238: begin w0<=  -9; w1<= -84; w2<= -75; w3<= -67; w4<= -41; w5<= -12; w6<= -40; w7<=   4; w8<= -18; end // OUT:14 IN:14
            239: begin w0<=  16; w1<= -13; w2<=  42; w3<=  38; w4<=   8; w5<=  55; w6<=   4; w7<=  75; w8<=   4; end // OUT:14 IN:15
            240: begin w0<=  34; w1<=   2; w2<=  35; w3<= -42; w4<= -44; w5<= -34; w6<= -46; w7<=  13; w8<=  21; end // OUT:15 IN:0
            241: begin w0<=  27; w1<= -14; w2<= -29; w3<=  10; w4<=  46; w5<=  -8; w6<= -42; w7<=   7; w8<=  23; end // OUT:15 IN:1
            242: begin w0<=-128; w1<=-103; w2<=-111; w3<=  -1; w4<=  13; w5<= -27; w6<= -40; w7<= -17; w8<= -41; end // OUT:15 IN:2
            243: begin w0<= -19; w1<= -74; w2<= -75; w3<= -72; w4<=  11; w5<= -39; w6<= -61; w7<= -15; w8<= -29; end // OUT:15 IN:3
            244: begin w0<= -20; w1<= -81; w2<=   2; w3<= -48; w4<= -90; w5<= -57; w6<= -53; w7<=  40; w8<=  13; end // OUT:15 IN:4
            245: begin w0<=  44; w1<=  69; w2<= -19; w3<=  21; w4<= -37; w5<=  14; w6<= -56; w7<=  -1; w8<= -40; end // OUT:15 IN:5
            246: begin w0<=-120; w1<= -94; w2<= -37; w3<=  14; w4<=   6; w5<= -82; w6<=-113; w7<= -62; w8<= -93; end // OUT:15 IN:6
            247: begin w0<=  59; w1<= -54; w2<= -43; w3<= -68; w4<=  33; w5<=  -7; w6<= -46; w7<=  44; w8<=  41; end // OUT:15 IN:7
            248: begin w0<=  -7; w1<= -56; w2<= -48; w3<=  35; w4<=  60; w5<=  -6; w6<= -41; w7<=  58; w8<= -27; end // OUT:15 IN:8
            249: begin w0<=  37; w1<= -91; w2<= -88; w3<= -90; w4<= -15; w5<= -77; w6<= -62; w7<= -95; w8<= -97; end // OUT:15 IN:9
            250: begin w0<=  11; w1<= -51; w2<=-116; w3<=  37; w4<=   2; w5<= -60; w6<=  35; w7<= -13; w8<= -62; end // OUT:15 IN:10
            251: begin w0<= -21; w1<=  24; w2<= -21; w3<= -78; w4<=  -4; w5<=   8; w6<= -94; w7<= -89; w8<= -59; end // OUT:15 IN:11
            252: begin w0<= -93; w1<= -68; w2<= -36; w3<= -68; w4<= -11; w5<= -47; w6<= -14; w7<=  30; w8<=  28; end // OUT:15 IN:12
            253: begin w0<= -25; w1<= -99; w2<=  -7; w3<= -19; w4<=  11; w5<=-123; w6<= -74; w7<= -62; w8<= -57; end // OUT:15 IN:13
            254: begin w0<=  28; w1<=  20; w2<=  -8; w3<=  48; w4<=  47; w5<=  26; w6<= -38; w7<= -40; w8<= -45; end // OUT:15 IN:14
            255: begin w0<=   2; w1<= -46; w2<= -68; w3<= -31; w4<=  44; w5<=   6; w6<= -23; w7<= -38; w8<=  65; end // OUT:15 IN:15
            256: begin w0<=   8; w1<= -29; w2<=  44; w3<=  14; w4<=  29; w5<=  41; w6<= -38; w7<= -43; w8<= -37; end // OUT:16 IN:0
            257: begin w0<= -15; w1<= -46; w2<= -82; w3<=  29; w4<= -55; w5<=   0; w6<= -65; w7<=   7; w8<=  16; end // OUT:16 IN:1
            258: begin w0<= -53; w1<= -56; w2<= -62; w3<= -22; w4<= -17; w5<= -22; w6<= 127; w7<=  70; w8<= 108; end // OUT:16 IN:2
            259: begin w0<=  13; w1<= -18; w2<= -26; w3<=  33; w4<=  40; w5<=   9; w6<=  31; w7<= -50; w8<=  -9; end // OUT:16 IN:3
            260: begin w0<=  -7; w1<= -13; w2<= -19; w3<= -80; w4<= -73; w5<=  10; w6<=  66; w7<=  15; w8<=  64; end // OUT:16 IN:4
            261: begin w0<=  -7; w1<=  26; w2<=  40; w3<=  35; w4<=   8; w5<=  46; w6<= -45; w7<= -12; w8<= -48; end // OUT:16 IN:5
            262: begin w0<= -18; w1<=  10; w2<= -14; w3<= -70; w4<= -66; w5<= -62; w6<= -15; w7<=  17; w8<=  18; end // OUT:16 IN:6
            263: begin w0<=  20; w1<= -42; w2<= -65; w3<=  40; w4<= -13; w5<= -16; w6<=  -3; w7<= -36; w8<= -26; end // OUT:16 IN:7
            264: begin w0<= -39; w1<=  25; w2<= -41; w3<= -39; w4<= -16; w5<= -54; w6<= -57; w7<= -28; w8<= -10; end // OUT:16 IN:8
            265: begin w0<= -50; w1<=   1; w2<= -16; w3<=  22; w4<= -32; w5<= -11; w6<= -15; w7<=  29; w8<=  43; end // OUT:16 IN:9
            266: begin w0<=  17; w1<= -55; w2<=  22; w3<= -37; w4<=-119; w5<= -80; w6<=  81; w7<=  86; w8<= -12; end // OUT:16 IN:10
            267: begin w0<= -55; w1<=  -2; w2<= -41; w3<= -12; w4<=   6; w5<=   3; w6<= -49; w7<= -52; w8<= -48; end // OUT:16 IN:11
            268: begin w0<= -35; w1<= -70; w2<=  -1; w3<= -28; w4<= -69; w5<= -98; w6<=   7; w7<=  34; w8<=  66; end // OUT:16 IN:12
            269: begin w0<= -17; w1<= -24; w2<=   4; w3<= -53; w4<= -18; w5<= -48; w6<=  38; w7<= -14; w8<=  45; end // OUT:16 IN:13
            270: begin w0<= -53; w1<=  16; w2<=  48; w3<= -21; w4<= -21; w5<=  44; w6<= -23; w7<=  14; w8<=  46; end // OUT:16 IN:14
            271: begin w0<= -15; w1<= -26; w2<=  16; w3<= -36; w4<=  26; w5<= -22; w6<=  -9; w7<= -12; w8<=   8; end // OUT:16 IN:15
            272: begin w0<= -74; w1<= -43; w2<= -89; w3<= -12; w4<=   3; w5<= -64; w6<=  83; w7<=  82; w8<=  35; end // OUT:17 IN:0
            273: begin w0<= -53; w1<= -58; w2<=  27; w3<= -55; w4<= -94; w5<=  15; w6<= -76; w7<= -66; w8<=-119; end // OUT:17 IN:1
            274: begin w0<= -54; w1<= -51; w2<= -74; w3<=  45; w4<=  41; w5<=  63; w6<=  71; w7<=  79; w8<=  71; end // OUT:17 IN:2
            275: begin w0<=  23; w1<= -31; w2<= -53; w3<=  37; w4<= -29; w5<= -30; w6<=  -8; w7<=  43; w8<=  66; end // OUT:17 IN:3
            276: begin w0<= -28; w1<= -44; w2<=-124; w3<=  43; w4<= -64; w5<= -76; w6<=  42; w7<= 116; w8<=  73; end // OUT:17 IN:4
            277: begin w0<= -47; w1<=   8; w2<=   8; w3<= -38; w4<= -58; w5<= -16; w6<= -55; w7<=  -3; w8<= -21; end // OUT:17 IN:5
            278: begin w0<=   4; w1<= -68; w2<=   9; w3<=  28; w4<=  23; w5<=  18; w6<=-105; w7<= -46; w8<= -42; end // OUT:17 IN:6
            279: begin w0<=-116; w1<= -31; w2<=-106; w3<=-113; w4<= -58; w5<=   0; w6<= -32; w7<=  -8; w8<=  14; end // OUT:17 IN:7
            280: begin w0<=-128; w1<=   7; w2<=  -4; w3<= -64; w4<= -13; w5<= -62; w6<=-117; w7<= -24; w8<= -62; end // OUT:17 IN:8
            281: begin w0<= -28; w1<= -18; w2<= -62; w3<= -74; w4<= -67; w5<= -84; w6<=  48; w7<=  24; w8<=  44; end // OUT:17 IN:9
            282: begin w0<=  96; w1<= -50; w2<= -75; w3<=  66; w4<=  56; w5<=  38; w6<=  70; w7<=  39; w8<= 124; end // OUT:17 IN:10
            283: begin w0<=  17; w1<= -36; w2<= -78; w3<=  -3; w4<= -95; w5<= -72; w6<=-107; w7<=-121; w8<= -35; end // OUT:17 IN:11
            284: begin w0<= -51; w1<= -26; w2<=-106; w3<=  38; w4<=  -5; w5<=  68; w6<=  52; w7<=   0; w8<=  72; end // OUT:17 IN:12
            285: begin w0<= -30; w1<= -22; w2<=  23; w3<=  33; w4<= -12; w5<= -17; w6<=  -9; w7<= -47; w8<=  10; end // OUT:17 IN:13
            286: begin w0<= -43; w1<=  36; w2<=   7; w3<= -20; w4<=  -2; w5<=  -9; w6<=  16; w7<= -11; w8<= -25; end // OUT:17 IN:14
            287: begin w0<=  37; w1<= -37; w2<=  30; w3<=  -5; w4<=  20; w5<=  43; w6<=   8; w7<= -56; w8<= -51; end // OUT:17 IN:15
            288: begin w0<= -27; w1<= -33; w2<=  29; w3<=   2; w4<=  23; w5<= -13; w6<= -32; w7<=  14; w8<=  27; end // OUT:18 IN:0
            289: begin w0<=  31; w1<=  33; w2<= -16; w3<=  11; w4<=  18; w5<= -33; w6<=   4; w7<=  18; w8<= -16; end // OUT:18 IN:1
            290: begin w0<= -24; w1<=  36; w2<=  27; w3<= -10; w4<=  -8; w5<=  13; w6<=  13; w7<= -16; w8<= -70; end // OUT:18 IN:2
            291: begin w0<=   3; w1<= -35; w2<= -26; w3<= -44; w4<= -17; w5<=  -2; w6<=   9; w7<= -41; w8<=  27; end // OUT:18 IN:3
            292: begin w0<= -12; w1<=   1; w2<=  36; w3<= -23; w4<=   4; w5<= -10; w6<=  32; w7<= -34; w8<=  -6; end // OUT:18 IN:4
            293: begin w0<= -23; w1<=  -3; w2<= -13; w3<= -25; w4<= -23; w5<=   5; w6<=  24; w7<=  21; w8<= -24; end // OUT:18 IN:5
            294: begin w0<=  -7; w1<=   7; w2<=   9; w3<=  24; w4<= -19; w5<=  -7; w6<=  14; w7<=  15; w8<=   3; end // OUT:18 IN:6
            295: begin w0<=  14; w1<=   8; w2<= -16; w3<=  54; w4<=  21; w5<=  24; w6<=  21; w7<=  65; w8<=  -8; end // OUT:18 IN:7
            296: begin w0<=  47; w1<= -12; w2<= -55; w3<=  43; w4<= -22; w5<= -60; w6<=  30; w7<= -11; w8<= -31; end // OUT:18 IN:8
            297: begin w0<= -34; w1<=  23; w2<=  -9; w3<=   5; w4<=  40; w5<= -13; w6<=  -5; w7<=  27; w8<=  10; end // OUT:18 IN:9
            298: begin w0<= -21; w1<=  -2; w2<=  59; w3<=   3; w4<=  19; w5<=  12; w6<=  64; w7<=  59; w8<=  29; end // OUT:18 IN:10
            299: begin w0<=  11; w1<= -20; w2<= -54; w3<=  12; w4<=   0; w5<= -40; w6<=  31; w7<= -29; w8<= -44; end // OUT:18 IN:11
            300: begin w0<= -18; w1<=  66; w2<=  51; w3<=  52; w4<= 127; w5<=  52; w6<=  38; w7<= 124; w8<=  62; end // OUT:18 IN:12
            301: begin w0<=   4; w1<=  -2; w2<=  22; w3<=  -6; w4<= -11; w5<=   4; w6<=  14; w7<=  -6; w8<= -29; end // OUT:18 IN:13
            302: begin w0<=  28; w1<= -17; w2<= -11; w3<= -28; w4<= -21; w5<= -10; w6<= -22; w7<= -24; w8<=  -4; end // OUT:18 IN:14
            303: begin w0<= -14; w1<=   6; w2<=  -5; w3<= -26; w4<=  24; w5<= -26; w6<= -17; w7<=  -6; w8<= -17; end // OUT:18 IN:15
            304: begin w0<= -69; w1<=  34; w2<=  28; w3<=   4; w4<=  15; w5<=  29; w6<= -90; w7<= -34; w8<=  22; end // OUT:19 IN:0
            305: begin w0<= -22; w1<= -80; w2<=  -6; w3<=  -1; w4<= -41; w5<=  21; w6<=  23; w7<= -20; w8<=   9; end // OUT:19 IN:1
            306: begin w0<=  41; w1<=   5; w2<= -17; w3<=  11; w4<= -54; w5<= -90; w6<= -34; w7<= -12; w8<=  45; end // OUT:19 IN:2
            307: begin w0<=  37; w1<= -25; w2<=  13; w3<= -49; w4<= -59; w5<= -60; w6<= -60; w7<= -75; w8<= -34; end // OUT:19 IN:3
            308: begin w0<=  76; w1<=  11; w2<=  14; w3<= -50; w4<= -22; w5<=-115; w6<= -39; w7<=  -7; w8<= -95; end // OUT:19 IN:4
            309: begin w0<= -30; w1<= -45; w2<=  44; w3<= -46; w4<= -28; w5<=  61; w6<= -28; w7<= -40; w8<= -19; end // OUT:19 IN:5
            310: begin w0<=   0; w1<=  16; w2<=  14; w3<= -76; w4<=   8; w5<= -46; w6<= -18; w7<= -45; w8<=  34; end // OUT:19 IN:6
            311: begin w0<=  -7; w1<= -37; w2<=-108; w3<= -25; w4<=  23; w5<= -51; w6<=  -6; w7<=  29; w8<= -80; end // OUT:19 IN:7
            312: begin w0<= -75; w1<=  -7; w2<=  31; w3<=  58; w4<=  50; w5<=   0; w6<=  70; w7<=  39; w8<=  56; end // OUT:19 IN:8
            313: begin w0<= -41; w1<=  16; w2<= -32; w3<=  14; w4<=  -6; w5<= -21; w6<= -50; w7<= -19; w8<= -13; end // OUT:19 IN:9
            314: begin w0<=  86; w1<= -35; w2<= -70; w3<=-128; w4<=  13; w5<=  13; w6<= -73; w7<= -52; w8<= -22; end // OUT:19 IN:10
            315: begin w0<=  22; w1<= -63; w2<= -11; w3<=  41; w4<=  18; w5<= -32; w6<= -41; w7<=  37; w8<= -28; end // OUT:19 IN:11
            316: begin w0<=  13; w1<=  57; w2<= -52; w3<=   1; w4<=  12; w5<=  41; w6<= -75; w7<=  27; w8<=  13; end // OUT:19 IN:12
            317: begin w0<= -60; w1<= -68; w2<= -28; w3<= -61; w4<=  17; w5<= -34; w6<= -31; w7<= -10; w8<= -50; end // OUT:19 IN:13
            318: begin w0<=  23; w1<=  43; w2<= -37; w3<=  -4; w4<=  44; w5<= -14; w6<=  47; w7<= -28; w8<=  33; end // OUT:19 IN:14
            319: begin w0<= -53; w1<=  17; w2<=  35; w3<=  -9; w4<=  46; w5<=  18; w6<= -39; w7<= -35; w8<= -33; end // OUT:19 IN:15
            320: begin w0<= -55; w1<= -43; w2<=  90; w3<=  45; w4<= -92; w5<= -93; w6<=  38; w7<= -62; w8<= -47; end // OUT:20 IN:0
            321: begin w0<=  23; w1<=   6; w2<= -56; w3<=  44; w4<=  42; w5<=  77; w6<= -41; w7<=  77; w8<= -35; end // OUT:20 IN:1
            322: begin w0<=  27; w1<=  33; w2<= -11; w3<=-107; w4<= -47; w5<=-118; w6<=  36; w7<=  23; w8<=  34; end // OUT:20 IN:2
            323: begin w0<=  49; w1<= -91; w2<= -73; w3<= -13; w4<=  76; w5<= -20; w6<=   8; w7<= -79; w8<= -95; end // OUT:20 IN:3
            324: begin w0<= -50; w1<=  55; w2<=   2; w3<= -97; w4<=   7; w5<=  48; w6<=-120; w7<=  44; w8<= -99; end // OUT:20 IN:4
            325: begin w0<=  92; w1<=  14; w2<= -30; w3<= -81; w4<=  22; w5<= -85; w6<=  92; w7<=  49; w8<=  60; end // OUT:20 IN:5
            326: begin w0<=  -3; w1<= -22; w2<= -92; w3<=  51; w4<= -79; w5<=  66; w6<=-113; w7<= -71; w8<=-121; end // OUT:20 IN:6
            327: begin w0<=   7; w1<=  34; w2<= -67; w3<= -44; w4<= -80; w5<=  79; w6<= -54; w7<= 105; w8<=  45; end // OUT:20 IN:7
            328: begin w0<=  79; w1<= -55; w2<=-112; w3<= -83; w4<= -77; w5<= -61; w6<=  90; w7<=   7; w8<=  19; end // OUT:20 IN:8
            329: begin w0<=   1; w1<=   0; w2<=-105; w3<=  44; w4<=  45; w5<= -50; w6<=  90; w7<=  10; w8<=  19; end // OUT:20 IN:9
            330: begin w0<=-125; w1<=  64; w2<= -49; w3<=-127; w4<=  61; w5<= -21; w6<= -42; w7<= -35; w8<=  34; end // OUT:20 IN:10
            331: begin w0<=  25; w1<=  33; w2<=   0; w3<=  29; w4<= -80; w5<= -98; w6<=  25; w7<=  40; w8<= -83; end // OUT:20 IN:11
            332: begin w0<=  44; w1<= -65; w2<=  52; w3<= -61; w4<= -25; w5<= -58; w6<=  -2; w7<=-111; w8<=   2; end // OUT:20 IN:12
            333: begin w0<=  55; w1<=  -2; w2<=  58; w3<= -37; w4<= -35; w5<=  54; w6<= -83; w7<= -30; w8<= -80; end // OUT:20 IN:13
            334: begin w0<= -69; w1<=  39; w2<=  34; w3<= -77; w4<=  66; w5<=   3; w6<= -59; w7<= -93; w8<= -51; end // OUT:20 IN:14
            335: begin w0<= -62; w1<=  96; w2<= -39; w3<=  61; w4<=  52; w5<= -17; w6<=  16; w7<=  14; w8<= -93; end // OUT:20 IN:15
            336: begin w0<= -67; w1<= -14; w2<=  17; w3<=  -6; w4<= -65; w5<= -85; w6<= -22; w7<=   2; w8<=  20; end // OUT:21 IN:0
            337: begin w0<= -42; w1<= -56; w2<= -63; w3<= -28; w4<=  -6; w5<=  -3; w6<=   6; w7<= -68; w8<=  13; end // OUT:21 IN:1
            338: begin w0<= -28; w1<= -44; w2<= -61; w3<= -84; w4<= -15; w5<= -19; w6<= -80; w7<= -25; w8<= -65; end // OUT:21 IN:2
            339: begin w0<= -75; w1<= -34; w2<= -56; w3<= -95; w4<= -96; w5<=   5; w6<= -50; w7<= -89; w8<= -68; end // OUT:21 IN:3
            340: begin w0<= -61; w1<= -53; w2<=  28; w3<= -10; w4<= -52; w5<=  31; w6<=-127; w7<=-108; w8<= -22; end // OUT:21 IN:4
            341: begin w0<= -61; w1<=   7; w2<= -23; w3<= -35; w4<=  48; w5<=   4; w6<=  47; w7<= -43; w8<=  16; end // OUT:21 IN:5
            342: begin w0<= -12; w1<=  14; w2<= -27; w3<=  35; w4<= -37; w5<= -42; w6<= -34; w7<= -81; w8<= -43; end // OUT:21 IN:6
            343: begin w0<=  14; w1<=  36; w2<= -13; w3<= -52; w4<= -21; w5<= -45; w6<=  -4; w7<=  21; w8<=  51; end // OUT:21 IN:7
            344: begin w0<= -63; w1<= -81; w2<= -57; w3<= -76; w4<= -32; w5<= -78; w6<= -39; w7<=   5; w8<=  38; end // OUT:21 IN:8
            345: begin w0<=   5; w1<=  24; w2<=  22; w3<=  34; w4<=  10; w5<=  20; w6<=  23; w7<=  -2; w8<= -18; end // OUT:21 IN:9
            346: begin w0<=  -3; w1<=   5; w2<= -64; w3<= -32; w4<= -54; w5<=  29; w6<=  32; w7<= -46; w8<= -36; end // OUT:21 IN:10
            347: begin w0<= -29; w1<= -84; w2<=  -7; w3<= -59; w4<=  -7; w5<=   9; w6<= -58; w7<=  20; w8<= -37; end // OUT:21 IN:11
            348: begin w0<= -42; w1<= -20; w2<=  20; w3<= -36; w4<= -71; w5<=  33; w6<=   4; w7<= -48; w8<=   9; end // OUT:21 IN:12
            349: begin w0<= -76; w1<=  12; w2<= -68; w3<=  26; w4<=  -5; w5<= -37; w6<=  20; w7<= -30; w8<=  -6; end // OUT:21 IN:13
            350: begin w0<=  60; w1<=  29; w2<= -21; w3<= -20; w4<= -52; w5<=  13; w6<= -40; w7<=  54; w8<= -43; end // OUT:21 IN:14
            351: begin w0<= -45; w1<= -16; w2<= -62; w3<=  12; w4<= -28; w5<= -40; w6<=  -4; w7<= -42; w8<=  10; end // OUT:21 IN:15
            352: begin w0<=  -4; w1<=  20; w2<= -43; w3<=  -7; w4<=  11; w5<= -35; w6<=  30; w7<=  25; w8<=   0; end // OUT:22 IN:0
            353: begin w0<=  -4; w1<=   3; w2<= -17; w3<=  32; w4<=  33; w5<=  -6; w6<= -12; w7<= -50; w8<=  -7; end // OUT:22 IN:1
            354: begin w0<= -47; w1<= -37; w2<=  19; w3<=  26; w4<=  76; w5<=  13; w6<=  96; w7<=  77; w8<=  25; end // OUT:22 IN:2
            355: begin w0<= -47; w1<= -19; w2<= -36; w3<= -45; w4<=  -6; w5<=  -9; w6<= -13; w7<= -12; w8<=   6; end // OUT:22 IN:3
            356: begin w0<= -47; w1<=  -7; w2<= -17; w3<= -44; w4<=  14; w5<=  44; w6<=  64; w7<=  18; w8<=  77; end // OUT:22 IN:4
            357: begin w0<= -17; w1<=  30; w2<= -12; w3<= -19; w4<= -11; w5<= -20; w6<= -20; w7<=   1; w8<=  -8; end // OUT:22 IN:5
            358: begin w0<= -14; w1<=   8; w2<= -24; w3<=  13; w4<= -13; w5<=  17; w6<= -22; w7<= -49; w8<= -37; end // OUT:22 IN:6
            359: begin w0<=  33; w1<=   9; w2<= -15; w3<=  18; w4<=   4; w5<= -22; w6<=  84; w7<=  53; w8<=   3; end // OUT:22 IN:7
            360: begin w0<=  22; w1<=  18; w2<= -16; w3<= -21; w4<=  -2; w5<=  -5; w6<= -56; w7<=  -1; w8<= -22; end // OUT:22 IN:8
            361: begin w0<=   1; w1<=  -8; w2<= -29; w3<= -38; w4<=   7; w5<=   6; w6<=  -3; w7<=  41; w8<=   1; end // OUT:22 IN:9
            362: begin w0<=  43; w1<=  29; w2<=  53; w3<=  25; w4<= -23; w5<=  23; w6<=  63; w7<=   1; w8<= -27; end // OUT:22 IN:10
            363: begin w0<= -16; w1<=  -9; w2<= -23; w3<=   7; w4<= -18; w5<= -46; w6<= -41; w7<= -69; w8<= -73; end // OUT:22 IN:11
            364: begin w0<=  47; w1<= -16; w2<= -32; w3<=  95; w4<= 127; w5<=  88; w6<= 123; w7<=  87; w8<=  62; end // OUT:22 IN:12
            365: begin w0<= -38; w1<= -16; w2<= -55; w3<= -22; w4<= -18; w5<= -28; w6<= -36; w7<=   1; w8<=  -4; end // OUT:22 IN:13
            366: begin w0<=  -2; w1<= -21; w2<=  20; w3<= -34; w4<=  35; w5<= -14; w6<= -10; w7<=  -3; w8<= -17; end // OUT:22 IN:14
            367: begin w0<=  17; w1<=  21; w2<= -13; w3<=  17; w4<=   0; w5<= -15; w6<=  -6; w7<= -15; w8<=  -3; end // OUT:22 IN:15
            368: begin w0<=  26; w1<=   0; w2<= -26; w3<=  14; w4<= -31; w5<= -37; w6<= -40; w7<= -57; w8<= -20; end // OUT:23 IN:0
            369: begin w0<= -12; w1<= -51; w2<= -10; w3<=   4; w4<=   0; w5<=  11; w6<= -33; w7<=  32; w8<=   9; end // OUT:23 IN:1
            370: begin w0<=  20; w1<=  -2; w2<= -40; w3<= -31; w4<= -81; w5<= -41; w6<= -62; w7<= -23; w8<= -60; end // OUT:23 IN:2
            371: begin w0<=  49; w1<= -25; w2<=  -9; w3<=  45; w4<=  15; w5<=  29; w6<=   7; w7<=  -7; w8<= -25; end // OUT:23 IN:3
            372: begin w0<=  25; w1<= -48; w2<=  -6; w3<=  38; w4<= -10; w5<= -42; w6<=   0; w7<=   9; w8<=   0; end // OUT:23 IN:4
            373: begin w0<= -38; w1<= -10; w2<=   0; w3<= -28; w4<=  -4; w5<=   4; w6<=  20; w7<=  12; w8<=   7; end // OUT:23 IN:5
            374: begin w0<= -40; w1<=  -3; w2<=  14; w3<=  33; w4<=  23; w5<=  22; w6<=  25; w7<= -38; w8<=  29; end // OUT:23 IN:6
            375: begin w0<=  31; w1<=  55; w2<=  55; w3<=  -1; w4<= -22; w5<=  31; w6<=  15; w7<=  25; w8<=  80; end // OUT:23 IN:7
            376: begin w0<= -25; w1<= -30; w2<= -37; w3<= -71; w4<= -39; w5<= -37; w6<= -14; w7<=  -1; w8<=   4; end // OUT:23 IN:8
            377: begin w0<=  33; w1<= -28; w2<=  14; w3<=  20; w4<=  -3; w5<= -20; w6<=  -8; w7<= -58; w8<= -22; end // OUT:23 IN:9
            378: begin w0<=  15; w1<=  56; w2<=   1; w3<=  53; w4<= -10; w5<=  -6; w6<=   3; w7<=  55; w8<=  39; end // OUT:23 IN:10
            379: begin w0<= -33; w1<=   4; w2<=  41; w3<=  17; w4<=  11; w5<=   0; w6<=  33; w7<=  21; w8<= -21; end // OUT:23 IN:11
            380: begin w0<=  51; w1<=  59; w2<=  70; w3<=  32; w4<=  15; w5<= 127; w6<= -35; w7<=   6; w8<=  61; end // OUT:23 IN:12
            381: begin w0<=  24; w1<=  18; w2<=  29; w3<=  29; w4<= -33; w5<= -36; w6<= -34; w7<=  27; w8<=   4; end // OUT:23 IN:13
            382: begin w0<= -25; w1<=  24; w2<=   6; w3<=  -4; w4<=  24; w5<= -14; w6<=  -1; w7<=  19; w8<=  33; end // OUT:23 IN:14
            383: begin w0<=  -4; w1<= -14; w2<=   5; w3<=  32; w4<=   2; w5<=   1; w6<= -28; w7<=  27; w8<= -26; end // OUT:23 IN:15
            384: begin w0<=  26; w1<=  61; w2<=  -4; w3<=  -5; w4<= -29; w5<= -75; w6<=  30; w7<= -62; w8<= -64; end // OUT:24 IN:0
            385: begin w0<= -25; w1<= -53; w2<= -52; w3<=  21; w4<= -53; w5<=  92; w6<= -16; w7<=   5; w8<=  25; end // OUT:24 IN:1
            386: begin w0<= -94; w1<= -15; w2<=-121; w3<=  41; w4<=  24; w5<= -57; w6<= -56; w7<=   0; w8<=  79; end // OUT:24 IN:2
            387: begin w0<= -22; w1<=  26; w2<=   9; w3<=  51; w4<=  75; w5<= -53; w6<=  57; w7<=  60; w8<= -90; end // OUT:24 IN:3
            388: begin w0<= -46; w1<=  31; w2<=-104; w3<=  39; w4<= -69; w5<= -65; w6<=  62; w7<= 103; w8<= -71; end // OUT:24 IN:4
            389: begin w0<=  33; w1<= -22; w2<= -46; w3<=  33; w4<= -12; w5<= -40; w6<=  33; w7<=  44; w8<=  44; end // OUT:24 IN:5
            390: begin w0<= -54; w1<=  10; w2<= -33; w3<=   8; w4<=  58; w5<=  45; w6<=  12; w7<=  28; w8<=   1; end // OUT:24 IN:6
            391: begin w0<=  -5; w1<=  38; w2<=  70; w3<= -43; w4<=  51; w5<=  64; w6<=  36; w7<= -30; w8<=  48; end // OUT:24 IN:7
            392: begin w0<= -21; w1<= -39; w2<=  -6; w3<= -58; w4<= -12; w5<=  95; w6<= -87; w7<=  19; w8<=  18; end // OUT:24 IN:8
            393: begin w0<=  51; w1<= -59; w2<=  24; w3<=   4; w4<= -84; w5<= -56; w6<=  -4; w7<= -80; w8<= -33; end // OUT:24 IN:9
            394: begin w0<=  12; w1<=  81; w2<= -49; w3<=  -5; w4<= 110; w5<=  53; w6<= -57; w7<= 103; w8<=  37; end // OUT:24 IN:10
            395: begin w0<=  13; w1<=   6; w2<=  82; w3<= -66; w4<= 127; w5<=  51; w6<=  14; w7<=  37; w8<=  59; end // OUT:24 IN:11
            396: begin w0<=  40; w1<=  46; w2<=  32; w3<=  36; w4<= -55; w5<=  61; w6<=  42; w7<= -22; w8<=  43; end // OUT:24 IN:12
            397: begin w0<= -22; w1<=  16; w2<= -42; w3<= -36; w4<=  39; w5<= -15; w6<= -23; w7<= -57; w8<= -52; end // OUT:24 IN:13
            398: begin w0<=  31; w1<=  46; w2<= -12; w3<=  17; w4<=  15; w5<= -49; w6<= -11; w7<=  41; w8<=  10; end // OUT:24 IN:14
            399: begin w0<= -21; w1<= -16; w2<=   4; w3<=   9; w4<= -53; w5<= -39; w6<=  28; w7<= -26; w8<= -42; end // OUT:24 IN:15
            400: begin w0<= -15; w1<= -28; w2<=  15; w3<= -14; w4<= -23; w5<=  41; w6<= -41; w7<= -24; w8<=  40; end // OUT:25 IN:0
            401: begin w0<= -15; w1<= -32; w2<= -22; w3<=  17; w4<=   0; w5<=  -8; w6<=  17; w7<=  15; w8<=  -8; end // OUT:25 IN:1
            402: begin w0<= -31; w1<= -40; w2<=  -4; w3<= -24; w4<= -40; w5<= -27; w6<= -31; w7<= -26; w8<=  21; end // OUT:25 IN:2
            403: begin w0<= -35; w1<= -21; w2<=  19; w3<= -29; w4<= -33; w5<= -13; w6<=  10; w7<= -37; w8<= -16; end // OUT:25 IN:3
            404: begin w0<= -14; w1<= -47; w2<= -22; w3<=   4; w4<= -35; w5<= -17; w6<= -10; w7<=  -9; w8<=  21; end // OUT:25 IN:4
            405: begin w0<= -20; w1<=  10; w2<=  13; w3<= -12; w4<=  19; w5<=  18; w6<=  -2; w7<=   5; w8<=  20; end // OUT:25 IN:5
            406: begin w0<= -12; w1<=  11; w2<= -12; w3<=   9; w4<=   2; w5<= -23; w6<=   4; w7<=  14; w8<=   9; end // OUT:25 IN:6
            407: begin w0<=  -1; w1<=  32; w2<=  37; w3<=  -6; w4<= -13; w5<=  89; w6<= -34; w7<=  -5; w8<=  64; end // OUT:25 IN:7
            408: begin w0<=   7; w1<= -24; w2<= -25; w3<= -13; w4<=  -9; w5<= -26; w6<= -18; w7<=   4; w8<= -33; end // OUT:25 IN:8
            409: begin w0<=  -3; w1<=  21; w2<=  26; w3<= -13; w4<= -15; w5<=  48; w6<= -41; w7<=  -2; w8<=  21; end // OUT:25 IN:9
            410: begin w0<=  23; w1<=   8; w2<= -38; w3<=   7; w4<= -33; w5<=  -2; w6<=  26; w7<= -13; w8<= -28; end // OUT:25 IN:10
            411: begin w0<=  -5; w1<=  12; w2<= -55; w3<=  18; w4<=  11; w5<=   0; w6<=  11; w7<= -18; w8<= -32; end // OUT:25 IN:11
            412: begin w0<=  30; w1<=  52; w2<= 127; w3<= -45; w4<=  53; w5<= 122; w6<= -22; w7<=  48; w8<=  62; end // OUT:25 IN:12
            413: begin w0<=  -8; w1<= -16; w2<=  -1; w3<= -10; w4<=   6; w5<=  16; w6<= -28; w7<=  -1; w8<=  21; end // OUT:25 IN:13
            414: begin w0<=  24; w1<=  11; w2<=  25; w3<=  11; w4<=  -6; w5<=  -2; w6<=  11; w7<=  15; w8<= -25; end // OUT:25 IN:14
            415: begin w0<= -25; w1<=  -8; w2<=  12; w3<=   5; w4<= -11; w5<=  22; w6<= -21; w7<= -22; w8<= -19; end // OUT:25 IN:15
            416: begin w0<=  40; w1<= -89; w2<= -24; w3<=  43; w4<=  39; w5<=  10; w6<= -65; w7<= -10; w8<=   1; end // OUT:26 IN:0
            417: begin w0<=  39; w1<= -14; w2<= -16; w3<=  33; w4<=  37; w5<= -66; w6<= -80; w7<=  25; w8<=  38; end // OUT:26 IN:1
            418: begin w0<=-128; w1<= -12; w2<=  63; w3<=  42; w4<= -24; w5<= -12; w6<= -77; w7<= -56; w8<= -19; end // OUT:26 IN:2
            419: begin w0<=  -8; w1<= -71; w2<=  39; w3<=-100; w4<= -65; w5<=  -3; w6<= -73; w7<=   8; w8<= -46; end // OUT:26 IN:3
            420: begin w0<= -62; w1<= -23; w2<=   7; w3<= -47; w4<= -37; w5<=  53; w6<= -33; w7<=-110; w8<=  -8; end // OUT:26 IN:4
            421: begin w0<= -63; w1<= -53; w2<=  69; w3<= -30; w4<=  33; w5<= -26; w6<= -44; w7<= -79; w8<=  57; end // OUT:26 IN:5
            422: begin w0<= -30; w1<= -40; w2<=  12; w3<=  23; w4<= -79; w5<= -99; w6<=  17; w7<= -67; w8<= -89; end // OUT:26 IN:6
            423: begin w0<= -75; w1<= -88; w2<= -28; w3<= -12; w4<= -88; w5<= -22; w6<= -85; w7<= -48; w8<= -81; end // OUT:26 IN:7
            424: begin w0<=  13; w1<= -87; w2<= -49; w3<= -42; w4<= -69; w5<=  43; w6<= -30; w7<= -94; w8<=  27; end // OUT:26 IN:8
            425: begin w0<= -92; w1<= -25; w2<= -77; w3<= -40; w4<= -21; w5<=  20; w6<=  57; w7<=  30; w8<=  16; end // OUT:26 IN:9
            426: begin w0<= -73; w1<= -80; w2<=  25; w3<=  28; w4<=  68; w5<=  -9; w6<= -22; w7<= -13; w8<= -82; end // OUT:26 IN:10
            427: begin w0<=  40; w1<= -63; w2<= -89; w3<= -30; w4<=  57; w5<=  20; w6<= -16; w7<= -36; w8<= -26; end // OUT:26 IN:11
            428: begin w0<= -16; w1<= -18; w2<=  36; w3<= -40; w4<= -20; w5<=  36; w6<= -38; w7<= -21; w8<= -78; end // OUT:26 IN:12
            429: begin w0<=  17; w1<=  52; w2<= -70; w3<=   0; w4<=-101; w5<=  15; w6<=  46; w7<= -76; w8<=  -3; end // OUT:26 IN:13
            430: begin w0<= -58; w1<= -82; w2<= -65; w3<=  39; w4<= -46; w5<=  68; w6<=  28; w7<= -58; w8<= -66; end // OUT:26 IN:14
            431: begin w0<=   1; w1<=  19; w2<=  27; w3<=  59; w4<=  42; w5<= -15; w6<=  68; w7<=  77; w8<= -45; end // OUT:26 IN:15
            432: begin w0<= -47; w1<= -10; w2<=  20; w3<= -49; w4<= -24; w5<=   3; w6<= -24; w7<=   1; w8<=  35; end // OUT:27 IN:0
            433: begin w0<=   7; w1<=  16; w2<=  16; w3<=   3; w4<=  13; w5<=   7; w6<=  38; w7<=  18; w8<= -71; end // OUT:27 IN:1
            434: begin w0<= -22; w1<= -11; w2<= -13; w3<=   4; w4<=  43; w5<=  32; w6<=  45; w7<=  42; w8<=  12; end // OUT:27 IN:2
            435: begin w0<= -46; w1<= -46; w2<=  20; w3<= -31; w4<= -32; w5<=   0; w6<= -22; w7<=  22; w8<=  19; end // OUT:27 IN:3
            436: begin w0<= -50; w1<=   6; w2<=   6; w3<= -40; w4<= -17; w5<= -15; w6<=  58; w7<=   2; w8<= -36; end // OUT:27 IN:4
            437: begin w0<=  29; w1<=   3; w2<=  25; w3<= -19; w4<=   1; w5<=  -7; w6<=  15; w7<= -25; w8<=  22; end // OUT:27 IN:5
            438: begin w0<=   7; w1<=  10; w2<=  22; w3<=  26; w4<= -25; w5<=  15; w6<=  -6; w7<= -32; w8<= -45; end // OUT:27 IN:6
            439: begin w0<=   1; w1<=  69; w2<=  25; w3<= -19; w4<=  31; w5<=  14; w6<=   7; w7<=   4; w8<=  56; end // OUT:27 IN:7
            440: begin w0<=  29; w1<= -25; w2<= -21; w3<=  35; w4<=  12; w5<= -47; w6<= -22; w7<= -32; w8<= -62; end // OUT:27 IN:8
            441: begin w0<= -20; w1<=  -1; w2<=  34; w3<= -17; w4<=  24; w5<=  12; w6<=  26; w7<=  32; w8<=   5; end // OUT:27 IN:9
            442: begin w0<=  20; w1<=  40; w2<=   4; w3<= -36; w4<=  28; w5<=  17; w6<=  -7; w7<=  35; w8<=  31; end // OUT:27 IN:10
            443: begin w0<= -10; w1<= -16; w2<=   6; w3<=  12; w4<=  24; w5<= -22; w6<= -34; w7<= -15; w8<= -38; end // OUT:27 IN:11
            444: begin w0<=  20; w1<=  71; w2<= 117; w3<=  -5; w4<= 116; w5<=  80; w6<=  72; w7<= 127; w8<=  62; end // OUT:27 IN:12
            445: begin w0<= -36; w1<= -21; w2<=  28; w3<= -28; w4<=   5; w5<=  32; w6<=  28; w7<=  -8; w8<= -37; end // OUT:27 IN:13
            446: begin w0<= -19; w1<=  29; w2<= -26; w3<=  14; w4<= -24; w5<=  -1; w6<= -26; w7<=  10; w8<=  22; end // OUT:27 IN:14
            447: begin w0<=  -2; w1<=  -6; w2<= -31; w3<= -19; w4<= -26; w5<= -19; w6<= -25; w7<=  -3; w8<=  15; end // OUT:27 IN:15
            448: begin w0<= -26; w1<= -20; w2<= -47; w3<= -64; w4<= -22; w5<=  59; w6<= -15; w7<=  44; w8<= -24; end // OUT:28 IN:0
            449: begin w0<=  74; w1<=  81; w2<=  10; w3<= -18; w4<= -73; w5<= -77; w6<= -86; w7<=  66; w8<=  -4; end // OUT:28 IN:1
            450: begin w0<= -49; w1<=  95; w2<=  -5; w3<=  45; w4<= -65; w5<= -44; w6<= -54; w7<= -41; w8<= -13; end // OUT:28 IN:2
            451: begin w0<= -47; w1<=  14; w2<=  66; w3<= -47; w4<= -82; w5<= -61; w6<=  63; w7<= -87; w8<= -50; end // OUT:28 IN:3
            452: begin w0<=  39; w1<=  86; w2<= 117; w3<=-100; w4<=   6; w5<= -18; w6<=  52; w7<=  -5; w8<= -55; end // OUT:28 IN:4
            453: begin w0<= -40; w1<= -65; w2<=  39; w3<=  30; w4<= -30; w5<=  48; w6<= -18; w7<= -10; w8<=  34; end // OUT:28 IN:5
            454: begin w0<= -75; w1<=  19; w2<=   3; w3<=   7; w4<=  64; w5<=  49; w6<= -14; w7<=  15; w8<=  29; end // OUT:28 IN:6
            455: begin w0<=  13; w1<=   7; w2<= -72; w3<=  76; w4<=  15; w5<= -20; w6<= -50; w7<= -20; w8<= -22; end // OUT:28 IN:7
            456: begin w0<= -62; w1<= -99; w2<= -46; w3<= -18; w4<= -10; w5<= -41; w6<=  10; w7<= -66; w8<= -86; end // OUT:28 IN:8
            457: begin w0<= -74; w1<=  49; w2<=  55; w3<=   2; w4<= -44; w5<=  11; w6<=  41; w7<= -22; w8<= -19; end // OUT:28 IN:9
            458: begin w0<= -55; w1<=  71; w2<= 127; w3<= -28; w4<=  57; w5<= -46; w6<=  -3; w7<=   4; w8<=  71; end // OUT:28 IN:10
            459: begin w0<= -39; w1<=  34; w2<= -50; w3<= -66; w4<=  56; w5<= -74; w6<= -40; w7<=  60; w8<=  27; end // OUT:28 IN:11
            460: begin w0<=  18; w1<= 110; w2<= -23; w3<=  57; w4<=  25; w5<=  57; w6<=  47; w7<=  27; w8<=  88; end // OUT:28 IN:12
            461: begin w0<=  49; w1<= -78; w2<=  30; w3<= -76; w4<= -72; w5<= -50; w6<= -64; w7<=  59; w8<=  43; end // OUT:28 IN:13
            462: begin w0<=  22; w1<=  43; w2<= -40; w3<= -49; w4<=  60; w5<= -24; w6<=  27; w7<=  65; w8<=  -6; end // OUT:28 IN:14
            463: begin w0<=  19; w1<=  24; w2<=  31; w3<= -56; w4<= -30; w5<= -61; w6<=  68; w7<=   1; w8<=  -3; end // OUT:28 IN:15
            464: begin w0<= -59; w1<= -13; w2<=  -2; w3<= -83; w4<= -59; w5<=   0; w6<=   2; w7<= -93; w8<= -23; end // OUT:29 IN:0
            465: begin w0<=  18; w1<=  -6; w2<= -82; w3<= -93; w4<= -25; w5<=  32; w6<=  20; w7<=  27; w8<= -98; end // OUT:29 IN:1
            466: begin w0<= -64; w1<= -91; w2<= -18; w3<=-113; w4<= -27; w5<= -51; w6<= -18; w7<= -23; w8<= -94; end // OUT:29 IN:2
            467: begin w0<= -37; w1<= -80; w2<= -96; w3<=  -9; w4<=   4; w5<= -12; w6<= -26; w7<= -33; w8<= -77; end // OUT:29 IN:3
            468: begin w0<=  -3; w1<= -61; w2<= -53; w3<=  12; w4<= -24; w5<=  -7; w6<=-112; w7<= -75; w8<= -84; end // OUT:29 IN:4
            469: begin w0<=  -6; w1<= -31; w2<=  10; w3<= -37; w4<=  28; w5<=   4; w6<= -63; w7<=  31; w8<= -23; end // OUT:29 IN:5
            470: begin w0<= -68; w1<= -14; w2<=-103; w3<=-114; w4<= -28; w5<= -94; w6<= -46; w7<= -93; w8<= -54; end // OUT:29 IN:6
            471: begin w0<=  18; w1<=  35; w2<= -65; w3<=  16; w4<=  60; w5<=   6; w6<=  21; w7<= -19; w8<=  58; end // OUT:29 IN:7
            472: begin w0<= -74; w1<= -44; w2<=  -1; w3<= -85; w4<= -11; w5<= -48; w6<=  29; w7<= -64; w8<=  -5; end // OUT:29 IN:8
            473: begin w0<= -91; w1<= -77; w2<= -55; w3<= -10; w4<=  33; w5<= -53; w6<= -48; w7<=   0; w8<= -81; end // OUT:29 IN:9
            474: begin w0<= -46; w1<= -82; w2<=-123; w3<=-128; w4<= -91; w5<=-124; w6<= -68; w7<= -79; w8<= -90; end // OUT:29 IN:10
            475: begin w0<= -75; w1<=  28; w2<=  28; w3<=-111; w4<=  29; w5<=  27; w6<= -50; w7<= -74; w8<=  -1; end // OUT:29 IN:11
            476: begin w0<= -50; w1<=  49; w2<=  57; w3<= -86; w4<= -67; w5<= -54; w6<= -51; w7<= -55; w8<= -77; end // OUT:29 IN:12
            477: begin w0<=  19; w1<= -44; w2<=  23; w3<= -17; w4<=  34; w5<=  12; w6<= -18; w7<= -35; w8<= -37; end // OUT:29 IN:13
            478: begin w0<= -44; w1<=  44; w2<=  42; w3<=  13; w4<=  68; w5<=  74; w6<= -63; w7<=   1; w8<= -48; end // OUT:29 IN:14
            479: begin w0<=   5; w1<= -68; w2<=  73; w3<=  33; w4<=  48; w5<= -16; w6<= -56; w7<= -73; w8<=  57; end // OUT:29 IN:15
            480: begin w0<=-109; w1<=-122; w2<=-126; w3<= -19; w4<= -40; w5<= -87; w6<= -71; w7<=-124; w8<=  30; end // OUT:30 IN:0
            481: begin w0<=  38; w1<= -30; w2<=  14; w3<=-100; w4<=  66; w5<= 117; w6<= 117; w7<=  77; w8<= 100; end // OUT:30 IN:1
            482: begin w0<= -89; w1<= -99; w2<= 122; w3<= -12; w4<= -90; w5<=  69; w6<=-105; w7<=  26; w8<= -17; end // OUT:30 IN:2
            483: begin w0<=   1; w1<= -80; w2<=-113; w3<= 119; w4<= -52; w5<=  16; w6<=   5; w7<=  70; w8<=  49; end // OUT:30 IN:3
            484: begin w0<= -73; w1<= -31; w2<= -53; w3<=-127; w4<=  30; w5<=  39; w6<=   8; w7<= -69; w8<=  11; end // OUT:30 IN:4
            485: begin w0<= -82; w1<= 125; w2<=  61; w3<= 123; w4<= 114; w5<= -83; w6<= 104; w7<=  97; w8<=  31; end // OUT:30 IN:5
            486: begin w0<=-120; w1<=-104; w2<= -75; w3<= -88; w4<= -91; w5<= 110; w6<=  44; w7<= 104; w8<= -98; end // OUT:30 IN:6
            487: begin w0<=  62; w1<=  20; w2<=  -4; w3<= -29; w4<=  49; w5<= -34; w6<= -95; w7<=-118; w8<=  98; end // OUT:30 IN:7
            488: begin w0<=  90; w1<= -34; w2<= -69; w3<= -32; w4<=  -3; w5<=-123; w6<=  15; w7<=-118; w8<= -58; end // OUT:30 IN:8
            489: begin w0<=  -4; w1<=-101; w2<= 111; w3<=  43; w4<= -47; w5<=  17; w6<= 123; w7<= -62; w8<=  34; end // OUT:30 IN:9
            490: begin w0<=  96; w1<=-111; w2<=-101; w3<= -41; w4<= -69; w5<=-123; w6<=  53; w7<= -71; w8<=  -7; end // OUT:30 IN:10
            491: begin w0<=   8; w1<= -69; w2<=  17; w3<=  -7; w4<= -82; w5<=  31; w6<= -16; w7<=  17; w8<= -89; end // OUT:30 IN:11
            492: begin w0<=  44; w1<= -88; w2<=  78; w3<=  61; w4<= -33; w5<= -82; w6<=-105; w7<=  56; w8<=  18; end // OUT:30 IN:12
            493: begin w0<=  10; w1<=  71; w2<=   0; w3<=  46; w4<= -85; w5<=  25; w6<=   4; w7<= -62; w8<=-123; end // OUT:30 IN:13
            494: begin w0<= -64; w1<=  71; w2<=-108; w3<=  42; w4<=  13; w5<= 110; w6<= -53; w7<=-126; w8<= -88; end // OUT:30 IN:14
            495: begin w0<=  12; w1<=-114; w2<=  19; w3<= -43; w4<=  79; w5<=  66; w6<=  94; w7<= -50; w8<=-128; end // OUT:30 IN:15
            496: begin w0<= -46; w1<=  32; w2<= -25; w3<= -28; w4<= -25; w5<=  35; w6<=  63; w7<=   6; w8<=  17; end // OUT:31 IN:0
            497: begin w0<= -58; w1<=  -7; w2<=  13; w3<= -52; w4<= -26; w5<= -61; w6<= -39; w7<=  -7; w8<= -33; end // OUT:31 IN:1
            498: begin w0<=  88; w1<=  95; w2<=  40; w3<= -85; w4<=  16; w5<=-128; w6<= -78; w7<= -35; w8<= -27; end // OUT:31 IN:2
            499: begin w0<= -56; w1<=  46; w2<= -45; w3<=  48; w4<= -80; w5<= -50; w6<= -48; w7<= -30; w8<= -60; end // OUT:31 IN:3
            500: begin w0<= -20; w1<= -44; w2<=  83; w3<= -26; w4<= -84; w5<= -68; w6<= -71; w7<= -69; w8<= -39; end // OUT:31 IN:4
            501: begin w0<= -12; w1<= -29; w2<=   3; w3<= -36; w4<=  24; w5<=  18; w6<= -17; w7<= -33; w8<=  31; end // OUT:31 IN:5
            502: begin w0<= -57; w1<=  47; w2<=  67; w3<= -30; w4<= -67; w5<= -68; w6<= -59; w7<=  15; w8<= -29; end // OUT:31 IN:6
            503: begin w0<=   2; w1<=  14; w2<= -64; w3<=   8; w4<= -41; w5<=   7; w6<=  -5; w7<=  35; w8<=  53; end // OUT:31 IN:7
            504: begin w0<= -68; w1<=   5; w2<= -71; w3<=  48; w4<= -67; w5<=  18; w6<=  88; w7<=  36; w8<=  39; end // OUT:31 IN:8
            505: begin w0<=  56; w1<= -34; w2<=  60; w3<=  54; w4<= -20; w5<=  44; w6<=  58; w7<=  -6; w8<=  45; end // OUT:31 IN:9
            506: begin w0<= -44; w1<= -41; w2<=  27; w3<=  11; w4<= -67; w5<= -28; w6<=-104; w7<=  12; w8<=  -3; end // OUT:31 IN:10
            507: begin w0<= -65; w1<= -44; w2<= -30; w3<= -43; w4<= -48; w5<= -98; w6<=   1; w7<=  18; w8<= -86; end // OUT:31 IN:11
            508: begin w0<= -15; w1<= -50; w2<= -82; w3<= -50; w4<=-124; w5<= -67; w6<= -20; w7<= -12; w8<=-124; end // OUT:31 IN:12
            509: begin w0<=  13; w1<= -59; w2<=  52; w3<= -46; w4<= -61; w5<=  28; w6<= -55; w7<= -28; w8<=  30; end // OUT:31 IN:13
            510: begin w0<= -63; w1<= -69; w2<=  28; w3<=  11; w4<=  31; w5<=  18; w6<=  56; w7<= -45; w8<=  22; end // OUT:31 IN:14
            511: begin w0<=  69; w1<= -57; w2<=  57; w3<=  31; w4<= -43; w5<=  37; w6<=  68; w7<=  46; w8<=  25; end // OUT:31 IN:15
            default: begin w0 <= 8'd0; w1 <= 8'd0 ; w2 <= 8'd0; w3 <= 8'd0; w4 <= 8'd0; w5 <= 8'd0; w6 <= 8'd0; w7 <= 8'd0; w8 <= 8'd0; end
        endcase
    end

endmodule