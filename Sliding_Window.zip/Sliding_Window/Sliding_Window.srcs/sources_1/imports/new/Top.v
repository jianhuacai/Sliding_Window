`timescale 1ns / 1ps

// ==========================================
// 頂層模組 (負責連線與產生脈衝)
// ==========================================
module Top (
    input  wire        clk,
    input  wire        reset,
    input  wire        calc_start,
    
    // ==========================================
    // 🧠 BRAM 0 介面 (Shared_Image_BRAM)
    // ==========================================
    output wire [31:0] bram0_addr,
    output wire [31:0] bram0_din,  // 給 Layer 2 寫入最終結果使用
    input  wire [31:0] bram0_dout, // 給 Layer 1 讀取原圖使用
    output wire [3:0]  bram0_we,   // Layer 2 寫入致能
    output wire        bram0_en,

    // ==========================================
    // 🧠 BRAM 1 介面 (Inter_BRAM)
    // ==========================================
    output wire [31:0] bram1_addr,
    output wire [31:0] bram1_din,  // 給 Layer 1 寫入特徵圖使用
    input  wire [31:0] bram1_dout, // 給 Layer 2 讀取特徵圖使用
    output wire [3:0]  bram1_we,   // Layer 1 寫入致能
    output wire        bram1_en,
    
    output wire        calc_done
);

    // 永遠開啟 BRAM 致能 (由 WE 控制寫入即可)
    assign bram0_en = 1'b1;
    assign bram1_en = 1'b1; 

    wire calc_done_layer1;
    wire calc_done_layer2;
    assign calc_done = sticky_done; // 整體完成信號

    // 🌟 核心標誌位：紀錄目前是哪一層在運作
    reg layer2_active;
    always @(posedge clk or negedge reset) begin
        if (!reset) begin
            layer2_active <= 1'b0;
        end else if (calc_done_layer1) begin
            layer2_active <= 1'b1; // Layer 1 算完，控制權交給 Layer 2
        end else if (calc_done_layer2) begin
            layer2_active <= 1'b0; // 全部算完，重置狀態
        end
    end

    reg sticky_done;
    
    always @(posedge clk or negedge reset) begin
        if (!reset) begin
            sticky_done <= 1'b0;
        end else if (calc_start) begin 
            // 當 Python 發送 start_gpio = 1 時，把牌子放下，準備新的一輪
            sticky_done <= 1'b0;
        end else if (calc_done_layer2) begin 
            // 只要抓到 Layer 2 完成的瞬間，就把牌子舉起來，死都不放下
            sticky_done <= 1'b1;
        end
    end


    // 🌟 內部接線宣告 (先把它們從 Layer 1 & 2 拉出來)
    wire [31:0] l1_in_bram_addr, l1_out_bram_addr, l1_out_bram_din;
    wire [3:0]  l1_in_bram_we, l1_out_bram_we;

    wire [31:0] l2_in_bram_addr, l2_out_bram_addr, l2_out_bram_din;
    wire [3:0]  l2_in_bram_we, l2_out_bram_we;

    // ==========================================
    // 🚦 BRAM 控制權切換 MUX (解決 Multiple Driver 錯誤)
    // ==========================================
    // --- BRAM 0 (L1 讀 / L2 寫) ---
    assign bram0_addr = layer2_active ? l2_out_bram_addr : l1_in_bram_addr;
    assign bram0_din  = l2_out_bram_din; // 只有 Layer 2 會寫入 BRAM 0
    assign bram0_we   = layer2_active ? l2_out_bram_we   : 4'b0000;

    // --- BRAM 1 (L1 寫 / L2 讀) ---
    assign bram1_addr = layer2_active ? l2_in_bram_addr : l1_out_bram_addr;
    assign bram1_din  = l1_out_bram_din; // 只有 Layer 1 會寫入 BRAM 1
    assign bram1_we   = layer2_active ? 4'b0000         : l1_out_bram_we;

    // ==========================================
    // 實例化核心運算模組
    // ==========================================
    (* DONT_TOUCH = "yes" *)
    Layer1 layer1 (
        .clk(clk),
        .reset(reset),
        .calc_start(calc_start), // 吃頂層的 start
        
        .in_bram_addr(l1_in_bram_addr),
        .in_bram_dout(bram0_dout),
        .in_bram_we(l1_in_bram_we),
        
        .out_bram_addr(l1_out_bram_addr),
        .out_bram_din(l1_out_bram_din),
        .out_bram_we(l1_out_bram_we),
        
        .calc_done(calc_done_layer1)
    );
    
    Layer2 layer2 (
        .clk(clk),
        .reset(reset),
        .calc_start(layer2_active), // 🌟 利用 L1 的 done 脈衝直接觸發 L2
        
        .in_bram_addr(l2_in_bram_addr),
        .in_bram_dout(bram1_dout),
        .in_bram_we(l2_in_bram_we),
        
        .out_bram_addr(l2_out_bram_addr),
        .out_bram_din(l2_out_bram_din),
        .out_bram_we(l2_out_bram_we),
        
        .calc_done(calc_done_layer2)
    );

endmodule