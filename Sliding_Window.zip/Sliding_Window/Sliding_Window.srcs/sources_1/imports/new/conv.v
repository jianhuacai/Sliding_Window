`timescale 1ns / 1ps

module conv (
    input          clk,
    input          reset,
    input          start,     

    // 權重與像素輸入保持不變
    input  signed [7:0]  w0, w1, w2, w3, w4, w5, w6, w7, w8,
    input         [7:0] p0, p1, p2, p3, p4, p5, p6, p7, p8,

    output reg signed [31:0] result,    
    output reg               done       
);

    // 1. 強制讓 9 個乘法獨立使用 DSP
    (* use_dsp = "yes" *) reg signed [16:0] m0, m1, m2, m3, m4, m5, m6, m7, m8;
    
    // 2. 加法樹的管線暫存器 (避免加法拉太長產生新的 Slack 違規)
    reg signed [31:0] sum0, sum1, sum2;
    reg signed [31:0] sum_final_stage;

    reg [1:0] state; // 狀態機變得非常簡單
    localparam IDLE = 2'd0, STG_MUL = 2'd1, STG_ADD = 2'd2, STG_DONE = 2'd3;

    always @(posedge clk or negedge reset) begin
        if (!reset) begin
            state <= IDLE;
            done <= 1'b0;
            result <= 32'd0;
        end else begin
            case (state)
                IDLE: begin
                    done <= 1'b0;
                    if (start) begin
                        // 【第 1 拍】：9 個乘法同時引爆！
                        m0 <= w0 * $signed({1'b0, p0});
                        m1 <= w1 * $signed({1'b0, p1});
                        m2 <= w2 * $signed({1'b0, p2});
                        m3 <= w3 * $signed({1'b0, p3});
                        m4 <= w4 * $signed({1'b0, p4});
                        m5 <= w5 * $signed({1'b0, p5});
                        m6 <= w6 * $signed({1'b0, p6});
                        m7 <= w7 * $signed({1'b0, p7});
                        m8 <= w8 * $signed({1'b0, p8});
                        state <= STG_MUL;
                    end
                end

                STG_MUL: begin
                    // 【第 2 拍】：分組相加 (加法樹第一層)
                    sum0 <= m0 + m1 + m2;
                    sum1 <= m3 + m4 + m5;
                    sum2 <= m6 + m7 + m8;
                    state <= STG_ADD;
                end

                STG_ADD: begin
                    // 【第 3 拍】：最後總和
                    sum_final_stage <= sum0 + sum1 + sum2;
                    state <= STG_DONE;
                end

                STG_DONE: begin
                    // 輸出結果
                    result <= sum_final_stage;
                    done <= 1'b1;
                    state <= IDLE;
                end
            endcase
        end
    end
endmodule
