`timescale 1ns / 1ps
`define W_SIZE 4    
`define IMG_W 126   
`define OUT_W 62    
`define CH 16       


module Layer1 (
    input  wire        clk,
    input  wire        reset,
    input  wire        calc_start,

    // 📦 讀取原圖 (BRAM 0) -> 腳位全部設為 wire
    output wire [31:0] in_bram_addr,
    input  wire [31:0] in_bram_dout,
    output wire [3:0]  in_bram_we,
    
    // 📦 寫入結果 (BRAM 1) -> 腳位全部設為 wire
    output wire [31:0] out_bram_addr,
    output wire [31:0] out_bram_din,
    output wire [3:0]  out_bram_we,

    output wire        calc_done
);

    localparam BASE_IMAGE  = 32'h0; 

    localparam PIXEL_BYTES   = 4; 
    localparam ROW_BYTES     = `IMG_W * PIXEL_BYTES;          
    localparam WIN_NEXT_ROW  = ROW_BYTES - (3 * PIXEL_BYTES); 
    localparam POOL_STRIDE_X = 2 * PIXEL_BYTES;               
    localparam POOL_STRIDE_Y = 2 * ROW_BYTES;                 

    localparam IDLE        = 4'd0,
               IMG_READ    = 4'd1,  
               CONV_START  = 4'd2,  
               CONV_WAIT   = 4'd3,  
               PAIR_1      = 4'd4,  
               PAIR_2      = 4'd5, 
               SCALE_STG   = 4'd6,  
               BRAM_WRITE  = 4'd7,  
               NEXT_CH     = 4'd8,  
               NEXT_WIN    = 4'd9,  
               DONE        = 4'd10;

    reg [3:0] state, next_state;

    reg [5:0]  col_cnt, row_cnt; 
    reg [3:0]  out_ch_cnt;       
    reg [4:0]  re_count;         
    
    reg [31:0] img_ptr;          
    reg [31:0] row_start_ptr;    
    
    // 🌟 獨立的讀寫指標 (維持你習慣的 Byte Address)
    reg [31:0] read_ptr_byte;
    reg [31:0] write_ptr_byte;

    reg        [7:0] img_buf    [0:15];
    reg signed [31:0] out_data, pair_data1, pair_data2;

    assign calc_done = (state == DONE);
    
    // 🌟 【關鍵修改】直接使用純粹的 assign，絕不報錯，且維持原汁原味的 +4
    assign in_bram_we    = 4'b0000;
    assign in_bram_addr  = read_ptr_byte;
    
    assign out_bram_addr = write_ptr_byte;
    assign out_bram_we   = (state == BRAM_WRITE) ? 4'b1111 : 4'b0000;
    assign out_bram_din  = out_data;
    
    // ==========================================
    // 🧠 1. 將 Tensor 寫入純組合邏輯 (權重)
    // ==========================================
    reg signed [7:0] w0, w1, w2, w3, w4, w5, w6, w7, w8;
    always @(*) begin
        case(out_ch_cnt)
            4'd0 :  begin w0=   90; w1=   53; w2=  127; w3=   86; w4=   21; w5=   94; w6=  -55; w7=  -46; w8=   82; end
            4'd1 :  begin w0=   14; w1=  -33; w2= -127; w3= -123; w4=  -66; w5=   54; w6= -119; w7=   55; w8=   74; end
            4'd2 :  begin w0= -119; w1=  -20; w2=  -70; w3=  -81; w4=   65; w5=   -6; w6=  127; w7=   14; w8=   48; end
            4'd3 :  begin w0=  -51; w1=   76; w2= -120; w3=   47; w4=  127; w5=  -60; w6=  127; w7=   32; w8=  -63; end
            4'd4 :  begin w0=   12; w1= -128; w2= -114; w3=  102; w4=  106; w5=   83; w6= -102; w7=   99; w8=  -52; end
            4'd5 :  begin w0= -119; w1= -122; w2=  127; w3=  -13; w4=   -9; w5=   80; w6=  -49; w7=  -89; w8= -118; end
            4'd6 :  begin w0= -122; w1=   62; w2=  -45; w3=  -26; w4=  105; w5= -128; w6=    7; w7=   51; w8=  -42; end
            4'd7 :  begin w0= -116; w1=   60; w2=   95; w3=   40; w4=  -99; w5=  125; w6=   77; w7= -128; w8=  -10; end
            4'd8 :  begin w0=  -61; w1=   55; w2=   22; w3= -116; w4=  -79; w5=  -76; w6= -128; w7=  -51; w8= -115; end
            4'd9 :  begin w0= -127; w1=  -37; w2=   63; w3=   45; w4=   59; w5=   38; w6=  -33; w7=  -42; w8=  104; end
            4'd10:  begin w0=  -53; w1=  -11; w2=   -9; w3=    8; w4=  -77; w5=   58; w6=  127; w7=  -32; w8=  -79; end
            4'd11:  begin w0=   82; w1=  -63; w2=   21; w3=  117; w4= -128; w5=  -60; w6=   45; w7= -111; w8=   26; end
            4'd12:  begin w0= -103; w1=  -67; w2=   99; w3= -124; w4=  -19; w5=  124; w6=   49; w7=  -41; w8=  127; end
            4'd13:  begin w0=  -66; w1=  127; w2=  -77; w3= -127; w4=   14; w5=  -56; w6=  -48; w7=  124; w8=    7; end
            4'd14:  begin w0=  -12; w1=   21; w2=  -85; w3=   13; w4=  -78; w5= -128; w6=  114; w7=  -38; w8=  -32; end
            4'd15:  begin w0=  -11; w1=   23; w2=  -74; w3=  -22; w4=  -77; w5= -128; w6=  -78; w7=   50; w8=   51; end
            default:begin w0=0; w1=0; w2=0; w3=0; w4=0; w5=0; w6=0; w7=0; w8=0; end
        endcase
    end

    // ==========================================
    // ⚔️ 2. Conv 例化
    // ==========================================
    wire signed [31:0] conv_res [0:3];
    wire [3:0]  conv_dones;
    wire        start_conv = (state == CONV_START);

    conv window1 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[0]), .p1(img_buf[1]), .p2(img_buf[2]), .p3(img_buf[4]), .p4(img_buf[5]), .p5(img_buf[6]), .p6(img_buf[8]), .p7(img_buf[9]), .p8(img_buf[10]), .result(conv_res[0]), .done(conv_dones[0]));
    conv window2 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[1]), .p1(img_buf[2]), .p2(img_buf[3]), .p3(img_buf[5]), .p4(img_buf[6]), .p5(img_buf[7]), .p6(img_buf[9]), .p7(img_buf[10]), .p8(img_buf[11]), .result(conv_res[1]), .done(conv_dones[1]));
    conv window3 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[4]), .p1(img_buf[5]), .p2(img_buf[6]), .p3(img_buf[8]), .p4(img_buf[9]), .p5(img_buf[10]), .p6(img_buf[12]), .p7(img_buf[13]), .p8(img_buf[14]), .result(conv_res[2]), .done(conv_dones[2]));
    conv window4 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[5]), .p1(img_buf[6]), .p2(img_buf[7]), .p3(img_buf[9]), .p4(img_buf[10]), .p5(img_buf[11]), .p6(img_buf[13]), .p7(img_buf[14]), .p8(img_buf[15]), .result(conv_res[3]), .done(conv_dones[3]));

    // ==========================================
    // ⚙️ 3. 狀態機控制
    // ==========================================
    always @(posedge clk or negedge reset) begin
        if(!reset) state <= IDLE;
        else       state <= next_state;
    end

    always @(*) begin
        case(state)
            IDLE:       next_state = (calc_start) ? IMG_READ : IDLE;
            IMG_READ:   next_state = (re_count == 15) ? CONV_START : IMG_READ; 
            CONV_START: next_state = CONV_WAIT;
            CONV_WAIT:  next_state = (&conv_dones) ? PAIR_1 : CONV_WAIT;
            PAIR_1:     next_state = PAIR_2;
            PAIR_2:     next_state = SCALE_STG; 
            SCALE_STG:  next_state = BRAM_WRITE; 
            BRAM_WRITE: next_state = NEXT_CH; 
            NEXT_CH:    next_state = (out_ch_cnt == `CH - 1) ? NEXT_WIN : CONV_START;
            NEXT_WIN:   next_state = (col_cnt == `OUT_W-1 && row_cnt == `OUT_W - 1) ? DONE : IMG_READ;
            DONE:       next_state = IDLE;
            default:    next_state = IDLE;
        endcase
    end

    // ==========================================
    // 🧮 4. 記憶體指標控制 (拔除所有 WE 和 DIN 的邏輯，保持乾淨的 +4)
    // ==========================================
    always @(posedge clk or negedge reset) begin
        if(!reset) begin
            read_ptr_byte <= 0; write_ptr_byte <= 0; 
            re_count <= 0; col_cnt <= 0; row_cnt <= 0; out_ch_cnt <= 0;
            img_ptr <= 0; row_start_ptr <= 0;
        end else begin
            case(state)
                IDLE: begin
                    re_count <= 0; col_cnt <= 0; row_cnt <= 0; out_ch_cnt <= 0;
                    img_ptr        <= BASE_IMAGE;
                    row_start_ptr  <= BASE_IMAGE;
                    read_ptr_byte  <= BASE_IMAGE;
                    write_ptr_byte <= 0;
                end
                IMG_READ: begin
                    if (re_count == 15) begin
                        re_count <= 0;
                    end else begin
                        re_count <= re_count + 1;
                        if ((re_count & 2'b11) == 2'b11) begin
                            read_ptr_byte <= read_ptr_byte + WIN_NEXT_ROW; 
                        end else begin
                            read_ptr_byte <= read_ptr_byte + PIXEL_BYTES;
                        end
                    end
                end
                NEXT_CH: begin
                    write_ptr_byte <= write_ptr_byte + 4;
                    if (out_ch_cnt == `CH - 1) out_ch_cnt <= 0;
                    else                       out_ch_cnt <= out_ch_cnt + 1;
                end
                NEXT_WIN: begin
                    if (col_cnt == `OUT_W - 1) begin
                        col_cnt <= 0;
                        row_cnt <= row_cnt + 1;
                        row_start_ptr <= row_start_ptr + POOL_STRIDE_Y;
                        img_ptr       <= row_start_ptr + POOL_STRIDE_Y;
                        read_ptr_byte <= row_start_ptr + POOL_STRIDE_Y;
                    end else begin
                        col_cnt <= col_cnt + 1;
                        img_ptr       <= img_ptr + POOL_STRIDE_X;
                        read_ptr_byte <= img_ptr + POOL_STRIDE_X;
                    end
                end
            endcase
        end
    end

    reg [4:0] cap_idx;
    reg       cap_img_en;

    always @(posedge clk or negedge reset) begin
        if(!reset) begin
            cap_idx    <= 0;
            cap_img_en <= 0;
        end else begin
            cap_idx    <= re_count;
            cap_img_en <= (state == IMG_READ);
        end
    end

    always @(posedge clk) begin
        // 取出下半部的 8 bit (因為新版你只存 8 bit)
        if (cap_img_en) img_buf[cap_idx] <= in_bram_dout[7:0];
    end

    // ==========================================
    // ⚖️ 6. 各通道專屬的 Scale 乘數
    // ==========================================
    reg signed [7:0] ch_scale;
    always @(*) begin
        case(out_ch_cnt)
            4'd0:  ch_scale = 8'd89;
            4'd1:  ch_scale = 8'd88;
            4'd2:  ch_scale = 8'd105;
            4'd3:  ch_scale = 8'd96;
            4'd4:  ch_scale = 8'd71;
            4'd5:  ch_scale = 8'd77;
            4'd6:  ch_scale = 8'd93;
            4'd7:  ch_scale = 8'd93; 
            4'd8:  ch_scale = 8'd85;
            4'd9:  ch_scale = 8'd107;
            4'd10: ch_scale = 8'd102;
            4'd11: ch_scale = 8'd95;
            4'd12: ch_scale = 8'd85;
            4'd13: ch_scale = 8'd76;
            4'd14: ch_scale = 8'd57;
            4'd15: ch_scale = 8'd93;
            default: ch_scale = 8'd0;
        endcase
    end

    // ==========================================
    // 🏆 7. Max Pooling 計算與 Scale 縮放 (>>> 16)
    // ==========================================
    reg signed [31:0] current_max_reg; 
    
    wire signed [39:0] scaled_result = $signed(current_max_reg) * $signed(ch_scale);

    wire signed [31:0] relu_0 = (conv_res[0] > 0) ? conv_res[0] : 0;
    wire signed [31:0] relu_1 = (conv_res[1] > 0) ? conv_res[1] : 0;
    wire signed [31:0] relu_2 = (conv_res[2] > 0) ? conv_res[2] : 0;
    wire signed [31:0] relu_3 = (conv_res[3] > 0) ? conv_res[3] : 0;

    always @(posedge clk) begin
        if(state == PAIR_1) begin
            pair_data1 <= (relu_0 > relu_1) ? relu_0 : relu_1;
            pair_data2 <= (relu_2 > relu_3) ? relu_2 : relu_3;
        end
        if(state == PAIR_2) begin
            current_max_reg <= (pair_data1 > pair_data2) ? pair_data1 : pair_data2;
        end
        if(state == SCALE_STG) begin
            out_data <= scaled_result >>> 16;
        end
    end

endmodule