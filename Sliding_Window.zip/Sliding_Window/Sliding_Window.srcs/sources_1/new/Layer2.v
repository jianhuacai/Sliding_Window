`timescale 1ns / 1ps

// ==========================================
// Layer 2 核心運算模組
// ==========================================
module Layer2 (
    input  wire        clk,
    input  wire        reset,
    input  wire        calc_start,

    // 📦 讀取特徵圖 (Inter_BRAM) - 接收 Layer 1 結果
    output wire [31:0] in_bram_addr,
    input  wire [31:0] in_bram_dout,
    output wire [3:0]  in_bram_we,
    
    // 📦 寫入結果 (Shared_Image_BRAM) - 覆寫原圖
    output wire [31:0] out_bram_addr,
    output wire [31:0] out_bram_din,
    output wire [3:0]  out_bram_we,

    output wire        calc_done
);

    // ==========================================
    // 📐 硬體參數與跨距設定 (HWC 排列)
    // ==========================================
    localparam IMG_W  = 62; // 輸入尺寸 62x62
    localparam OUT_W  = 30; // 輸出尺寸 30x30
    localparam IN_CH  = 16;
    localparam OUT_CH = 32;

    // 🌟 跨距計算 (1 個像素包含 16 個 32-bit 通道 = 64 Bytes)
    // 💡 註：這裡假設你的 Inter_BRAM 每個 Address 依然是跳 4 Bytes (32-bit 寬度)
    localparam PIXEL_BYTES   = IN_CH * 4;                 // 64 Bytes
    localparam ROW_BYTES     = IMG_W * PIXEL_BYTES;       // 62 * 64 = 3968 Bytes
    localparam WIN_NEXT_ROW  = ROW_BYTES - (3 * PIXEL_BYTES); // 換行退回
    localparam POOL_STRIDE_X = 2 * PIXEL_BYTES;           // Stride = 2    
    localparam POOL_STRIDE_Y = 2 * ROW_BYTES;             // Stride = 2

    // ==========================================
    // ⚙️ 狀態機定義 (加入累加與管線化狀態)
    // ==========================================
    localparam IDLE        = 4'd0,
               IMG_READ    = 4'd1,  
               CONV_START  = 4'd2,  
               CONV_WAIT   = 4'd3,  
               ACCUM       = 4'd4,  // 累加 16 個通道
               NEXT_IN_CH  = 4'd5,  // 切換讀取下一個輸入通道
               POOL_STG1   = 4'd6,  // ReLU + 找兩兩最大值
               POOL_STG2   = 4'd7,  // 找最終最大值 (切斷 Critical Path)
               SCALE_STG   = 4'd8,  // 乘上 Scale 並右移 (切斷 Critical Path)
               BRAM_WRITE  = 4'd9,  // 寫入 BRAM
               NEXT_OUT_CH = 4'd10, // 切換下一個輸出通道
               NEXT_WIN    = 4'd11, // 空間視窗滑動
               DONE        = 4'd12;

    reg [3:0] state, next_state;

    reg [5:0] col_cnt, row_cnt; 
    reg [4:0] out_ch_cnt; // 0~31
    reg [4:0] in_ch_cnt;  // 0~15
    reg [4:0] re_count;   // 0~15 (讀取 4x4 像素)
    
    reg [31:0] win_base_ptr;  
    reg [31:0] row_start_ptr; 
    reg [31:0] read_ptr_byte;
    reg [31:0] write_ptr_byte;

    // 資料暫存區
    reg signed [7:0]  img_buf [0:15]; 
    reg signed [31:0] acc_res [0:3];  

    assign calc_done = (state == DONE);
    
    // BRAM 控制訊號
    assign in_bram_we    = 4'b0000; // 永遠只讀
    assign in_bram_addr  = read_ptr_byte;
    
    assign out_bram_we   = (state == BRAM_WRITE) ? 4'b1111 : 4'b0000;
    assign out_bram_addr = write_ptr_byte;
    assign out_bram_din  = out_data;

    reg signed [7:0] ch_scale;
    always @(*) begin
        case(out_ch_cnt)
            5'd0:  ch_scale = 8'd25;
            5'd1:  ch_scale = 8'd46;
            5'd2:  ch_scale = 8'd36;
            5'd3:  ch_scale = 8'd64;
            5'd4:  ch_scale = 8'd35;
            5'd5:  ch_scale = 8'd28;
            5'd6:  ch_scale = 8'd30;
            5'd7:  ch_scale = 8'd32;
            5'd8:  ch_scale = 8'd47;
            5'd9:  ch_scale = 8'd29;
            5'd10: ch_scale = 8'd30;
            5'd11: ch_scale = 8'd30;
            5'd12: ch_scale = 8'd34;
            5'd13: ch_scale = 8'd71;
            5'd14: ch_scale = 8'd29;
            5'd15: ch_scale = 8'd118;
            5'd16: ch_scale = 8'd28;
            5'd17: ch_scale = 8'd67;
            5'd18: ch_scale = 8'd36;
            5'd19: ch_scale = 8'd28;
            5'd20: ch_scale = 8'd36;
            5'd21: ch_scale = 8'd63;
            5'd22: ch_scale = 8'd32;
            5'd23: ch_scale = 8'd44;
            5'd24: ch_scale = 8'd29;
            5'd25: ch_scale = 8'd40;
            5'd26: ch_scale = 8'd29;
            5'd27: ch_scale = 8'd28;
            5'd28: ch_scale = 8'd35;
            5'd29: ch_scale = 8'd35;
            5'd30: ch_scale = 8'd38;
            5'd31: ch_scale = 8'd30;
            default: ch_scale = 8'd0; // 測試用
        endcase
    end

    // ==========================================
    // ⚔️ 2. 例化 4 個 L2 卷積模組 (共用權重)
    // ==========================================
    wire signed [31:0] conv_res [0:3];
    wire [3:0]  conv_dones;
    wire        start_conv = (state == CONV_START);

    conv window1 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[0]), .p1(img_buf[1]), .p2(img_buf[2]), .p3(img_buf[4]), .p4(img_buf[5]), .p5(img_buf[6]), .p6(img_buf[8]), .p7(img_buf[9]), .p8(img_buf[10]), .result(conv_res[0]), .done(conv_dones[0]));
    conv window2 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[1]), .p1(img_buf[2]), .p2(img_buf[3]), .p3(img_buf[5]), .p4(img_buf[6]), .p5(img_buf[7]), .p6(img_buf[9]), .p7(img_buf[10]), .p8(img_buf[11]), .result(conv_res[1]), .done(conv_dones[1]));
    conv window3 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[4]), .p1(img_buf[5]), .p2(img_buf[6]), .p3(img_buf[8]), .p4(img_buf[9]), .p5(img_buf[10]), .p6(img_buf[12]), .p7(img_buf[13]), .p8(img_buf[14]), .result(conv_res[2]), .done(conv_dones[2]));
    conv window4 (.clk(clk), .reset(reset), .start(start_conv), .w0(w0), .w1(w1), .w2(w2), .w3(w3), .w4(w4), .w5(w5), .w6(w6), .w7(w7), .w8(w8), .p0(img_buf[5]), .p1(img_buf[6]), .p2(img_buf[7]), .p3(img_buf[9]), .p4(img_buf[10]), .p5(img_buf[11]), .p6(img_buf[13]), .p7(img_buf[14]), .p8(img_buf[15]), .result(conv_res[3]), .done(conv_dones[3]));

    // ==========================================
    // ⚙️ 3. 狀態機控制
    // ==========================================
    always @(posedge clk or negedge reset) begin
        if(!reset) state <= IDLE;
        else       state <= next_state;
    end

    always @(*) begin
        case(state)
            IDLE:        next_state = (calc_start) ? IMG_READ : IDLE;
            IMG_READ:    next_state = (re_count == 15) ? CONV_START : IMG_READ; 
            CONV_START:  next_state = CONV_WAIT;
            CONV_WAIT:   next_state = (&conv_dones) ? ACCUM : CONV_WAIT;
            ACCUM:       next_state = NEXT_IN_CH;
            NEXT_IN_CH:  next_state = (in_ch_cnt == IN_CH - 1) ? POOL_STG1 : IMG_READ; 
            POOL_STG1:   next_state = POOL_STG2;   
            POOL_STG2:   next_state = SCALE_STG;   
            SCALE_STG:   next_state = BRAM_WRITE;  
            BRAM_WRITE:  next_state = NEXT_OUT_CH; 
            NEXT_OUT_CH: next_state = (out_ch_cnt == OUT_CH - 1) ? NEXT_WIN : IMG_READ;
            NEXT_WIN:    next_state = (col_cnt == OUT_W-1 && row_cnt == OUT_W-1) ? DONE : IMG_READ;
            DONE:        next_state = IDLE; // 等待頂層重置
            default:     next_state = IDLE;
        endcase
    end

    // ==========================================
    // 🧮 4. 記憶體指標與 BRAM 讀取捕捉
    // ==========================================
    reg [4:0] cap_idx;
    reg       cap_img_en;

    always @(posedge clk or negedge reset) begin
        if(!reset) begin
            read_ptr_byte <= 0; write_ptr_byte <= 0; 
            re_count <= 0; col_cnt <= 0; row_cnt <= 0; 
            out_ch_cnt <= 0; in_ch_cnt <= 0;
            win_base_ptr <= 0; row_start_ptr <= 0;
            cap_idx <= 0; cap_img_en <= 0;
            acc_res[0] <= 0; acc_res[1] <= 0; acc_res[2] <= 0; acc_res[3] <= 0;
        end else begin
            cap_idx    <= re_count;
            cap_img_en <= (state == IMG_READ);
            if (cap_img_en) img_buf[cap_idx] <= in_bram_dout[7:0]; 

            case(state)
                IDLE: begin
                    re_count <= 0; col_cnt <= 0; row_cnt <= 0; 
                    out_ch_cnt <= 0; in_ch_cnt <= 0;
                    win_base_ptr   <= 0; 
                    row_start_ptr  <= 0;
                    read_ptr_byte  <= 0;
                    write_ptr_byte <= 0;
                end

                IMG_READ: begin
                    if (re_count == 15) re_count <= 0;
                    else begin
                        re_count <= re_count + 1;
                        if ((re_count & 2'b11) == 2'b11) 
                             read_ptr_byte <= read_ptr_byte + WIN_NEXT_ROW; 
                        else read_ptr_byte <= read_ptr_byte + PIXEL_BYTES;
                    end
                end

                ACCUM: begin
                    acc_res[0] <= acc_res[0] + conv_res[0];
                    acc_res[1] <= acc_res[1] + conv_res[1];
                    acc_res[2] <= acc_res[2] + conv_res[2];
                    acc_res[3] <= acc_res[3] + conv_res[3];
                end

                NEXT_IN_CH: begin
                    if (in_ch_cnt != IN_CH - 1) begin
                        in_ch_cnt <= in_ch_cnt + 1;
                        read_ptr_byte <= win_base_ptr + ((in_ch_cnt + 1) * 4);
                    end
                end

                NEXT_OUT_CH: begin
                    write_ptr_byte <= write_ptr_byte + 4; 
                    in_ch_cnt <= 0; 
                    
                    acc_res[0] <= 0; acc_res[1] <= 0; acc_res[2] <= 0; acc_res[3] <= 0;

                    if (out_ch_cnt == OUT_CH - 1) out_ch_cnt <= 0;
                    else begin 
                        out_ch_cnt <= out_ch_cnt + 1;
                        read_ptr_byte <= win_base_ptr; 
                    end
                end

                NEXT_WIN: begin
                    if (col_cnt == OUT_W - 1) begin
                        col_cnt <= 0;
                        row_cnt <= row_cnt + 1;
                        row_start_ptr <= row_start_ptr + POOL_STRIDE_Y;
                        win_base_ptr  <= row_start_ptr + POOL_STRIDE_Y;
                        read_ptr_byte <= row_start_ptr + POOL_STRIDE_Y;
                    end else begin
                        col_cnt <= col_cnt + 1;
                        win_base_ptr  <= win_base_ptr + POOL_STRIDE_X;
                        read_ptr_byte <= win_base_ptr + POOL_STRIDE_X;
                    end
                end
            endcase
        end
    end

    // ==========================================
    // 🏆 5. Pipelined: ReLU, Max Pooling 與 Scale
    // ==========================================
    reg signed [31:0] pair_data1, pair_data2;     
    reg signed [31:0] current_max_reg;            
    reg signed [31:0] out_data;


    wire signed [31:0] relu_0 = (acc_res[0] > 0) ? acc_res[0] : 0; 
    wire signed [31:0] relu_1 = (acc_res[1] > 0) ? acc_res[1] : 0; 
    wire signed [31:0] relu_2 = (acc_res[2] > 0) ? acc_res[2] : 0; 
    wire signed [31:0] relu_3 = (acc_res[3] > 0) ? acc_res[3] : 0; 


    (* use_dsp = "yes" *) wire signed [39:0] scaled_result = current_max_reg * ch_scale;

    always @(posedge clk) begin
        if(state == POOL_STG1) begin
            pair_data1 <= (relu_0 > relu_1) ? relu_0 : relu_1;
            pair_data2 <= (relu_2 > relu_3) ? relu_2 : relu_3;
        end
        if(state == POOL_STG2) begin
            current_max_reg <= (pair_data1 > pair_data2) ? pair_data1 : pair_data2;
        end
        if(state == SCALE_STG) begin
            out_data <= scaled_result >>> 16;
        end
    end


    // ==========================================
    // 🧠 1. 權重與 Scale (純組合邏輯)
    // ==========================================
    reg signed [7:0] w0, w1, w2, w3, w4, w5, w6, w7, w8;
    always @(posedge clk) begin
        case({out_ch_cnt, in_ch_cnt}) 
            10'h000: begin w0<= -26; w1<=  51; w2<= -36; w3<=-114; w4<= -22; w5<= -57; w6<=  60; w7<=-108; w8<= -26; end // OUT:0 IN:0
            10'h001: begin w0<=  -7; w1<=  82; w2<=  86; w3<= -54; w4<=  74; w5<= -41; w6<= -12; w7<= -29; w8<= -25; end // OUT:0 IN:1
            10'h002: begin w0<=  23; w1<=   2; w2<=  21; w3<= -76; w4<=-127; w5<= -41; w6<= 107; w7<=  29; w8<= -91; end // OUT:0 IN:2
            10'h003: begin w0<=   1; w1<=  63; w2<=  59; w3<=-108; w4<=  32; w5<=  75; w6<= -71; w7<=-107; w8<= 124; end // OUT:0 IN:3
            10'h004: begin w0<= 107; w1<= -40; w2<= -80; w3<=  90; w4<= -70; w5<= 126; w6<=  41; w7<=  91; w8<=  59; end // OUT:0 IN:4
            10'h005: begin w0<=  79; w1<=-114; w2<=  61; w3<=  61; w4<=  46; w5<=  61; w6<= -78; w7<= -21; w8<= -74; end // OUT:0 IN:5
            10'h006: begin w0<= 115; w1<= -65; w2<= 120; w3<=   2; w4<= 100; w5<= -78; w6<=   6; w7<=-108; w8<= -56; end // OUT:0 IN:6
            10'h007: begin w0<=  38; w1<=-111; w2<=   3; w3<= -40; w4<= -69; w5<=-115; w6<= 113; w7<= 121; w8<=-120; end // OUT:0 IN:7
            10'h008: begin w0<= -39; w1<= -76; w2<=   1; w3<= -45; w4<= -37; w5<= -18; w6<=  59; w7<=  70; w8<=  43; end // OUT:0 IN:8
            10'h009: begin w0<= 124; w1<=-121; w2<=  46; w3<= -94; w4<=  77; w5<= -48; w6<=  35; w7<= -79; w8<= -25; end // OUT:0 IN:9
            10'h00a: begin w0<=   3; w1<=-127; w2<= 125; w3<=   5; w4<= -75; w5<= -23; w6<=-125; w7<= -75; w8<=  92; end // OUT:0 IN:10
            10'h00b: begin w0<=  62; w1<=  17; w2<=  89; w3<= -85; w4<=  33; w5<=  73; w6<=  61; w7<=  99; w8<=-115; end // OUT:0 IN:11
            10'h00c: begin w0<= -34; w1<= -81; w2<=-114; w3<=  71; w4<=  77; w5<=  86; w6<= 123; w7<= 120; w8<=  61; end // OUT:0 IN:12
            10'h00d: begin w0<= -89; w1<=  84; w2<=  79; w3<= 108; w4<= -47; w5<= -18; w6<= -76; w7<=-105; w8<=  25; end // OUT:0 IN:13
            10'h00e: begin w0<=  88; w1<= 123; w2<=  59; w3<=  -5; w4<= 108; w5<= -88; w6<=  28; w7<=-114; w8<= -84; end // OUT:0 IN:14
            10'h00f: begin w0<= -64; w1<= -40; w2<= -58; w3<=-120; w4<= -41; w5<=   0; w6<= 107; w7<=   7; w8<=  87; end // OUT:0 IN:15
            10'h010: begin w0<= -66; w1<=  10; w2<= 114; w3<= -48; w4<=   7; w5<=  34; w6<=  34; w7<= -96; w8<=  -6; end // OUT:1 IN:0
            10'h011: begin w0<=-124; w1<= 105; w2<= 102; w3<= 121; w4<= -88; w5<=-101; w6<=   6; w7<=  72; w8<= -57; end // OUT:1 IN:1
            10'h012: begin w0<=-117; w1<=  33; w2<= -96; w3<= -81; w4<= 118; w5<=  22; w6<= -67; w7<=  87; w8<= -92; end // OUT:1 IN:2
            10'h013: begin w0<= -30; w1<=  43; w2<= -25; w3<=  85; w4<=  90; w5<= -94; w6<=  64; w7<=  98; w8<= -28; end // OUT:1 IN:3
            10'h014: begin w0<=  46; w1<=  77; w2<=   2; w3<=-128; w4<=-124; w5<=  89; w6<= 118; w7<= 126; w8<=  13; end // OUT:1 IN:4
            10'h015: begin w0<= -26; w1<=-102; w2<=   8; w3<=  78; w4<=-114; w5<= -39; w6<= -87; w7<=  -5; w8<=  76; end // OUT:1 IN:5
            10'h016: begin w0<=  50; w1<= -66; w2<= -33; w3<= 102; w4<= 112; w5<= -77; w6<= 124; w7<= -33; w8<=   3; end // OUT:1 IN:6
            10'h017: begin w0<=  93; w1<= 100; w2<=  22; w3<= 102; w4<= 108; w5<=  14; w6<=  42; w7<=-100; w8<= -93; end // OUT:1 IN:7
            10'h018: begin w0<=-116; w1<=  31; w2<= -58; w3<=  58; w4<= 114; w5<= -43; w6<=-101; w7<= -63; w8<=  41; end // OUT:1 IN:8
            10'h019: begin w0<= -84; w1<= -67; w2<=  56; w3<= 116; w4<=   5; w5<=-101; w6<=-101; w7<= -21; w8<= -85; end // OUT:1 IN:9
            10'h01a: begin w0<= -45; w1<= -99; w2<=  61; w3<= -54; w4<=  -1; w5<= 121; w6<= 118; w7<= -37; w8<=  88; end // OUT:1 IN:10
            10'h01b: begin w0<= 102; w1<=  61; w2<=  96; w3<=   0; w4<=  -8; w5<=-102; w6<=  61; w7<=  -8; w8<= -13; end // OUT:1 IN:11
            10'h01c: begin w0<=  76; w1<= 104; w2<=-126; w3<= -26; w4<=  69; w5<=  71; w6<=  26; w7<=   8; w8<= -67; end // OUT:1 IN:12
            10'h01d: begin w0<=  36; w1<=  96; w2<= -78; w3<= 105; w4<=  43; w5<=  23; w6<=  78; w7<= -70; w8<= -11; end // OUT:1 IN:13
            10'h01e: begin w0<=  31; w1<= -33; w2<=  87; w3<= 104; w4<=  51; w5<= -16; w6<= -67; w7<= 112; w8<=  57; end // OUT:1 IN:14
            10'h01f: begin w0<= -77; w1<=-117; w2<= 125; w3<= -90; w4<=   1; w5<=   2; w6<= -16; w7<= -28; w8<= -16; end // OUT:1 IN:15
            10'h020: begin w0<=  55; w1<= -48; w2<=  58; w3<= -16; w4<=-127; w5<=   1; w6<=  91; w7<= -75; w8<= -42; end // OUT:2 IN:0
            10'h021: begin w0<= 100; w1<=  95; w2<=  96; w3<=   0; w4<=  18; w5<=  -3; w6<=   1; w7<= -76; w8<=  43; end // OUT:2 IN:1
            10'h022: begin w0<=  89; w1<=  31; w2<=  69; w3<=  31; w4<= 118; w5<= -61; w6<=  54; w7<=  74; w8<=  55; end // OUT:2 IN:2
            10'h023: begin w0<=  -6; w1<=  16; w2<= 126; w3<= -91; w4<=-105; w5<= -60; w6<= -13; w7<= -31; w8<=  69; end // OUT:2 IN:3
            10'h024: begin w0<=  85; w1<=  10; w2<= 126; w3<= 111; w4<=  15; w5<= -32; w6<=  72; w7<=  -5; w8<=  58; end // OUT:2 IN:4
            10'h025: begin w0<= -59; w1<=  79; w2<= -36; w3<=-126; w4<=  19; w5<= 123; w6<=  58; w7<=  35; w8<=  18; end // OUT:2 IN:5
            10'h026: begin w0<= -39; w1<=  66; w2<= 126; w3<=  18; w4<=  19; w5<= -33; w6<=  70; w7<= -77; w8<= 104; end // OUT:2 IN:6
            10'h027: begin w0<=  32; w1<=  39; w2<=  -1; w3<= -90; w4<= -47; w5<= -25; w6<=   0; w7<=-118; w8<=  91; end // OUT:2 IN:7
            10'h028: begin w0<=  56; w1<=  88; w2<=  49; w3<=  22; w4<=  30; w5<=  93; w6<= -87; w7<= -30; w8<=-122; end // OUT:2 IN:8
            10'h029: begin w0<= 123; w1<=  15; w2<= -39; w3<= -17; w4<= 120; w5<= 115; w6<= -69; w7<= -16; w8<=-127; end // OUT:2 IN:9
            10'h02a: begin w0<=   0; w1<= -81; w2<= 125; w3<=  11; w4<=  68; w5<= -92; w6<=  31; w7<= 122; w8<= 118; end // OUT:2 IN:10
            10'h02b: begin w0<=-120; w1<= 104; w2<= -30; w3<=  18; w4<= -81; w5<=  79; w6<=   2; w7<=  19; w8<=  23; end // OUT:2 IN:11
            10'h02c: begin w0<= -75; w1<=  -9; w2<=  32; w3<=  23; w4<= -13; w5<= -54; w6<= -16; w7<=  71; w8<=  35; end // OUT:2 IN:12
            10'h02d: begin w0<=  37; w1<= -25; w2<= -45; w3<= 125; w4<=  98; w5<= -17; w6<= 125; w7<=  88; w8<= -30; end // OUT:2 IN:13
            10'h02e: begin w0<=  24; w1<= -36; w2<=  17; w3<=  -1; w4<= -19; w5<= -47; w6<=  65; w7<= -75; w8<=  34; end // OUT:2 IN:14
            10'h02f: begin w0<=  79; w1<=  60; w2<=  40; w3<=  99; w4<=  32; w5<= -61; w6<= -96; w7<=  13; w8<=-108; end // OUT:2 IN:15
            10'h030: begin w0<= -81; w1<=  19; w2<= 119; w3<=  -1; w4<=   7; w5<=   6; w6<=  66; w7<=  16; w8<=  -1; end // OUT:3 IN:0
            10'h031: begin w0<= -96; w1<=  47; w2<=  75; w3<=  58; w4<= -14; w5<=  85; w6<= -10; w7<=-107; w8<= 109; end // OUT:3 IN:1
            10'h032: begin w0<=  29; w1<= -91; w2<= 101; w3<= -20; w4<= -78; w5<=  53; w6<=-121; w7<=-102; w8<=-102; end // OUT:3 IN:2
            10'h033: begin w0<=  97; w1<=-108; w2<= -99; w3<= -32; w4<=-101; w5<= -18; w6<=  63; w7<=  96; w8<=  68; end // OUT:3 IN:3
            10'h034: begin w0<= 123; w1<= -68; w2<= -81; w3<=  18; w4<=-125; w5<= -94; w6<=  63; w7<= -80; w8<=-112; end // OUT:3 IN:4
            10'h035: begin w0<=  43; w1<=  91; w2<=  29; w3<=  92; w4<= -83; w5<= -12; w6<=-123; w7<= -30; w8<=  -5; end // OUT:3 IN:5
            10'h036: begin w0<= 104; w1<= -92; w2<=-105; w3<= -36; w4<= 112; w5<= -83; w6<=  52; w7<= -34; w8<= -30; end // OUT:3 IN:6
            10'h037: begin w0<=  59; w1<=  96; w2<= -13; w3<=  62; w4<= 124; w5<=  84; w6<=  31; w7<=  86; w8<=  32; end // OUT:3 IN:7
            10'h038: begin w0<= -62; w1<=  -1; w2<=-111; w3<=-104; w4<= 105; w5<=  94; w6<= -75; w7<= -71; w8<= -62; end // OUT:3 IN:8
            10'h039: begin w0<= -25; w1<=  45; w2<=-105; w3<= -15; w4<= -97; w5<=  46; w6<= -43; w7<=  22; w8<=  65; end // OUT:3 IN:9
            10'h03a: begin w0<=  -2; w1<=  26; w2<= 105; w3<=   1; w4<=  89; w5<=-112; w6<= -25; w7<=  32; w8<=   8; end // OUT:3 IN:10
            10'h03b: begin w0<= -86; w1<= 117; w2<=  47; w3<= -90; w4<=  92; w5<=  41; w6<= 118; w7<=-103; w8<= -30; end // OUT:3 IN:11
            10'h03c: begin w0<= -79; w1<=  24; w2<=  23; w3<=-116; w4<= -69; w5<= 121; w6<=   6; w7<= -72; w8<= -93; end // OUT:3 IN:12
            10'h03d: begin w0<=  44; w1<=-109; w2<= -64; w3<=-121; w4<= 109; w5<=  15; w6<=  13; w7<=  75; w8<= -14; end // OUT:3 IN:13
            10'h03e: begin w0<=  86; w1<=  14; w2<= -37; w3<= -31; w4<= -63; w5<= -97; w6<=  86; w7<=  62; w8<= -43; end // OUT:3 IN:14
            10'h03f: begin w0<= -78; w1<=  24; w2<=  57; w3<= -66; w4<=  61; w5<=  -4; w6<=  21; w7<= -71; w8<= -71; end // OUT:3 IN:15
            10'h040: begin w0<= -43; w1<= -80; w2<=  51; w3<=  41; w4<= -59; w5<=-114; w6<= -75; w7<= 106; w8<=  59; end // OUT:4 IN:0
            10'h041: begin w0<= -28; w1<=  96; w2<=-121; w3<= -76; w4<= -69; w5<= 107; w6<= -21; w7<=-124; w8<= -26; end // OUT:4 IN:1
            10'h042: begin w0<=  67; w1<=-123; w2<= -20; w3<=  95; w4<= -13; w5<= -35; w6<= -82; w7<= -30; w8<= -74; end // OUT:4 IN:2
            10'h043: begin w0<=  39; w1<= -77; w2<=  15; w3<=-116; w4<= -15; w5<=  -5; w6<= -23; w7<=  29; w8<=  18; end // OUT:4 IN:3
            10'h044: begin w0<=  16; w1<=  -9; w2<= -66; w3<=-110; w4<= -37; w5<= -71; w6<=  54; w7<= -39; w8<= 100; end // OUT:4 IN:4
            10'h045: begin w0<=  89; w1<= -12; w2<= -67; w3<=-106; w4<=  -2; w5<=   8; w6<=  11; w7<= 116; w8<=   0; end // OUT:4 IN:5
            10'h046: begin w0<= -71; w1<=  -7; w2<=-128; w3<= 110; w4<= -95; w5<= -33; w6<=  -3; w7<= -11; w8<= -81; end // OUT:4 IN:6
            10'h047: begin w0<= -40; w1<= 103; w2<= 108; w3<= -12; w4<=   0; w5<=-113; w6<=  60; w7<= 102; w8<=  63; end // OUT:4 IN:7
            10'h048: begin w0<=  62; w1<= -60; w2<=-107; w3<= -36; w4<= 118; w5<=  66; w6<= -53; w7<=  25; w8<=  15; end // OUT:4 IN:8
            10'h049: begin w0<=  50; w1<= 100; w2<= -43; w3<=  56; w4<=-100; w5<=  77; w6<=  91; w7<= -60; w8<= -82; end // OUT:4 IN:9
            10'h04a: begin w0<= 112; w1<= -35; w2<= 109; w3<=  61; w4<= 115; w5<=  68; w6<=  75; w7<=  15; w8<=  89; end // OUT:4 IN:10
            10'h04b: begin w0<=  89; w1<=  47; w2<= -44; w3<= -90; w4<= -29; w5<= -96; w6<= 125; w7<=  93; w8<= -28; end // OUT:4 IN:11
            10'h04c: begin w0<=-106; w1<= 121; w2<=-119; w3<= 117; w4<= -60; w5<= -29; w6<= -95; w7<=  51; w8<=  94; end // OUT:4 IN:12
            10'h04d: begin w0<=   9; w1<= 121; w2<=  18; w3<=  57; w4<= -33; w5<=-128; w6<= 119; w7<= -60; w8<= 108; end // OUT:4 IN:13
            10'h04e: begin w0<=-125; w1<=-113; w2<=-105; w3<= -49; w4<= 118; w5<=-127; w6<= 112; w7<=  91; w8<=  -1; end // OUT:4 IN:14
            10'h04f: begin w0<=  31; w1<=  90; w2<= -45; w3<=  23; w4<=  11; w5<=  49; w6<=  34; w7<=  -5; w8<= -96; end // OUT:4 IN:15
            10'h050: begin w0<=  32; w1<=  60; w2<=  50; w3<=  42; w4<= -28; w5<=-117; w6<= -62; w7<= -64; w8<=  32; end // OUT:5 IN:0
            10'h051: begin w0<=  39; w1<= -55; w2<= -86; w3<= -85; w4<=-100; w5<=  12; w6<=-117; w7<= -34; w8<= -83; end // OUT:5 IN:1
            10'h052: begin w0<=   1; w1<= 124; w2<= 114; w3<= 113; w4<= -94; w5<=  86; w6<= -48; w7<= -39; w8<=-121; end // OUT:5 IN:2
            10'h053: begin w0<= -36; w1<=  25; w2<=  73; w3<= -39; w4<= 125; w5<=  33; w6<= -14; w7<= -24; w8<=   6; end // OUT:5 IN:3
            10'h054: begin w0<=  67; w1<= -71; w2<= 116; w3<= -15; w4<= 108; w5<= -54; w6<=  28; w7<=  -9; w8<=  35; end // OUT:5 IN:4
            10'h055: begin w0<=  88; w1<=-108; w2<= 124; w3<= 120; w4<=  35; w5<=   9; w6<= -28; w7<=  72; w8<=  23; end // OUT:5 IN:5
            10'h056: begin w0<=  63; w1<=  98; w2<=  48; w3<= -30; w4<= 111; w5<= -93; w6<=  81; w7<= 112; w8<= 102; end // OUT:5 IN:6
            10'h057: begin w0<= -33; w1<=  23; w2<=  22; w3<=  61; w4<=  95; w5<= -92; w6<=-117; w7<= -16; w8<=  54; end // OUT:5 IN:7
            10'h058: begin w0<=-116; w1<=-106; w2<=  88; w3<= -30; w4<= -24; w5<= -99; w6<=-112; w7<= -16; w8<= -67; end // OUT:5 IN:8
            10'h059: begin w0<= -45; w1<= -17; w2<=  88; w3<= -43; w4<=  12; w5<=  58; w6<=-110; w7<=  48; w8<= -29; end // OUT:5 IN:9
            10'h05a: begin w0<=  11; w1<=  60; w2<= 104; w3<=  18; w4<= -53; w5<=-120; w6<=  70; w7<=-101; w8<=  77; end // OUT:5 IN:10
            10'h05b: begin w0<=  94; w1<=  -1; w2<= -77; w3<= -46; w4<= 121; w5<= -18; w6<=  15; w7<= -12; w8<= -60; end // OUT:5 IN:11
            10'h05c: begin w0<= -30; w1<=  11; w2<=-104; w3<=  51; w4<=  -6; w5<=  84; w6<=  99; w7<= -76; w8<=  22; end // OUT:5 IN:12
            10'h05d: begin w0<=  15; w1<= -72; w2<= -90; w3<= -20; w4<=  52; w5<= -87; w6<=  57; w7<=  38; w8<=  13; end // OUT:5 IN:13
            10'h05e: begin w0<=  94; w1<=  -7; w2<=   4; w3<=  34; w4<=  86; w5<=  92; w6<= 106; w7<= -54; w8<=  17; end // OUT:5 IN:14
            10'h05f: begin w0<= 110; w1<= -53; w2<=-120; w3<= -55; w4<=  57; w5<= 107; w6<=  16; w7<= 124; w8<= 101; end // OUT:5 IN:15
            10'h060: begin w0<=-122; w1<=  45; w2<=  12; w3<=  39; w4<=  41; w5<=   8; w6<=  49; w7<=-102; w8<=  -7; end // OUT:6 IN:0
            10'h061: begin w0<=  65; w1<=-124; w2<=-100; w3<=  36; w4<=  37; w5<= -46; w6<=   7; w7<= 111; w8<= -20; end // OUT:6 IN:1
            10'h062: begin w0<= -64; w1<= -43; w2<= 115; w3<=  16; w4<= 126; w5<= -58; w6<=  88; w7<= -84; w8<=   3; end // OUT:6 IN:2
            10'h063: begin w0<= -93; w1<= -59; w2<= 123; w3<=  30; w4<=-110; w5<=  60; w6<= -21; w7<=  53; w8<=  38; end // OUT:6 IN:3
            10'h064: begin w0<= -38; w1<=  73; w2<= -39; w3<=-110; w4<= -90; w5<=  -3; w6<=  66; w7<=  44; w8<=  12; end // OUT:6 IN:4
            10'h065: begin w0<= 113; w1<=  91; w2<=  -3; w3<= -71; w4<=  19; w5<=  91; w6<=  71; w7<= -68; w8<=  -2; end // OUT:6 IN:5
            10'h066: begin w0<= -24; w1<=  38; w2<=-128; w3<=   2; w4<=  76; w5<= -37; w6<=  61; w7<= 120; w8<=  62; end // OUT:6 IN:6
            10'h067: begin w0<= 123; w1<= -16; w2<=  24; w3<= -73; w4<=  32; w5<=  37; w6<= -12; w7<=   5; w8<= -71; end // OUT:6 IN:7
            10'h068: begin w0<= -85; w1<=  44; w2<=  31; w3<=  44; w4<= -68; w5<= -82; w6<=  20; w7<= -49; w8<= -11; end // OUT:6 IN:8
            10'h069: begin w0<=  84; w1<=  74; w2<= 123; w3<= 100; w4<=  35; w5<=  98; w6<=  18; w7<=-109; w8<=  56; end // OUT:6 IN:9
            10'h06a: begin w0<=  17; w1<= -82; w2<= 104; w3<= -80; w4<=-115; w5<=  14; w6<=  30; w7<=-128; w8<= -12; end // OUT:6 IN:10
            10'h06b: begin w0<= -75; w1<= -11; w2<=-126; w3<=  15; w4<=  86; w5<=  56; w6<=  74; w7<=-117; w8<= -55; end // OUT:6 IN:11
            10'h06c: begin w0<=  95; w1<=-113; w2<=  71; w3<= -27; w4<=  75; w5<=  23; w6<=  27; w7<= -12; w8<=-121; end // OUT:6 IN:12
            10'h06d: begin w0<=  -7; w1<= -37; w2<=  35; w3<= -39; w4<=   7; w5<=  57; w6<= -69; w7<=  49; w8<=-101; end // OUT:6 IN:13
            10'h06e: begin w0<=  91; w1<= -28; w2<= -88; w3<=  99; w4<=  63; w5<=  26; w6<= 117; w7<=  62; w8<=  16; end // OUT:6 IN:14
            10'h06f: begin w0<=  72; w1<=  32; w2<= 116; w3<=  83; w4<=  76; w5<=  91; w6<= 111; w7<=  28; w8<=  12; end // OUT:6 IN:15
            10'h070: begin w0<= -83; w1<= -94; w2<= 124; w3<=   5; w4<= -47; w5<= -14; w6<=  68; w7<= -82; w8<=  24; end // OUT:7 IN:0
            10'h071: begin w0<=  65; w1<=-119; w2<= -73; w3<= -99; w4<= 113; w5<= 122; w6<= -20; w7<=-124; w8<= -10; end // OUT:7 IN:1
            10'h072: begin w0<= 119; w1<= -96; w2<= -11; w3<= -64; w4<=  17; w5<=  95; w6<= 110; w7<=  48; w8<=-118; end // OUT:7 IN:2
            10'h073: begin w0<= -44; w1<=-103; w2<= -66; w3<=  88; w4<= -43; w5<= -70; w6<=-102; w7<=  48; w8<=  76; end // OUT:7 IN:3
            10'h074: begin w0<=  32; w1<= -31; w2<= -24; w3<= -30; w4<= 126; w5<=   0; w6<=  20; w7<= 111; w8<= -74; end // OUT:7 IN:4
            10'h075: begin w0<=-123; w1<=  91; w2<=  80; w3<=  68; w4<= -34; w5<=   4; w6<= -27; w7<=-126; w8<=  52; end // OUT:7 IN:5
            10'h076: begin w0<=-106; w1<= 100; w2<= -76; w3<=  36; w4<=  73; w5<=  73; w6<= -46; w7<=  16; w8<= -44; end // OUT:7 IN:6
            10'h077: begin w0<= -51; w1<=  72; w2<= -19; w3<=-128; w4<= -78; w5<=  44; w6<=  76; w7<=-125; w8<=  61; end // OUT:7 IN:7
            10'h078: begin w0<=  64; w1<= -16; w2<= 103; w3<= -97; w4<= -95; w5<= -37; w6<= -34; w7<= -57; w8<= -90; end // OUT:7 IN:8
            10'h079: begin w0<=  25; w1<= 121; w2<=  33; w3<=  53; w4<= -11; w5<=-126; w6<=  -6; w7<= -79; w8<=-117; end // OUT:7 IN:9
            10'h07a: begin w0<=  64; w1<= -75; w2<= 107; w3<=   4; w4<=  93; w5<=  93; w6<= 122; w7<= -72; w8<=  16; end // OUT:7 IN:10
            10'h07b: begin w0<= -17; w1<= 126; w2<= -82; w3<=  22; w4<=  78; w5<= 100; w6<= -44; w7<=  13; w8<= -63; end // OUT:7 IN:11
            10'h07c: begin w0<= -54; w1<=  50; w2<= -26; w3<=  37; w4<=  63; w5<= 123; w6<=  97; w7<= -91; w8<= -79; end // OUT:7 IN:12
            10'h07d: begin w0<= -31; w1<= -47; w2<= -99; w3<= -50; w4<= -38; w5<=  50; w6<=  62; w7<=  97; w8<= -77; end // OUT:7 IN:13
            10'h07e: begin w0<= 120; w1<=  37; w2<=  96; w3<=  87; w4<= -50; w5<= 123; w6<= -99; w7<= 118; w8<= -23; end // OUT:7 IN:14
            10'h07f: begin w0<= -78; w1<= -48; w2<=   4; w3<=-100; w4<=   3; w5<=   9; w6<=  55; w7<=  16; w8<= -55; end // OUT:7 IN:15
            10'h080: begin w0<=-112; w1<= 123; w2<= -45; w3<=  87; w4<= -60; w5<= -95; w6<=-123; w7<= -76; w8<=  65; end // OUT:8 IN:0
            10'h081: begin w0<=  76; w1<=  -3; w2<= 106; w3<= -86; w4<= 111; w5<=  74; w6<= -14; w7<= -18; w8<= 120; end // OUT:8 IN:1
            10'h082: begin w0<=  22; w1<=  54; w2<= -49; w3<= -34; w4<=  74; w5<= -11; w6<=  15; w7<=-121; w8<=   3; end // OUT:8 IN:2
            10'h083: begin w0<= -25; w1<=   3; w2<=  55; w3<=-104; w4<=  66; w5<= -33; w6<=  66; w7<=  26; w8<= -36; end // OUT:8 IN:3
            10'h084: begin w0<=  31; w1<=  49; w2<= -68; w3<=  -7; w4<= -78; w5<=  18; w6<=-108; w7<=-124; w8<=  81; end // OUT:8 IN:4
            10'h085: begin w0<= -37; w1<=  41; w2<= -68; w3<=-107; w4<=  20; w5<= -59; w6<=-128; w7<=   4; w8<= 104; end // OUT:8 IN:5
            10'h086: begin w0<=-117; w1<= -39; w2<= -83; w3<= -95; w4<=  48; w5<= -51; w6<=  89; w7<= -84; w8<=  26; end // OUT:8 IN:6
            10'h087: begin w0<= -56; w1<=-103; w2<= 120; w3<= -82; w4<=  -8; w5<=  85; w6<= 110; w7<= -73; w8<= -35; end // OUT:8 IN:7
            10'h088: begin w0<= -22; w1<= -66; w2<= -81; w3<= -68; w4<= -48; w5<=-103; w6<= -93; w7<=-128; w8<=-121; end // OUT:8 IN:8
            10'h089: begin w0<= -16; w1<= -30; w2<= 124; w3<=  51; w4<=  78; w5<= -82; w6<=  -2; w7<= -73; w8<=  85; end // OUT:8 IN:9
            10'h08a: begin w0<=-115; w1<=  89; w2<=-101; w3<=  86; w4<= -51; w5<=  87; w6<=   1; w7<= -20; w8<=  25; end // OUT:8 IN:10
            10'h08b: begin w0<=-115; w1<=  58; w2<= -73; w3<= -14; w4<=-122; w5<=-126; w6<= -18; w7<=  22; w8<= 109; end // OUT:8 IN:11
            10'h08c: begin w0<= -22; w1<= 110; w2<= 123; w3<= 108; w4<=-111; w5<= 121; w6<= -91; w7<=  98; w8<= -14; end // OUT:8 IN:12
            10'h08d: begin w0<=-114; w1<=  63; w2<=  88; w3<= -10; w4<= 100; w5<=-101; w6<=  73; w7<= -90; w8<=  56; end // OUT:8 IN:13
            10'h08e: begin w0<=-112; w1<= 102; w2<= -43; w3<=  89; w4<=  -3; w5<= -85; w6<=-104; w7<=  16; w8<=-116; end // OUT:8 IN:14
            10'h08f: begin w0<=  83; w1<=-104; w2<= -61; w3<=   9; w4<= -62; w5<= 104; w6<= -20; w7<=  17; w8<= -18; end // OUT:8 IN:15
            10'h090: begin w0<=  99; w1<= -18; w2<=  85; w3<= -95; w4<= -18; w5<=-121; w6<=  39; w7<= -16; w8<= 107; end // OUT:9 IN:0
            10'h091: begin w0<= -46; w1<= -87; w2<=  40; w3<= -28; w4<=-123; w5<=  51; w6<=-103; w7<= -65; w8<=  97; end // OUT:9 IN:1
            10'h092: begin w0<=  58; w1<=  55; w2<= -70; w3<= -20; w4<=  69; w5<= 100; w6<=  -8; w7<= -96; w8<=  52; end // OUT:9 IN:2
            10'h093: begin w0<=  21; w1<=-108; w2<=  69; w3<= -59; w4<= 118; w5<= -17; w6<=-125; w7<= -35; w8<= -54; end // OUT:9 IN:3
            10'h094: begin w0<=  61; w1<= -67; w2<= -35; w3<= -34; w4<=  23; w5<= -74; w6<=   8; w7<= 118; w8<=   2; end // OUT:9 IN:4
            10'h095: begin w0<= 114; w1<= -98; w2<= -89; w3<= 100; w4<= -93; w5<=  23; w6<=  94; w7<=-123; w8<= -63; end // OUT:9 IN:5
            10'h096: begin w0<=  83; w1<=  91; w2<= -54; w3<=-125; w4<= -50; w5<=   5; w6<= -11; w7<= -16; w8<= -35; end // OUT:9 IN:6
            10'h097: begin w0<= 119; w1<= 101; w2<=  50; w3<= -67; w4<=  56; w5<=  65; w6<= -50; w7<=  74; w8<=   7; end // OUT:9 IN:7
            10'h098: begin w0<=-103; w1<=  50; w2<=  44; w3<= -85; w4<=   4; w5<= -59; w6<=  25; w7<= -11; w8<= -61; end // OUT:9 IN:8
            10'h099: begin w0<=-110; w1<=  83; w2<=  96; w3<=-109; w4<= -16; w5<=  11; w6<= -82; w7<=-128; w8<= -39; end // OUT:9 IN:9
            10'h09a: begin w0<=  13; w1<= -65; w2<= -91; w3<= -92; w4<=  -3; w5<=  10; w6<= 126; w7<= -29; w8<= -52; end // OUT:9 IN:10
            10'h09b: begin w0<= 106; w1<=-126; w2<=  32; w3<=   5; w4<=  49; w5<= 119; w6<=-119; w7<=-124; w8<=  22; end // OUT:9 IN:11
            10'h09c: begin w0<=   9; w1<=  43; w2<=   1; w3<=-116; w4<=  39; w5<=   1; w6<= -45; w7<= -64; w8<= -66; end // OUT:9 IN:12
            10'h09d: begin w0<= -28; w1<= -56; w2<=-112; w3<=-120; w4<=  74; w5<=  14; w6<=  23; w7<= -91; w8<= 118; end // OUT:9 IN:13
            10'h09e: begin w0<=  34; w1<= -35; w2<= -34; w3<= -80; w4<= -60; w5<= -67; w6<=  59; w7<= 107; w8<=  49; end // OUT:9 IN:14
            10'h09f: begin w0<= -51; w1<= -12; w2<=  -9; w3<=  74; w4<=   8; w5<=  33; w6<= -53; w7<=  98; w8<= -94; end // OUT:9 IN:15
            10'h0a0: begin w0<=-128; w1<= -89; w2<= -65; w3<=  21; w4<= -69; w5<= -65; w6<= -36; w7<= -57; w8<=-118; end // OUT:10 IN:0
            10'h0a1: begin w0<= -24; w1<= 100; w2<=-115; w3<= -69; w4<= -99; w5<= -94; w6<=  84; w7<=  36; w8<=-124; end // OUT:10 IN:1
            10'h0a2: begin w0<= -46; w1<=  -6; w2<= -51; w3<=  25; w4<= -67; w5<=   3; w6<= -40; w7<= 108; w8<= -87; end // OUT:10 IN:2
            10'h0a3: begin w0<= -40; w1<=  17; w2<= -89; w3<= -57; w4<= -90; w5<= -25; w6<=-115; w7<= -97; w8<=  50; end // OUT:10 IN:3
            10'h0a4: begin w0<=  -4; w1<=  37; w2<= -32; w3<=-106; w4<= -66; w5<=  14; w6<=  96; w7<=  24; w8<=  16; end // OUT:10 IN:4
            10'h0a5: begin w0<=  96; w1<= 110; w2<= 118; w3<=  65; w4<=  77; w5<= -76; w6<= -25; w7<= -25; w8<=  50; end // OUT:10 IN:5
            10'h0a6: begin w0<= -90; w1<=  50; w2<=  69; w3<=   5; w4<= -62; w5<=   6; w6<=  50; w7<=  71; w8<= -87; end // OUT:10 IN:6
            10'h0a7: begin w0<=  63; w1<= 115; w2<=-114; w3<= -18; w4<=  28; w5<= -96; w6<= 115; w7<=  93; w8<= 102; end // OUT:10 IN:7
            10'h0a8: begin w0<=  26; w1<=  35; w2<=  28; w3<= -91; w4<=  56; w5<= -32; w6<= 124; w7<= 100; w8<=  26; end // OUT:10 IN:8
            10'h0a9: begin w0<=  54; w1<= -96; w2<= 125; w3<=  67; w4<= -43; w5<= -63; w6<=-119; w7<=-124; w8<=  -6; end // OUT:10 IN:9
            10'h0aa: begin w0<= -55; w1<= -32; w2<= -11; w3<= -91; w4<=  12; w5<=  30; w6<= -82; w7<=  99; w8<= -20; end // OUT:10 IN:10
            10'h0ab: begin w0<=  87; w1<=  51; w2<=  55; w3<=-114; w4<=  28; w5<=   7; w6<=-124; w7<=  28; w8<= -82; end // OUT:10 IN:11
            10'h0ac: begin w0<= -61; w1<= -53; w2<=  44; w3<=   1; w4<=  26; w5<= -34; w6<= -14; w7<= 114; w8<=  35; end // OUT:10 IN:12
            10'h0ad: begin w0<= -93; w1<=-103; w2<= -86; w3<=-102; w4<= -60; w5<=  19; w6<=-118; w7<= 125; w8<= -55; end // OUT:10 IN:13
            10'h0ae: begin w0<= -25; w1<= -91; w2<=   5; w3<=  71; w4<=-106; w5<= -82; w6<= -39; w7<= -83; w8<= -22; end // OUT:10 IN:14
            10'h0af: begin w0<=  11; w1<=  89; w2<=  12; w3<= -25; w4<=  61; w5<=  81; w6<=  88; w7<=  96; w8<= -18; end // OUT:10 IN:15
            10'h0b0: begin w0<= -25; w1<= -69; w2<=  42; w3<=  75; w4<= 107; w5<= -29; w6<= 111; w7<= -61; w8<=   4; end // OUT:11 IN:0
            10'h0b1: begin w0<=  -9; w1<= -92; w2<= -57; w3<=  -2; w4<= -23; w5<= 112; w6<= -37; w7<= -98; w8<=  -7; end // OUT:11 IN:1
            10'h0b2: begin w0<=   8; w1<= 117; w2<= -78; w3<=-100; w4<=  77; w5<= -89; w6<= -88; w7<=  85; w8<=-118; end // OUT:11 IN:2
            10'h0b3: begin w0<=  22; w1<=-128; w2<= -83; w3<= -28; w4<=  20; w5<= -39; w6<= -19; w7<=  35; w8<=  53; end // OUT:11 IN:3
            10'h0b4: begin w0<=  86; w1<= -72; w2<=-128; w3<= -66; w4<=  53; w5<= -74; w6<= -14; w7<=  39; w8<=  14; end // OUT:11 IN:4
            10'h0b5: begin w0<=  20; w1<=  46; w2<=  72; w3<= -76; w4<=   8; w5<=  73; w6<=  51; w7<= -72; w8<= -12; end // OUT:11 IN:5
            10'h0b6: begin w0<=  25; w1<=  40; w2<= -94; w3<= -66; w4<= 115; w5<=-104; w6<= -39; w7<= -54; w8<= -91; end // OUT:11 IN:6
            10'h0b7: begin w0<=   1; w1<=   6; w2<=  81; w3<=  90; w4<=  33; w5<= -38; w6<=-112; w7<=  -1; w8<=  42; end // OUT:11 IN:7
            10'h0b8: begin w0<=  58; w1<= -21; w2<= 122; w3<=  50; w4<=  53; w5<=  23; w6<=-104; w7<=  70; w8<=  51; end // OUT:11 IN:8
            10'h0b9: begin w0<=  69; w1<= 116; w2<= -41; w3<=  32; w4<=  48; w5<=-100; w6<= -66; w7<= 106; w8<=  21; end // OUT:11 IN:9
            10'h0ba: begin w0<=  25; w1<=  27; w2<= -15; w3<=  84; w4<= -80; w5<=  70; w6<= -48; w7<= -45; w8<= -24; end // OUT:11 IN:10
            10'h0bb: begin w0<=  48; w1<=  19; w2<= -11; w3<= -43; w4<=  91; w5<= -66; w6<=  60; w7<= -25; w8<= -80; end // OUT:11 IN:11
            10'h0bc: begin w0<= -58; w1<=-128; w2<=  95; w3<=  12; w4<=  93; w5<=  86; w6<=  50; w7<=  -6; w8<=  55; end // OUT:11 IN:12
            10'h0bd: begin w0<=  82; w1<= -67; w2<= -97; w3<=  29; w4<=-100; w5<= -80; w6<=  44; w7<=  92; w8<= -99; end // OUT:11 IN:13
            10'h0be: begin w0<=  15; w1<=  39; w2<=-110; w3<=-111; w4<=-128; w5<= -51; w6<= -14; w7<=  46; w8<= 113; end // OUT:11 IN:14
            10'h0bf: begin w0<=  65; w1<= 117; w2<=  91; w3<= -16; w4<= -15; w5<=  93; w6<=  37; w7<=  50; w8<= -66; end // OUT:11 IN:15
            10'h0c0: begin w0<=   3; w1<=   0; w2<=-121; w3<=  28; w4<= -74; w5<= -26; w6<=   2; w7<= -97; w8<=-119; end // OUT:12 IN:0
            10'h0c1: begin w0<=  73; w1<=  82; w2<= -19; w3<=  33; w4<=  -5; w5<=  96; w6<= -42; w7<= -74; w8<=  91; end // OUT:12 IN:1
            10'h0c2: begin w0<= -97; w1<=  49; w2<=   6; w3<= -36; w4<=-121; w5<= -64; w6<= -72; w7<= 118; w8<= -62; end // OUT:12 IN:2
            10'h0c3: begin w0<=  87; w1<=  86; w2<=  58; w3<= 126; w4<= 124; w5<= -57; w6<= -75; w7<= 120; w8<= 110; end // OUT:12 IN:3
            10'h0c4: begin w0<= 100; w1<= -62; w2<= -78; w3<= -32; w4<= -37; w5<= 110; w6<=-121; w7<=  33; w8<= -94; end // OUT:12 IN:4
            10'h0c5: begin w0<= -33; w1<= -41; w2<= -51; w3<= -97; w4<=  -9; w5<= -83; w6<= 106; w7<=  15; w8<=  67; end // OUT:12 IN:5
            10'h0c6: begin w0<= 115; w1<=  36; w2<=  53; w3<=  84; w4<=  13; w5<=  94; w6<= -74; w7<=  47; w8<=  81; end // OUT:12 IN:6
            10'h0c7: begin w0<=-122; w1<= -55; w2<=-122; w3<=  32; w4<=  22; w5<= -44; w6<=  18; w7<= -17; w8<=  -4; end // OUT:12 IN:7
            10'h0c8: begin w0<=  18; w1<= -93; w2<=-100; w3<=  59; w4<= -47; w5<=-127; w6<=   0; w7<= -82; w8<=  68; end // OUT:12 IN:8
            10'h0c9: begin w0<=  19; w1<=-118; w2<= 105; w3<= 126; w4<=   1; w5<=  66; w6<=  86; w7<= -10; w8<=  11; end // OUT:12 IN:9
            10'h0ca: begin w0<=-109; w1<=-124; w2<= -92; w3<=  37; w4<=  93; w5<=   8; w6<=  97; w7<= -76; w8<=  43; end // OUT:12 IN:10
            10'h0cb: begin w0<= -30; w1<= 115; w2<= 121; w3<= -43; w4<= -21; w5<=-105; w6<= -48; w7<=  73; w8<=  29; end // OUT:12 IN:11
            10'h0cc: begin w0<=  -9; w1<= -70; w2<= 109; w3<=  86; w4<=  -1; w5<=  95; w6<=  80; w7<= -15; w8<= -14; end // OUT:12 IN:12
            10'h0cd: begin w0<=  80; w1<=-115; w2<=-120; w3<= -89; w4<=  65; w5<= 108; w6<=-104; w7<= -26; w8<=  72; end // OUT:12 IN:13
            10'h0ce: begin w0<= 117; w1<=-107; w2<= 106; w3<= 109; w4<=-125; w5<=  25; w6<=  57; w7<=-100; w8<= -20; end // OUT:12 IN:14
            10'h0cf: begin w0<= -31; w1<=  86; w2<= -92; w3<= -54; w4<= -59; w5<=  17; w6<=  -1; w7<= -44; w8<= -87; end // OUT:12 IN:15
            10'h0d0: begin w0<= -29; w1<= -88; w2<=  37; w3<= -95; w4<=-112; w5<=  36; w6<=  24; w7<= 101; w8<=  -7; end // OUT:13 IN:0
            10'h0d1: begin w0<= -53; w1<= -42; w2<= -12; w3<= -23; w4<= -43; w5<=  84; w6<=-102; w7<= -72; w8<= -98; end // OUT:13 IN:1
            10'h0d2: begin w0<=   5; w1<=  90; w2<=  39; w3<= -31; w4<=-117; w5<= 108; w6<= 120; w7<= -76; w8<=  70; end // OUT:13 IN:2
            10'h0d3: begin w0<=   9; w1<=  44; w2<=  16; w3<=  25; w4<=  84; w5<=  91; w6<=  61; w7<=  -7; w8<= -83; end // OUT:13 IN:3
            10'h0d4: begin w0<= -65; w1<=   1; w2<= 123; w3<= -75; w4<= -22; w5<=  64; w6<= -78; w7<=  52; w8<= -93; end // OUT:13 IN:4
            10'h0d5: begin w0<= -14; w1<=-103; w2<=-100; w3<=  20; w4<=-118; w5<= -89; w6<=-118; w7<=  35; w8<= -16; end // OUT:13 IN:5
            10'h0d6: begin w0<=  58; w1<= -90; w2<= 103; w3<=  98; w4<= -75; w5<= -31; w6<= -74; w7<= -18; w8<=  23; end // OUT:13 IN:6
            10'h0d7: begin w0<= 117; w1<=  21; w2<= -60; w3<= -73; w4<= -96; w5<= 121; w6<= -93; w7<= 110; w8<=  19; end // OUT:13 IN:7
            10'h0d8: begin w0<=  82; w1<=  98; w2<= 115; w3<= 106; w4<= -48; w5<=  61; w6<= 122; w7<= -20; w8<= 106; end // OUT:13 IN:8
            10'h0d9: begin w0<=  97; w1<=  72; w2<=  25; w3<=  65; w4<= 116; w5<= -56; w6<=  72; w7<= -89; w8<=-112; end // OUT:13 IN:9
            10'h0da: begin w0<=   0; w1<=  88; w2<= -68; w3<=  42; w4<= -25; w5<= -87; w6<=-104; w7<= -90; w8<= -94; end // OUT:13 IN:10
            10'h0db: begin w0<=   2; w1<= 113; w2<= 100; w3<= -21; w4<=  43; w5<=  50; w6<=  93; w7<= -27; w8<= -31; end // OUT:13 IN:11
            10'h0dc: begin w0<=-117; w1<=-110; w2<= -28; w3<= -85; w4<=  58; w5<= 122; w6<= -80; w7<=  60; w8<=-112; end // OUT:13 IN:12
            10'h0dd: begin w0<= -55; w1<= -72; w2<= -74; w3<= 112; w4<= -82; w5<=-117; w6<= -67; w7<= -49; w8<=  87; end // OUT:13 IN:13
            10'h0de: begin w0<= -46; w1<=-121; w2<=  94; w3<=  20; w4<= -48; w5<=  86; w6<= 100; w7<= -11; w8<=  79; end // OUT:13 IN:14
            10'h0df: begin w0<=  69; w1<=  71; w2<=-104; w3<=  81; w4<= -40; w5<=-117; w6<=  14; w7<= -70; w8<=  25; end // OUT:13 IN:15
            10'h0e0: begin w0<= 104; w1<= -20; w2<=-103; w3<= -82; w4<= -97; w5<=-119; w6<=-113; w7<=  70; w8<=  16; end // OUT:14 IN:0
            10'h0e1: begin w0<=  22; w1<=-103; w2<=  84; w3<= -43; w4<= 121; w5<=   6; w6<=-115; w7<= -50; w8<= -12; end // OUT:14 IN:1
            10'h0e2: begin w0<=-122; w1<=   8; w2<= -14; w3<=  47; w4<= -57; w5<= 113; w6<= -70; w7<=  86; w8<=  92; end // OUT:14 IN:2
            10'h0e3: begin w0<= -47; w1<=  94; w2<=  93; w3<= -13; w4<=  38; w5<=  98; w6<=  17; w7<=  58; w8<= 105; end // OUT:14 IN:3
            10'h0e4: begin w0<= -26; w1<=-112; w2<=-115; w3<=  30; w4<=  23; w5<=  98; w6<= -21; w7<=  59; w8<= -84; end // OUT:14 IN:4
            10'h0e5: begin w0<= -31; w1<=   2; w2<= -92; w3<=  42; w4<=  39; w5<=  89; w6<=  54; w7<=  86; w8<= -21; end // OUT:14 IN:5
            10'h0e6: begin w0<= -90; w1<=-114; w2<=  -9; w3<= 112; w4<=-125; w5<= -36; w6<=  85; w7<=  24; w8<=  12; end // OUT:14 IN:6
            10'h0e7: begin w0<=  81; w1<=  32; w2<=-113; w3<= 108; w4<=  41; w5<= -21; w6<=  -3; w7<=  65; w8<= -74; end // OUT:14 IN:7
            10'h0e8: begin w0<=  98; w1<=  41; w2<= -95; w3<=  29; w4<= 122; w5<= 118; w6<=-116; w7<=  12; w8<=-111; end // OUT:14 IN:8
            10'h0e9: begin w0<=  31; w1<= -33; w2<=  98; w3<=  -6; w4<= -90; w5<= -83; w6<= 115; w7<=-100; w8<=  61; end // OUT:14 IN:9
            10'h0ea: begin w0<= 112; w1<=  92; w2<= -67; w3<= 116; w4<= 107; w5<=  56; w6<=-113; w7<=  55; w8<= 107; end // OUT:14 IN:10
            10'h0eb: begin w0<= 110; w1<=  -8; w2<=-119; w3<=  29; w4<=  24; w5<= 126; w6<= -26; w7<= -45; w8<=   4; end // OUT:14 IN:11
            10'h0ec: begin w0<= -64; w1<=  93; w2<=  48; w3<=-126; w4<=  44; w5<=  13; w6<=  -9; w7<=  29; w8<= 113; end // OUT:14 IN:12
            10'h0ed: begin w0<= -61; w1<=  17; w2<=  61; w3<= -92; w4<=  24; w5<=  47; w6<=  64; w7<=  52; w8<= 109; end // OUT:14 IN:13
            10'h0ee: begin w0<=  78; w1<= -56; w2<=  14; w3<= -80; w4<=  -8; w5<= -41; w6<=  67; w7<=  11; w8<=  58; end // OUT:14 IN:14
            10'h0ef: begin w0<= 121; w1<= -92; w2<= -68; w3<= 100; w4<=  42; w5<=  -5; w6<=  69; w7<= -90; w8<=  55; end // OUT:14 IN:15
            10'h0f0: begin w0<= -66; w1<= -83; w2<= -41; w3<=-118; w4<= -67; w5<= -52; w6<=  97; w7<=  24; w8<=  70; end // OUT:15 IN:0
            10'h0f1: begin w0<= -77; w1<=-125; w2<= -70; w3<= -57; w4<=  19; w5<= -36; w6<= -66; w7<= -75; w8<= -12; end // OUT:15 IN:1
            10'h0f2: begin w0<= 114; w1<= 108; w2<= -19; w3<= -55; w4<= -22; w5<=  97; w6<= -72; w7<=  89; w8<=  40; end // OUT:15 IN:2
            10'h0f3: begin w0<= 112; w1<= 121; w2<=-126; w3<=  -9; w4<=-123; w5<=-124; w6<=-124; w7<= -75; w8<= -82; end // OUT:15 IN:3
            10'h0f4: begin w0<=  86; w1<=  48; w2<=-120; w3<= -30; w4<=-109; w5<=  -7; w6<= 112; w7<= -68; w8<=  -6; end // OUT:15 IN:4
            10'h0f5: begin w0<= 105; w1<=  34; w2<=  49; w3<= -47; w4<= -67; w5<=  16; w6<=  87; w7<=-126; w8<=  31; end // OUT:15 IN:5
            10'h0f6: begin w0<=  98; w1<= 101; w2<=-116; w3<=  -9; w4<=  -4; w5<= 110; w6<= -40; w7<= -56; w8<= -61; end // OUT:15 IN:6
            10'h0f7: begin w0<=  13; w1<= -28; w2<= -31; w3<=-118; w4<= -24; w5<=  55; w6<= -62; w7<=  -6; w8<=  91; end // OUT:15 IN:7
            10'h0f8: begin w0<=-100; w1<=   8; w2<=  66; w3<=  24; w4<=  97; w5<= -53; w6<=  41; w7<=-120; w8<=  78; end // OUT:15 IN:8
            10'h0f9: begin w0<= -89; w1<=-104; w2<=-124; w3<=  10; w4<=  58; w5<=  97; w6<=  87; w7<=  -5; w8<=  78; end // OUT:15 IN:9
            10'h0fa: begin w0<= -91; w1<= -57; w2<= 122; w3<=   4; w4<=  47; w5<= -39; w6<=  17; w7<=  69; w8<= -92; end // OUT:15 IN:10
            10'h0fb: begin w0<= -69; w1<=  47; w2<=  76; w3<=-101; w4<=  68; w5<=  76; w6<= -48; w7<= -15; w8<= -89; end // OUT:15 IN:11
            10'h0fc: begin w0<= -84; w1<=  95; w2<= -67; w3<= -36; w4<= -14; w5<=  57; w6<= -62; w7<= -73; w8<= -89; end // OUT:15 IN:12
            10'h0fd: begin w0<= -31; w1<= -89; w2<= -38; w3<=  76; w4<= 108; w5<= -96; w6<=-123; w7<=  87; w8<=  18; end // OUT:15 IN:13
            10'h0fe: begin w0<= -49; w1<=  39; w2<= -37; w3<= -32; w4<= -70; w5<= -70; w6<= -81; w7<=  40; w8<=-116; end // OUT:15 IN:14
            10'h0ff: begin w0<= -22; w1<= -84; w2<= -40; w3<=  52; w4<=  41; w5<= -29; w6<=  62; w7<=  26; w8<=  37; end // OUT:15 IN:15
            10'h100: begin w0<=  59; w1<=-122; w2<=   4; w3<= 106; w4<= -84; w5<= -71; w6<= 120; w7<= 114; w8<= -98; end // OUT:16 IN:0
            10'h101: begin w0<=-106; w1<=  41; w2<=   9; w3<=  31; w4<= -22; w5<=  52; w6<=  29; w7<= -90; w8<=  30; end // OUT:16 IN:1
            10'h102: begin w0<= -47; w1<= -29; w2<=-127; w3<=  77; w4<= -52; w5<=  92; w6<=-117; w7<= -90; w8<=  65; end // OUT:16 IN:2
            10'h103: begin w0<=  95; w1<=-116; w2<= -83; w3<=  26; w4<= -16; w5<= 104; w6<=-112; w7<= -25; w8<=  94; end // OUT:16 IN:3
            10'h104: begin w0<= -31; w1<=  59; w2<=  63; w3<= -41; w4<= -20; w5<=  34; w6<= 111; w7<= -59; w8<=  82; end // OUT:16 IN:4
            10'h105: begin w0<=  29; w1<=  70; w2<= -55; w3<= 104; w4<=  95; w5<=  97; w6<= -66; w7<=  27; w8<= -69; end // OUT:16 IN:5
            10'h106: begin w0<= -50; w1<=  93; w2<= -92; w3<=  92; w4<=-107; w5<=  67; w6<=  19; w7<= -33; w8<=  99; end // OUT:16 IN:6
            10'h107: begin w0<= 113; w1<= -61; w2<=  90; w3<=  63; w4<=-112; w5<=-117; w6<=  21; w7<=  16; w8<=   9; end // OUT:16 IN:7
            10'h108: begin w0<= -11; w1<=  64; w2<=-107; w3<=  89; w4<=  -9; w5<= 122; w6<=  81; w7<= -79; w8<=-115; end // OUT:16 IN:8
            10'h109: begin w0<=  63; w1<=  46; w2<=-100; w3<=  75; w4<=  35; w5<= 122; w6<=  98; w7<=  51; w8<=  -4; end // OUT:16 IN:9
            10'h10a: begin w0<=  75; w1<=-122; w2<=-100; w3<=  10; w4<= -96; w5<=   5; w6<= -18; w7<= -50; w8<=  31; end // OUT:16 IN:10
            10'h10b: begin w0<=  50; w1<=  74; w2<= -71; w3<=  86; w4<=-103; w5<=  97; w6<=  45; w7<=  97; w8<=-100; end // OUT:16 IN:11
            10'h10c: begin w0<=-125; w1<=  80; w2<= -30; w3<=  12; w4<= 104; w5<= -90; w6<=-114; w7<= -10; w8<=-100; end // OUT:16 IN:12
            10'h10d: begin w0<=  28; w1<= -54; w2<= -13; w3<= -97; w4<=   1; w5<=  46; w6<=  77; w7<= -45; w8<=-107; end // OUT:16 IN:13
            10'h10e: begin w0<=  74; w1<=-102; w2<=  66; w3<= -48; w4<=  -3; w5<= 107; w6<=  55; w7<= -37; w8<=  92; end // OUT:16 IN:14
            10'h10f: begin w0<=-108; w1<= -82; w2<=  79; w3<= -28; w4<=  58; w5<= -45; w6<=-123; w7<=  18; w8<=  56; end // OUT:16 IN:15
            10'h110: begin w0<=  68; w1<=   2; w2<= 122; w3<=-128; w4<= -71; w5<=  -5; w6<=  37; w7<=-114; w8<=  33; end // OUT:17 IN:0
            10'h111: begin w0<=  60; w1<=  34; w2<= -65; w3<= 112; w4<=-104; w5<=-105; w6<=-117; w7<=-111; w8<=-114; end // OUT:17 IN:1
            10'h112: begin w0<= 107; w1<=  79; w2<=-102; w3<= -57; w4<= -69; w5<=  45; w6<=  88; w7<=  16; w8<= -36; end // OUT:17 IN:2
            10'h113: begin w0<= -76; w1<=-121; w2<= -50; w3<=-102; w4<=  45; w5<= -79; w6<= 115; w7<=  70; w8<=   2; end // OUT:17 IN:3
            10'h114: begin w0<= -36; w1<=  63; w2<=  43; w3<=  52; w4<=-105; w5<= -69; w6<=  -7; w7<=   2; w8<=  19; end // OUT:17 IN:4
            10'h115: begin w0<= -83; w1<=-114; w2<=  24; w3<=  93; w4<=  77; w5<=  70; w6<=-112; w7<=  -3; w8<= 107; end // OUT:17 IN:5
            10'h116: begin w0<= -45; w1<=  99; w2<=-120; w3<=  37; w4<=  47; w5<= 120; w6<=  59; w7<= -66; w8<=  85; end // OUT:17 IN:6
            10'h117: begin w0<= 117; w1<= 116; w2<= -12; w3<=   1; w4<= -41; w5<= -57; w6<=  10; w7<= -65; w8<=  76; end // OUT:17 IN:7
            10'h118: begin w0<=  80; w1<= -57; w2<=-108; w3<=-111; w4<=  93; w5<= -65; w6<= -47; w7<= -19; w8<= 110; end // OUT:17 IN:8
            10'h119: begin w0<= -34; w1<=  37; w2<= -97; w3<=-118; w4<= -84; w5<=  88; w6<= -96; w7<= 123; w8<= -27; end // OUT:17 IN:9
            10'h11a: begin w0<=  40; w1<=   7; w2<=-118; w3<=  85; w4<=  50; w5<= -41; w6<= -88; w7<=  16; w8<= -53; end // OUT:17 IN:10
            10'h11b: begin w0<=  -8; w1<= -83; w2<=  31; w3<=  78; w4<= -49; w5<= -75; w6<= -43; w7<= -37; w8<=  19; end // OUT:17 IN:11
            10'h11c: begin w0<=  32; w1<=  73; w2<=  39; w3<=  31; w4<= 113; w5<= 123; w6<= -32; w7<=-127; w8<=  96; end // OUT:17 IN:12
            10'h11d: begin w0<= -96; w1<= 104; w2<=  76; w3<=  29; w4<=  32; w5<= -52; w6<= -13; w7<=  25; w8<=  21; end // OUT:17 IN:13
            10'h11e: begin w0<= -26; w1<=  65; w2<=  37; w3<= -26; w4<= -39; w5<=  45; w6<=  -7; w7<= 113; w8<=  14; end // OUT:17 IN:14
            10'h11f: begin w0<=  97; w1<= -23; w2<= -10; w3<=  43; w4<= -80; w5<= -25; w6<=  74; w7<= -68; w8<=  66; end // OUT:17 IN:15
            10'h120: begin w0<=  -6; w1<=   5; w2<=-120; w3<=-123; w4<= -56; w5<= -26; w6<=  94; w7<=  31; w8<= -88; end // OUT:18 IN:0
            10'h121: begin w0<= -15; w1<=  75; w2<=-121; w3<= -57; w4<=  49; w5<= -37; w6<= -67; w7<= -45; w8<= -67; end // OUT:18 IN:1
            10'h122: begin w0<= -18; w1<= 122; w2<=  -2; w3<=-122; w4<=  74; w5<= -45; w6<=  79; w7<=   3; w8<=   5; end // OUT:18 IN:2
            10'h123: begin w0<= -71; w1<=-107; w2<=  25; w3<=  -2; w4<=-126; w5<=  -2; w6<= -88; w7<=  59; w8<= -23; end // OUT:18 IN:3
            10'h124: begin w0<=-115; w1<=  74; w2<=  81; w3<= 117; w4<=-117; w5<= -42; w6<=-117; w7<=  12; w8<=-104; end // OUT:18 IN:4
            10'h125: begin w0<= -84; w1<= 114; w2<=  -7; w3<=  18; w4<= -74; w5<= 109; w6<= -29; w7<=  44; w8<=   7; end // OUT:18 IN:5
            10'h126: begin w0<=  92; w1<= -10; w2<= -76; w3<=  54; w4<= -97; w5<= -78; w6<= -85; w7<= -47; w8<=  69; end // OUT:18 IN:6
            10'h127: begin w0<=  17; w1<=  82; w2<=  21; w3<= -92; w4<= -33; w5<= -73; w6<= -24; w7<= -70; w8<=   2; end // OUT:18 IN:7
            10'h128: begin w0<=  27; w1<=  73; w2<= 114; w3<= -94; w4<=  60; w5<= -36; w6<=  53; w7<=  62; w8<=  78; end // OUT:18 IN:8
            10'h129: begin w0<= -32; w1<=   6; w2<= -53; w3<= -80; w4<= -35; w5<=  84; w6<=  30; w7<=  57; w8<=  60; end // OUT:18 IN:9
            10'h12a: begin w0<=-105; w1<=  19; w2<= -92; w3<=-125; w4<=  91; w5<= -21; w6<=  -3; w7<=-109; w8<=  59; end // OUT:18 IN:10
            10'h12b: begin w0<=  23; w1<= -79; w2<=  48; w3<=  50; w4<= -33; w5<= -24; w6<=  35; w7<= 121; w8<= -12; end // OUT:18 IN:11
            10'h12c: begin w0<= -31; w1<=  99; w2<= -63; w3<= -50; w4<=  33; w5<=  35; w6<=-123; w7<= -90; w8<=  41; end // OUT:18 IN:12
            10'h12d: begin w0<= 114; w1<= -14; w2<=  57; w3<= 117; w4<=  -4; w5<=-117; w6<=   2; w7<= 108; w8<=-111; end // OUT:18 IN:13
            10'h12e: begin w0<= -89; w1<=-108; w2<=  14; w3<=  96; w4<= -30; w5<=-103; w6<=-121; w7<= -29; w8<= 111; end // OUT:18 IN:14
            10'h12f: begin w0<=  93; w1<= -42; w2<= -87; w3<=  43; w4<=-115; w5<= -51; w6<=-127; w7<= -10; w8<= -92; end // OUT:18 IN:15
            10'h130: begin w0<= -60; w1<=  37; w2<= 108; w3<= -88; w4<= -67; w5<= 117; w6<= -69; w7<=  -4; w8<= -18; end // OUT:19 IN:0
            10'h131: begin w0<=-115; w1<= 119; w2<= 102; w3<=  88; w4<= -45; w5<=   1; w6<= 102; w7<= -59; w8<=  16; end // OUT:19 IN:1
            10'h132: begin w0<=  -6; w1<= -40; w2<= 120; w3<=-101; w4<= -63; w5<=  34; w6<= 100; w7<=-124; w8<= 126; end // OUT:19 IN:2
            10'h133: begin w0<=  64; w1<=  39; w2<=  75; w3<=  55; w4<=  35; w5<= -84; w6<=  22; w7<= -82; w8<= -98; end // OUT:19 IN:3
            10'h134: begin w0<=  10; w1<=-119; w2<=  66; w3<= -11; w4<=-115; w5<= -49; w6<=  73; w7<= -36; w8<=-119; end // OUT:19 IN:4
            10'h135: begin w0<= -53; w1<= -35; w2<= -24; w3<=-128; w4<=   4; w5<=-109; w6<=-121; w7<=  42; w8<=  75; end // OUT:19 IN:5
            10'h136: begin w0<=-128; w1<= -72; w2<= -65; w3<= -11; w4<=  83; w5<=-101; w6<=  -8; w7<= -22; w8<=  36; end // OUT:19 IN:6
            10'h137: begin w0<=  46; w1<= 100; w2<=  75; w3<=  36; w4<= -80; w5<= 112; w6<=  -9; w7<= -85; w8<= -73; end // OUT:19 IN:7
            10'h138: begin w0<=  27; w1<= -18; w2<=  78; w3<=   5; w4<= -21; w5<= 122; w6<=  60; w7<=  19; w8<= -15; end // OUT:19 IN:8
            10'h139: begin w0<= -51; w1<=   1; w2<=  72; w3<= 126; w4<= -92; w5<=-109; w6<=-103; w7<=-100; w8<=-128; end // OUT:19 IN:9
            10'h13a: begin w0<= -10; w1<= -94; w2<=  69; w3<= 100; w4<= 116; w5<= -70; w6<= -60; w7<=  32; w8<= 112; end // OUT:19 IN:10
            10'h13b: begin w0<=  50; w1<=  77; w2<=-117; w3<= 105; w4<=-109; w5<=  52; w6<= 113; w7<=  87; w8<= 122; end // OUT:19 IN:11
            10'h13c: begin w0<= -86; w1<=  -3; w2<=  97; w3<=  88; w4<= -79; w5<=-100; w6<=  56; w7<= -90; w8<=  94; end // OUT:19 IN:12
            10'h13d: begin w0<=  55; w1<= 110; w2<=  42; w3<=  49; w4<=  22; w5<=  43; w6<= -91; w7<= -45; w8<=  22; end // OUT:19 IN:13
            10'h13e: begin w0<=  -1; w1<=  -3; w2<= -84; w3<= -77; w4<= -49; w5<=  49; w6<= 105; w7<=  -5; w8<= -10; end // OUT:19 IN:14
            10'h13f: begin w0<=-121; w1<= 113; w2<= -44; w3<=   0; w4<= 118; w5<=-121; w6<=  28; w7<= -33; w8<= -27; end // OUT:19 IN:15
            10'h140: begin w0<=-124; w1<= 110; w2<= -43; w3<=  46; w4<= -95; w5<=  64; w6<= -74; w7<= -10; w8<=  89; end // OUT:20 IN:0
            10'h141: begin w0<=  42; w1<=  73; w2<=  29; w3<= -15; w4<=  81; w5<=  16; w6<=-103; w7<=   7; w8<= -82; end // OUT:20 IN:1
            10'h142: begin w0<= 103; w1<= -16; w2<= -53; w3<=  90; w4<= -57; w5<= -40; w6<= -83; w7<=  67; w8<= -96; end // OUT:20 IN:2
            10'h143: begin w0<=-128; w1<=  18; w2<= -98; w3<=  79; w4<=  13; w5<= -76; w6<= -81; w7<= -60; w8<= -24; end // OUT:20 IN:3
            10'h144: begin w0<= -39; w1<=  61; w2<=  91; w3<=  65; w4<= 113; w5<=  63; w6<=  69; w7<= -66; w8<= -56; end // OUT:20 IN:4
            10'h145: begin w0<=  32; w1<=  40; w2<= -40; w3<=  47; w4<=-116; w5<= -56; w6<= 116; w7<= -52; w8<=  30; end // OUT:20 IN:5
            10'h146: begin w0<= 104; w1<=  74; w2<= -61; w3<= -31; w4<=  -4; w5<= -27; w6<= 109; w7<=   3; w8<= -27; end // OUT:20 IN:6
            10'h147: begin w0<=-110; w1<=  69; w2<=  97; w3<= -47; w4<=  12; w5<= 104; w6<=-106; w7<= -46; w8<= -20; end // OUT:20 IN:7
            10'h148: begin w0<= -54; w1<=   0; w2<= -41; w3<= 125; w4<= -75; w5<=  70; w6<= -40; w7<=  84; w8<=  14; end // OUT:20 IN:8
            10'h149: begin w0<= -64; w1<= -53; w2<= 121; w3<=  70; w4<=  14; w5<=  20; w6<=  18; w7<= -69; w8<= -36; end // OUT:20 IN:9
            10'h14a: begin w0<=  88; w1<=  32; w2<= -80; w3<=  95; w4<= 112; w5<= -94; w6<=  43; w7<= -27; w8<=  89; end // OUT:20 IN:10
            10'h14b: begin w0<=-118; w1<= -30; w2<=  71; w3<= -19; w4<=  77; w5<= -55; w6<=  65; w7<=  45; w8<=-120; end // OUT:20 IN:11
            10'h14c: begin w0<=-126; w1<= -44; w2<=-103; w3<= -57; w4<= -81; w5<=  65; w6<=  69; w7<=  27; w8<= -12; end // OUT:20 IN:12
            10'h14d: begin w0<=  92; w1<=  25; w2<=  24; w3<=-117; w4<=   4; w5<=  97; w6<= -81; w7<= -92; w8<=  78; end // OUT:20 IN:13
            10'h14e: begin w0<= -85; w1<=  99; w2<=-114; w3<= -86; w4<=  47; w5<= -42; w6<= -59; w7<= -83; w8<= 113; end // OUT:20 IN:14
            10'h14f: begin w0<= -21; w1<=  -6; w2<=  42; w3<= 108; w4<=-108; w5<=  22; w6<= -22; w7<= 118; w8<= -49; end // OUT:20 IN:15
            10'h150: begin w0<= -82; w1<= -12; w2<=  -5; w3<=  14; w4<=-104; w5<= -93; w6<=  74; w7<= -78; w8<=-114; end // OUT:21 IN:0
            10'h151: begin w0<= -61; w1<=-108; w2<=  12; w3<=  85; w4<=-110; w5<= -95; w6<= -51; w7<=  -4; w8<=  67; end // OUT:21 IN:1
            10'h152: begin w0<= 111; w1<= -12; w2<= -77; w3<= 109; w4<=-102; w5<=  28; w6<= 110; w7<=  27; w8<= -94; end // OUT:21 IN:2
            10'h153: begin w0<=   7; w1<=  15; w2<= -23; w3<=  35; w4<=  29; w5<=  17; w6<=-127; w7<=  48; w8<= -52; end // OUT:21 IN:3
            10'h154: begin w0<=   3; w1<= -39; w2<= -40; w3<= -35; w4<=  74; w5<=-122; w6<= -34; w7<= -21; w8<= -55; end // OUT:21 IN:4
            10'h155: begin w0<= -90; w1<=  12; w2<=  30; w3<= -58; w4<=  62; w5<= -73; w6<= 112; w7<=  41; w8<=  60; end // OUT:21 IN:5
            10'h156: begin w0<= -87; w1<=  55; w2<= -93; w3<= -45; w4<=  67; w5<= -11; w6<=-122; w7<= -75; w8<=   0; end // OUT:21 IN:6
            10'h157: begin w0<=  43; w1<=  -9; w2<=  44; w3<= -23; w4<= -82; w5<=  -6; w6<=  12; w7<= -10; w8<=  21; end // OUT:21 IN:7
            10'h158: begin w0<= -11; w1<=-108; w2<=  85; w3<=  91; w4<=   8; w5<=-103; w6<=-120; w7<=-114; w8<=-119; end // OUT:21 IN:8
            10'h159: begin w0<=  87; w1<=  -7; w2<=  -8; w3<=  -4; w4<=  41; w5<= -57; w6<=  23; w7<=  79; w8<= -80; end // OUT:21 IN:9
            10'h15a: begin w0<=  25; w1<= -38; w2<= -92; w3<= -61; w4<= -79; w5<=  23; w6<=-110; w7<= -29; w8<= -69; end // OUT:21 IN:10
            10'h15b: begin w0<=  38; w1<=  73; w2<= -40; w3<=  17; w4<=  18; w5<=  35; w6<=  73; w7<=  96; w8<=  54; end // OUT:21 IN:11
            10'h15c: begin w0<= 113; w1<= -60; w2<=  46; w3<= -80; w4<=  98; w5<= -21; w6<=  97; w7<=  32; w8<= -10; end // OUT:21 IN:12
            10'h15d: begin w0<=  20; w1<=  80; w2<=  21; w3<=  47; w4<= -92; w5<=  14; w6<=  34; w7<=  91; w8<=  70; end // OUT:21 IN:13
            10'h15e: begin w0<=  31; w1<=-118; w2<=   9; w3<=  72; w4<= -51; w5<= -52; w6<= 124; w7<=  56; w8<= 125; end // OUT:21 IN:14
            10'h15f: begin w0<=  24; w1<=-127; w2<= -65; w3<= -94; w4<=-122; w5<= -44; w6<=  17; w7<= -62; w8<= -87; end // OUT:21 IN:15
            10'h160: begin w0<= -11; w1<=  -4; w2<=  38; w3<=  40; w4<= 112; w5<=  74; w6<= 102; w7<=-105; w8<=  59; end // OUT:22 IN:0
            10'h161: begin w0<= -83; w1<=-110; w2<= -61; w3<=  89; w4<= -27; w5<= -87; w6<= -97; w7<=  38; w8<= -20; end // OUT:22 IN:1
            10'h162: begin w0<= 109; w1<= -93; w2<= 103; w3<= 100; w4<= -32; w5<=  35; w6<=   2; w7<= -56; w8<=   7; end // OUT:22 IN:2
            10'h163: begin w0<= -32; w1<=  -6; w2<= -59; w3<=  40; w4<= 102; w5<=  67; w6<=-116; w7<= -80; w8<= -69; end // OUT:22 IN:3
            10'h164: begin w0<=   1; w1<=  59; w2<=-124; w3<=  43; w4<=-102; w5<=  31; w6<=  20; w7<=-121; w8<= 101; end // OUT:22 IN:4
            10'h165: begin w0<=  71; w1<= -79; w2<= -62; w3<= 117; w4<= -85; w5<=  -4; w6<= -71; w7<=-126; w8<= -43; end // OUT:22 IN:5
            10'h166: begin w0<= -59; w1<=   1; w2<=  86; w3<=  43; w4<=-127; w5<= -27; w6<=  80; w7<= -94; w8<= -31; end // OUT:22 IN:6
            10'h167: begin w0<=  86; w1<= -99; w2<= -13; w3<=-121; w4<=  21; w5<= -85; w6<=  57; w7<= -93; w8<=  68; end // OUT:22 IN:7
            10'h168: begin w0<= -52; w1<=  92; w2<= -98; w3<= -82; w4<= 120; w5<= -74; w6<=  79; w7<= -23; w8<=  61; end // OUT:22 IN:8
            10'h169: begin w0<=  29; w1<=  -8; w2<= -74; w3<=  15; w4<=-117; w5<=  16; w6<=  15; w7<=  11; w8<=   7; end // OUT:22 IN:9
            10'h16a: begin w0<=  83; w1<=-126; w2<=  15; w3<= -99; w4<= 108; w5<=-106; w6<= -37; w7<= -14; w8<= -25; end // OUT:22 IN:10
            10'h16b: begin w0<= -11; w1<=-124; w2<=  83; w3<= -25; w4<= 119; w5<= -21; w6<= -64; w7<=  -8; w8<= -99; end // OUT:22 IN:11
            10'h16c: begin w0<=  20; w1<= -45; w2<=  69; w3<=  21; w4<=  81; w5<=  71; w6<= 102; w7<= -97; w8<=  32; end // OUT:22 IN:12
            10'h16d: begin w0<= 116; w1<=-113; w2<=  75; w3<= -91; w4<= 115; w5<=  97; w6<= 124; w7<=  13; w8<= -93; end // OUT:22 IN:13
            10'h16e: begin w0<=  96; w1<=  22; w2<= -15; w3<= 108; w4<= -63; w5<= -24; w6<= -44; w7<=-127; w8<=  90; end // OUT:22 IN:14
            10'h16f: begin w0<= 120; w1<=  72; w2<=  64; w3<= -54; w4<= -62; w5<=  51; w6<=  61; w7<=  22; w8<=  25; end // OUT:22 IN:15
            10'h170: begin w0<=  67; w1<=  81; w2<= -74; w3<=-123; w4<=  34; w5<=  21; w6<=  42; w7<=  14; w8<= -43; end // OUT:23 IN:0
            10'h171: begin w0<= -69; w1<= -28; w2<= 115; w3<= 105; w4<=-117; w5<= 110; w6<= -80; w7<= -87; w8<=  37; end // OUT:23 IN:1
            10'h172: begin w0<= -47; w1<=  44; w2<= -94; w3<=  29; w4<=  87; w5<= 105; w6<=  29; w7<=  77; w8<=   5; end // OUT:23 IN:2
            10'h173: begin w0<= -62; w1<= -49; w2<=-122; w3<=  51; w4<=-115; w5<= -56; w6<=  14; w7<=  20; w8<=  34; end // OUT:23 IN:3
            10'h174: begin w0<= -63; w1<= -38; w2<=   1; w3<=  34; w4<=  81; w5<=  77; w6<=-109; w7<=  81; w8<=-119; end // OUT:23 IN:4
            10'h175: begin w0<=-104; w1<=  65; w2<=-104; w3<= 124; w4<= -75; w5<= -96; w6<=  35; w7<= -34; w8<=-115; end // OUT:23 IN:5
            10'h176: begin w0<= -64; w1<= -19; w2<= -49; w3<= -75; w4<= 109; w5<=  -4; w6<=  51; w7<=   2; w8<=  98; end // OUT:23 IN:6
            10'h177: begin w0<=  40; w1<=   5; w2<=-104; w3<=  12; w4<= -12; w5<=  97; w6<=   7; w7<=  20; w8<=  97; end // OUT:23 IN:7
            10'h178: begin w0<=  67; w1<=-104; w2<= -50; w3<= -61; w4<=  44; w5<=  59; w6<=-117; w7<= -97; w8<=  -1; end // OUT:23 IN:8
            10'h179: begin w0<= -33; w1<= -37; w2<=  12; w3<= -98; w4<= -51; w5<=-109; w6<=  17; w7<=  92; w8<= -69; end // OUT:23 IN:9
            10'h17a: begin w0<=  62; w1<=   5; w2<=  31; w3<= -36; w4<= -86; w5<= 125; w6<=   1; w7<= -69; w8<=  22; end // OUT:23 IN:10
            10'h17b: begin w0<=  82; w1<= -98; w2<= 114; w3<=-124; w4<=  82; w5<=  33; w6<=-119; w7<= -40; w8<=   1; end // OUT:23 IN:11
            10'h17c: begin w0<=  -3; w1<=-118; w2<=  49; w3<= 124; w4<=  30; w5<= -73; w6<=  78; w7<=  72; w8<=  86; end // OUT:23 IN:12
            10'h17d: begin w0<= -46; w1<=   8; w2<= -30; w3<=  20; w4<= -56; w5<=  27; w6<=  61; w7<= 109; w8<= -14; end // OUT:23 IN:13
            10'h17e: begin w0<=-122; w1<= -49; w2<=  15; w3<= 123; w4<= -32; w5<=-125; w6<=-125; w7<= -26; w8<= -89; end // OUT:23 IN:14
            10'h17f: begin w0<=-112; w1<= -28; w2<= -26; w3<=  -5; w4<= -77; w5<=  92; w6<= -77; w7<=  35; w8<=  -5; end // OUT:23 IN:15
            10'h180: begin w0<=  37; w1<= 102; w2<=  49; w3<= -66; w4<= 100; w5<= -13; w6<=  62; w7<= -67; w8<= 124; end // OUT:24 IN:0
            10'h181: begin w0<=  98; w1<=-122; w2<=  26; w3<= -37; w4<=  85; w5<=-115; w6<=  70; w7<= 100; w8<= 124; end // OUT:24 IN:1
            10'h182: begin w0<= -43; w1<=   4; w2<= 125; w3<=  54; w4<=   1; w5<= -67; w6<=  90; w7<=  20; w8<= 117; end // OUT:24 IN:2
            10'h183: begin w0<= 101; w1<= -50; w2<=  20; w3<=   9; w4<=  86; w5<= -71; w6<=  -9; w7<=  38; w8<=   4; end // OUT:24 IN:3
            10'h184: begin w0<= -64; w1<=-116; w2<=  84; w3<=  89; w4<= 113; w5<= 108; w6<=  84; w7<=  52; w8<= -47; end // OUT:24 IN:4
            10'h185: begin w0<= 100; w1<=  44; w2<=  31; w3<=  35; w4<=  80; w5<=  98; w6<= 112; w7<=  59; w8<=  10; end // OUT:24 IN:5
            10'h186: begin w0<=  62; w1<=  20; w2<= -77; w3<=  54; w4<= -12; w5<=-103; w6<= 125; w7<=  67; w8<= -95; end // OUT:24 IN:6
            10'h187: begin w0<= -77; w1<= -17; w2<= 123; w3<= -47; w4<= 103; w5<=  98; w6<= 104; w7<=  92; w8<=  51; end // OUT:24 IN:7
            10'h188: begin w0<=  28; w1<=  37; w2<= -87; w3<=-108; w4<= -87; w5<=  12; w6<= -16; w7<= -24; w8<=  63; end // OUT:24 IN:8
            10'h189: begin w0<=-112; w1<=  -9; w2<=   8; w3<=  40; w4<=   0; w5<=   1; w6<= -69; w7<= -81; w8<=-100; end // OUT:24 IN:9
            10'h18a: begin w0<= -32; w1<=-119; w2<= 113; w3<= -71; w4<=  59; w5<= 103; w6<=-108; w7<=-101; w8<=  74; end // OUT:24 IN:10
            10'h18b: begin w0<= 118; w1<= -95; w2<=-121; w3<=  58; w4<=  85; w5<=  71; w6<=  48; w7<= -50; w8<=  16; end // OUT:24 IN:11
            10'h18c: begin w0<=  59; w1<= -42; w2<= -41; w3<=  44; w4<=  82; w5<= -60; w6<=  31; w7<=  43; w8<=  64; end // OUT:24 IN:12
            10'h18d: begin w0<= -42; w1<= -28; w2<=-121; w3<= -52; w4<=  71; w5<= 120; w6<= -42; w7<= -86; w8<=   0; end // OUT:24 IN:13
            10'h18e: begin w0<= -20; w1<=  50; w2<=  23; w3<=  98; w4<=  23; w5<=-112; w6<=   4; w7<=  19; w8<=-108; end // OUT:24 IN:14
            10'h18f: begin w0<= 103; w1<= -71; w2<=  30; w3<= -19; w4<=  99; w5<=  10; w6<=  51; w7<=  14; w8<=  82; end // OUT:24 IN:15
            10'h190: begin w0<=   6; w1<= 114; w2<=-101; w3<= -78; w4<= 106; w5<=  57; w6<=-124; w7<=-124; w8<= -35; end // OUT:25 IN:0
            10'h191: begin w0<= 117; w1<= -33; w2<=-121; w3<= -65; w4<=   9; w5<= -91; w6<= -18; w7<=  95; w8<= -17; end // OUT:25 IN:1
            10'h192: begin w0<=  91; w1<= -48; w2<=  94; w3<=   7; w4<= -25; w5<=  24; w6<= -56; w7<=  65; w8<=  78; end // OUT:25 IN:2
            10'h193: begin w0<=  49; w1<=  66; w2<= -80; w3<= -93; w4<=  -3; w5<= -61; w6<= -51; w7<= -24; w8<=  40; end // OUT:25 IN:3
            10'h194: begin w0<=  88; w1<=  -7; w2<= -10; w3<=  61; w4<= 126; w5<= -15; w6<=-119; w7<=  20; w8<=  35; end // OUT:25 IN:4
            10'h195: begin w0<=  11; w1<= -38; w2<= 103; w3<=-127; w4<= -11; w5<=-116; w6<=  52; w7<=  31; w8<= -34; end // OUT:25 IN:5
            10'h196: begin w0<=  15; w1<= -97; w2<= -97; w3<=  -5; w4<=  97; w5<=-118; w6<=-119; w7<=-114; w8<=-112; end // OUT:25 IN:6
            10'h197: begin w0<=  39; w1<=  17; w2<=  54; w3<=  72; w4<=  24; w5<= 103; w6<= -70; w7<= -51; w8<=  -5; end // OUT:25 IN:7
            10'h198: begin w0<= 121; w1<=  88; w2<= -15; w3<=-107; w4<= 115; w5<=  29; w6<=  83; w7<=  84; w8<=  43; end // OUT:25 IN:8
            10'h199: begin w0<= -97; w1<=  50; w2<=  45; w3<= -16; w4<=  -9; w5<=  20; w6<=  98; w7<=  -7; w8<= -97; end // OUT:25 IN:9
            10'h19a: begin w0<=  93; w1<= -10; w2<= -90; w3<= 112; w4<=-117; w5<= 104; w6<=  46; w7<=-111; w8<=  20; end // OUT:25 IN:10
            10'h19b: begin w0<=  12; w1<= 125; w2<=  20; w3<=  -3; w4<=   7; w5<= -83; w6<= -25; w7<= 109; w8<=   6; end // OUT:25 IN:11
            10'h19c: begin w0<=  22; w1<= 107; w2<=  95; w3<=  74; w4<= -43; w5<=  21; w6<= 106; w7<= -40; w8<=-107; end // OUT:25 IN:12
            10'h19d: begin w0<= -37; w1<=-100; w2<=-116; w3<=  81; w4<=-127; w5<=-100; w6<=  84; w7<=  78; w8<=  51; end // OUT:25 IN:13
            10'h19e: begin w0<=-102; w1<= -79; w2<= -34; w3<=  78; w4<= 114; w5<=  22; w6<= -41; w7<= -85; w8<=  76; end // OUT:25 IN:14
            10'h19f: begin w0<=-107; w1<=  42; w2<=  36; w3<=  60; w4<= -32; w5<=  55; w6<=-126; w7<=  62; w8<= -11; end // OUT:25 IN:15
            10'h1a0: begin w0<=-110; w1<=-106; w2<=  28; w3<= -99; w4<= -90; w5<= -21; w6<= -18; w7<=-104; w8<=  -1; end // OUT:26 IN:0
            10'h1a1: begin w0<= 100; w1<= -18; w2<=   7; w3<= -23; w4<=  57; w5<=  15; w6<= -57; w7<=   0; w8<= -21; end // OUT:26 IN:1
            10'h1a2: begin w0<=-124; w1<=-126; w2<=  64; w3<=   3; w4<= -25; w5<=  98; w6<=  95; w7<= -65; w8<= -23; end // OUT:26 IN:2
            10'h1a3: begin w0<= -31; w1<= 106; w2<=  88; w3<=-119; w4<=  20; w5<=  -1; w6<= -83; w7<= 102; w8<=  90; end // OUT:26 IN:3
            10'h1a4: begin w0<=  26; w1<= -63; w2<=  40; w3<= -17; w4<=-116; w5<=   8; w6<= 115; w7<=  35; w8<= -43; end // OUT:26 IN:4
            10'h1a5: begin w0<= 105; w1<= -39; w2<= -71; w3<= -75; w4<=-117; w5<=  80; w6<=  77; w7<=-115; w8<=  -8; end // OUT:26 IN:5
            10'h1a6: begin w0<=  33; w1<=  52; w2<=  -8; w3<=-109; w4<= -54; w5<=  15; w6<= 114; w7<=  94; w8<= 118; end // OUT:26 IN:6
            10'h1a7: begin w0<= -59; w1<= -73; w2<=  82; w3<= -28; w4<=  57; w5<=   3; w6<= -18; w7<=  -4; w8<=   3; end // OUT:26 IN:7
            10'h1a8: begin w0<=-109; w1<=   9; w2<=-105; w3<= 117; w4<=  98; w5<=  25; w6<= -92; w7<= 101; w8<=  84; end // OUT:26 IN:8
            10'h1a9: begin w0<= -75; w1<= 103; w2<= -26; w3<=  20; w4<=  73; w5<= -91; w6<=  45; w7<=-125; w8<=  59; end // OUT:26 IN:9
            10'h1aa: begin w0<= -72; w1<=  44; w2<=-109; w3<=-112; w4<= -10; w5<= -58; w6<=-125; w7<=  92; w8<=-115; end // OUT:26 IN:10
            10'h1ab: begin w0<=-126; w1<=  87; w2<= 100; w3<= -49; w4<=  57; w5<= -74; w6<= 115; w7<=   3; w8<=  -9; end // OUT:26 IN:11
            10'h1ac: begin w0<= 125; w1<=-105; w2<=  33; w3<=  29; w4<= -47; w5<=  18; w6<=  30; w7<=  59; w8<= -69; end // OUT:26 IN:12
            10'h1ad: begin w0<=  18; w1<= -80; w2<= -66; w3<= -19; w4<=  82; w5<=  21; w6<=  23; w7<= -20; w8<= -53; end // OUT:26 IN:13
            10'h1ae: begin w0<= -99; w1<= -71; w2<= 101; w3<= -12; w4<=  30; w5<= -29; w6<=  63; w7<=-110; w8<=  47; end // OUT:26 IN:14
            10'h1af: begin w0<=  44; w1<=  99; w2<= -35; w3<=  54; w4<= -16; w5<=  54; w6<=  96; w7<=  17; w8<= -66; end // OUT:26 IN:15
            10'h1b0: begin w0<= -13; w1<= -16; w2<= 122; w3<=  91; w4<= 122; w5<= -82; w6<=  74; w7<= -72; w8<= 123; end // OUT:27 IN:0
            10'h1b1: begin w0<= -11; w1<= -84; w2<=  32; w3<=  16; w4<=  69; w5<=-125; w6<=  19; w7<= 111; w8<= -82; end // OUT:27 IN:1
            10'h1b2: begin w0<=  90; w1<=  14; w2<=  69; w3<= -82; w4<= -51; w5<=  -5; w6<= -54; w7<= -26; w8<=   8; end // OUT:27 IN:2
            10'h1b3: begin w0<= -39; w1<=  15; w2<= -60; w3<= 120; w4<= 115; w5<= -68; w6<=   9; w7<= -79; w8<=-126; end // OUT:27 IN:3
            10'h1b4: begin w0<=  76; w1<= -22; w2<= -16; w3<= -35; w4<= 125; w5<= -11; w6<= 108; w7<=  69; w8<= -48; end // OUT:27 IN:4
            10'h1b5: begin w0<= 122; w1<= -20; w2<= -78; w3<= 116; w4<=  18; w5<=  41; w6<= -94; w7<= -83; w8<=  25; end // OUT:27 IN:5
            10'h1b6: begin w0<= 114; w1<= -60; w2<= -36; w3<= -65; w4<=  36; w5<=  83; w6<= -80; w7<=  20; w8<= -55; end // OUT:27 IN:6
            10'h1b7: begin w0<=  63; w1<=-124; w2<= -29; w3<= -59; w4<= -39; w5<=-125; w6<=  -3; w7<= 102; w8<= -90; end // OUT:27 IN:7
            10'h1b8: begin w0<= 113; w1<=  34; w2<=   0; w3<=-105; w4<= -72; w5<= -29; w6<= -59; w7<= -88; w8<=  53; end // OUT:27 IN:8
            10'h1b9: begin w0<=  45; w1<= -69; w2<= -21; w3<=  59; w4<= -72; w5<= -98; w6<= -45; w7<=  23; w8<=  88; end // OUT:27 IN:9
            10'h1ba: begin w0<= -93; w1<=  84; w2<=  29; w3<=  23; w4<= -21; w5<= -23; w6<=  29; w7<= -43; w8<=  91; end // OUT:27 IN:10
            10'h1bb: begin w0<=   6; w1<=  34; w2<=  54; w3<=  91; w4<=-115; w5<=  -9; w6<=   9; w7<= -49; w8<=  15; end // OUT:27 IN:11
            10'h1bc: begin w0<=  53; w1<=  94; w2<= -23; w3<=  88; w4<=  76; w5<= -59; w6<= -85; w7<= -56; w8<= -84; end // OUT:27 IN:12
            10'h1bd: begin w0<=  99; w1<=  55; w2<= -22; w3<= -45; w4<= -47; w5<= 121; w6<= -22; w7<=  56; w8<=-108; end // OUT:27 IN:13
            10'h1be: begin w0<=  67; w1<=  49; w2<=  32; w3<=  90; w4<=-122; w5<= -59; w6<=  -2; w7<=  14; w8<=  81; end // OUT:27 IN:14
            10'h1bf: begin w0<=  31; w1<= 119; w2<=  74; w3<=  19; w4<=  87; w5<=  14; w6<=  47; w7<=  70; w8<=  20; end // OUT:27 IN:15
            10'h1c0: begin w0<=  41; w1<=  25; w2<= 107; w3<=  -9; w4<=  -1; w5<=  13; w6<= -72; w7<=  36; w8<= -71; end // OUT:28 IN:0
            10'h1c1: begin w0<=-108; w1<= -47; w2<= -60; w3<=   2; w4<= -42; w5<=  89; w6<=  36; w7<=  87; w8<= -80; end // OUT:28 IN:1
            10'h1c2: begin w0<=  18; w1<= -14; w2<= -40; w3<= -44; w4<=  -1; w5<=  11; w6<= 120; w7<=  60; w8<=  40; end // OUT:28 IN:2
            10'h1c3: begin w0<=  32; w1<=  49; w2<= -12; w3<=  67; w4<=  -2; w5<= 105; w6<= 120; w7<= -58; w8<= -43; end // OUT:28 IN:3
            10'h1c4: begin w0<= 118; w1<= -96; w2<= -48; w3<=  23; w4<= -68; w5<= -68; w6<= -31; w7<=-101; w8<=  57; end // OUT:28 IN:4
            10'h1c5: begin w0<= -86; w1<=  40; w2<=  38; w3<= -43; w4<=  48; w5<=-112; w6<= -31; w7<=  69; w8<= 109; end // OUT:28 IN:5
            10'h1c6: begin w0<=  69; w1<= -31; w2<= -64; w3<= -55; w4<= -44; w5<=-124; w6<=-127; w7<=-107; w8<= -17; end // OUT:28 IN:6
            10'h1c7: begin w0<= -72; w1<= -63; w2<= -55; w3<= -31; w4<=  15; w5<= -17; w6<=  50; w7<=  -4; w8<=  38; end // OUT:28 IN:7
            10'h1c8: begin w0<= -43; w1<= -53; w2<= -41; w3<= 110; w4<=  39; w5<= -91; w6<=  59; w7<= -70; w8<=   9; end // OUT:28 IN:8
            10'h1c9: begin w0<= -30; w1<=  63; w2<= 114; w3<= -66; w4<= -80; w5<=  63; w6<= -97; w7<=   6; w8<=-108; end // OUT:28 IN:9
            10'h1ca: begin w0<=-109; w1<=  25; w2<=  -2; w3<= -61; w4<= -19; w5<= -13; w6<=  85; w7<=  14; w8<=  -9; end // OUT:28 IN:10
            10'h1cb: begin w0<= 103; w1<=  84; w2<= -50; w3<=  85; w4<= -13; w5<= -37; w6<=-115; w7<=  26; w8<=  -4; end // OUT:28 IN:11
            10'h1cc: begin w0<= 104; w1<=  39; w2<= -71; w3<=-101; w4<=-103; w5<= -16; w6<=  62; w7<= -63; w8<=  24; end // OUT:28 IN:12
            10'h1cd: begin w0<= 119; w1<= 125; w2<=   2; w3<=  71; w4<= -85; w5<= -32; w6<= -87; w7<= 115; w8<=  98; end // OUT:28 IN:13
            10'h1ce: begin w0<=-123; w1<=  38; w2<=  51; w3<=-106; w4<= -40; w5<=  -6; w6<=  49; w7<=  42; w8<=  18; end // OUT:28 IN:14
            10'h1cf: begin w0<=  68; w1<= -78; w2<=-118; w3<= 119; w4<=-117; w5<= -55; w6<=-121; w7<=  23; w8<= 123; end // OUT:28 IN:15
            10'h1d0: begin w0<=  91; w1<= -88; w2<=  35; w3<= 100; w4<= -44; w5<= -57; w6<= -74; w7<=   8; w8<= -82; end // OUT:29 IN:0
            10'h1d1: begin w0<=  14; w1<=  47; w2<= 109; w3<= -25; w4<=  81; w5<= -87; w6<= -69; w7<=  83; w8<=  69; end // OUT:29 IN:1
            10'h1d2: begin w0<=-117; w1<=   1; w2<=-122; w3<= -49; w4<=   2; w5<= -20; w6<=-126; w7<=-102; w8<= -15; end // OUT:29 IN:2
            10'h1d3: begin w0<= -22; w1<= -89; w2<= 101; w3<=  32; w4<=  91; w5<=   0; w6<= 118; w7<=-121; w8<= -28; end // OUT:29 IN:3
            10'h1d4: begin w0<=  31; w1<=  -5; w2<=  47; w3<= -22; w4<= -28; w5<=-125; w6<=  93; w7<=  69; w8<= -19; end // OUT:29 IN:4
            10'h1d5: begin w0<= 117; w1<=-110; w2<= -97; w3<=   8; w4<=-117; w5<=  10; w6<= -83; w7<= -10; w8<=-113; end // OUT:29 IN:5
            10'h1d6: begin w0<=   0; w1<= -66; w2<= -20; w3<= -10; w4<= 116; w5<=-108; w6<=  29; w7<=-116; w8<=  33; end // OUT:29 IN:6
            10'h1d7: begin w0<=-125; w1<=  27; w2<= -27; w3<= 121; w4<=  94; w5<= -70; w6<= 118; w7<=  -1; w8<=-102; end // OUT:29 IN:7
            10'h1d8: begin w0<= -60; w1<=-104; w2<=   2; w3<= -32; w4<=  67; w5<=-104; w6<=  19; w7<=  33; w8<=  25; end // OUT:29 IN:8
            10'h1d9: begin w0<=  -3; w1<= 125; w2<=   4; w3<=  98; w4<=  60; w5<=  91; w6<=  92; w7<=-120; w8<= -13; end // OUT:29 IN:9
            10'h1da: begin w0<= 101; w1<=  49; w2<=   5; w3<=  82; w4<= -69; w5<=  43; w6<=  -8; w7<=  10; w8<=  65; end // OUT:29 IN:10
            10'h1db: begin w0<=  46; w1<= -21; w2<= -21; w3<=  72; w4<=  84; w5<=  87; w6<=  97; w7<=  85; w8<=   2; end // OUT:29 IN:11
            10'h1dc: begin w0<= -53; w1<=  91; w2<= -99; w3<=  89; w4<= 111; w5<=-108; w6<=  27; w7<= 119; w8<=  89; end // OUT:29 IN:12
            10'h1dd: begin w0<=  61; w1<=  32; w2<=  84; w3<=  34; w4<=  51; w5<= -95; w6<= -88; w7<= -78; w8<=  46; end // OUT:29 IN:13
            10'h1de: begin w0<= -47; w1<= -71; w2<= -54; w3<=  56; w4<=-106; w5<=  47; w6<=  -1; w7<=  21; w8<=-112; end // OUT:29 IN:14
            10'h1df: begin w0<= -60; w1<= -21; w2<=  10; w3<= -35; w4<=-114; w5<= -38; w6<=  34; w7<= -96; w8<=  83; end // OUT:29 IN:15
            10'h1e0: begin w0<=  -4; w1<=-113; w2<=  33; w3<= -63; w4<=  98; w5<=  39; w6<= 119; w7<=  27; w8<= -82; end // OUT:30 IN:0
            10'h1e1: begin w0<=  38; w1<=  69; w2<=  72; w3<=  19; w4<=  -5; w5<=-128; w6<=  71; w7<= 118; w8<= -42; end // OUT:30 IN:1
            10'h1e2: begin w0<=  -1; w1<=  62; w2<= -62; w3<=-125; w4<=  57; w5<=  24; w6<= -82; w7<= -91; w8<=  14; end // OUT:30 IN:2
            10'h1e3: begin w0<=  62; w1<=-108; w2<=  98; w3<= -72; w4<= -12; w5<=  52; w6<= -83; w7<= 115; w8<=  13; end // OUT:30 IN:3
            10'h1e4: begin w0<=  99; w1<=  75; w2<=  16; w3<= -90; w4<=   8; w5<= -30; w6<= 123; w7<= -52; w8<=  78; end // OUT:30 IN:4
            10'h1e5: begin w0<=  81; w1<= -14; w2<=  96; w3<=   5; w4<= 122; w5<=  90; w6<=  22; w7<=  58; w8<= -38; end // OUT:30 IN:5
            10'h1e6: begin w0<= -31; w1<=  -9; w2<= -83; w3<= -91; w4<=  13; w5<= -29; w6<= 116; w7<= -57; w8<=  61; end // OUT:30 IN:6
            10'h1e7: begin w0<= -94; w1<=  18; w2<= -99; w3<= 126; w4<= -51; w5<= 122; w6<= -45; w7<= -16; w8<=-104; end // OUT:30 IN:7
            10'h1e8: begin w0<=  39; w1<= -41; w2<=-115; w3<=  25; w4<= -27; w5<=  86; w6<=  21; w7<=  47; w8<= 120; end // OUT:30 IN:8
            10'h1e9: begin w0<= -46; w1<= -19; w2<=  50; w3<=   2; w4<=  41; w5<=-110; w6<=  72; w7<=-101; w8<=  83; end // OUT:30 IN:9
            10'h1ea: begin w0<=  44; w1<= -58; w2<=  77; w3<= -66; w4<= -56; w5<= 122; w6<=  -5; w7<= -10; w8<=  -8; end // OUT:30 IN:10
            10'h1eb: begin w0<= 123; w1<=-110; w2<=  46; w3<= 115; w4<=  13; w5<=  -9; w6<=  37; w7<=  52; w8<= -68; end // OUT:30 IN:11
            10'h1ec: begin w0<=  35; w1<=  39; w2<=  80; w3<= -99; w4<=-120; w5<= -65; w6<=  32; w7<=  -9; w8<= -77; end // OUT:30 IN:12
            10'h1ed: begin w0<= -40; w1<=  13; w2<=  74; w3<= -76; w4<=  98; w5<= 104; w6<=  58; w7<= -51; w8<=  93; end // OUT:30 IN:13
            10'h1ee: begin w0<= -88; w1<=  67; w2<= 122; w3<= -61; w4<=  91; w5<=-121; w6<=-127; w7<= -24; w8<=  -4; end // OUT:30 IN:14
            10'h1ef: begin w0<= -19; w1<= -43; w2<=  40; w3<=  -9; w4<=  -2; w5<= 126; w6<=  54; w7<=-113; w8<=  92; end // OUT:30 IN:15
            10'h1f0: begin w0<= -67; w1<= -16; w2<=  47; w3<=  29; w4<=-117; w5<= -94; w6<=-118; w7<= -65; w8<= 109; end // OUT:31 IN:0
            10'h1f1: begin w0<= -79; w1<=  84; w2<= 126; w3<=  20; w4<= -60; w5<= -81; w6<=-109; w7<= -28; w8<=  66; end // OUT:31 IN:1
            10'h1f2: begin w0<=  43; w1<=  32; w2<= 116; w3<= 124; w4<=  72; w5<=  60; w6<=   8; w7<= -61; w8<= -94; end // OUT:31 IN:2
            10'h1f3: begin w0<=  80; w1<=  97; w2<=  87; w3<=  95; w4<= -64; w5<=-121; w6<= -84; w7<= -42; w8<=  46; end // OUT:31 IN:3
            10'h1f4: begin w0<=  39; w1<= -53; w2<=  53; w3<= -53; w4<=  45; w5<= -82; w6<=-114; w7<= -24; w8<=  18; end // OUT:31 IN:4
            10'h1f5: begin w0<=-103; w1<= -77; w2<= -36; w3<=  21; w4<= 103; w5<=-108; w6<= -78; w7<= -91; w8<=-109; end // OUT:31 IN:5
            10'h1f6: begin w0<= 120; w1<=  28; w2<=  50; w3<=   3; w4<= -74; w5<=  70; w6<= -37; w7<=-101; w8<=-125; end // OUT:31 IN:6
            10'h1f7: begin w0<=  21; w1<= -53; w2<=  44; w3<= -62; w4<= -43; w5<= 107; w6<=  65; w7<=  87; w8<=  33; end // OUT:31 IN:7
            10'h1f8: begin w0<= -38; w1<=  54; w2<= -24; w3<=-128; w4<= -57; w5<= -42; w6<=  37; w7<=-123; w8<=  85; end // OUT:31 IN:8
            10'h1f9: begin w0<=  24; w1<=  81; w2<=  16; w3<= -68; w4<=-117; w5<=-123; w6<=  89; w7<=-102; w8<=   7; end // OUT:31 IN:9
            10'h1fa: begin w0<=  82; w1<=  -5; w2<= -23; w3<=  64; w4<=  56; w5<= -36; w6<= -20; w7<= 112; w8<= -30; end // OUT:31 IN:10
            10'h1fb: begin w0<=  39; w1<=  13; w2<= -94; w3<=  47; w4<= 108; w5<= -45; w6<= -73; w7<=  48; w8<=  12; end // OUT:31 IN:11
            10'h1fc: begin w0<=  60; w1<= 101; w2<= -80; w3<= -83; w4<= -16; w5<=  61; w6<=   7; w7<= -86; w8<=  19; end // OUT:31 IN:12
            10'h1fd: begin w0<=  -5; w1<= -32; w2<= -39; w3<= -90; w4<= -44; w5<= 116; w6<=  48; w7<=  63; w8<= -67; end // OUT:31 IN:13
            10'h1fe: begin w0<= -23; w1<= -22; w2<= -75; w3<=  -3; w4<= 104; w5<=-120; w6<= -41; w7<= -92; w8<= -80; end // OUT:31 IN:14
            10'h1ff: begin w0<= -88; w1<=-112; w2<= -41; w3<=-108; w4<= -78; w5<= -70; w6<=  38; w7<=  54; w8<= -88; end // OUT:31 IN:15
            default: begin w0 <= 0; w1 <= 0 ; w2 <= 0; w3 <= 0; w4 <= 0; w5 <= 0; w6 <= 0; w7 <= 0; w8 <= 0; end
        endcase
    end

endmodule