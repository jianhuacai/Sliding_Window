`timescale 1ns / 1ps

(* use_dsp = "yes" *) // 模組層級宣告
module conv (
    input          clk,
    input          reset,
    input          start,     

    // 權重：有號數 (-128 ~ 127)
    input  signed [7:0]  w0, w1, w2, w3, w4, w5, w6, w7, w8,
    // 接收來自 Layer 1 的 16-bit 有號數像素
    input        [7:0] p0, p1, p2, p3, p4, p5, p6, p7, p8,

    output reg signed [31:0] result,    
    output reg               done       
);

    // ===== 1. 狀態定義 =====
    localparam IDLE      = 3'd0,
               STG_MUL   = 3'd1, // 執行乘法 
               STG_ADD   = 3'd2, // 加法第一層
               STG_DONE  = 3'd3;

    reg [2:0] state, next_state;
    reg [3:0] counter; 
    reg signed [7:0] w;
    reg [7:0] p;

    // ===== 2. 運算暫存器 (Datapath) =====
    // 🌟 強制這 9 個乘法進入 DSP
    (* use_dsp = "yes" *) reg signed [16:0] m; 
    reg signed [31:0] sum_final;

    // ===== 3. 狀態跳轉 =====
    always @(posedge clk or negedge reset) begin
        if (!reset) state <= IDLE;
        else        state <= next_state;
    end

    // ===== 4. 下一狀態邏輯 =====
    always @(*) begin
        case (state)
            IDLE:      next_state = (start) ? STG_MUL : IDLE;
            STG_MUL:   next_state = STG_ADD;
            STG_ADD:   next_state = (counter == 8) ? STG_DONE : STG_MUL; 
            STG_DONE:  next_state = IDLE;
            default:   next_state = IDLE;
        endcase
    end

    always@(*)begin
      case(counter)
        0: begin w = w0; p = p0; end
        1: begin w = w1; p = p1; end
        2: begin w = w2; p = p2; end
        3: begin w = w3; p = p3; end
        4: begin w = w4; p = p4; end
        5: begin w = w5; p = p5; end
        6: begin w = w6; p = p6; end
        7: begin w = w7; p = p7; end
        8: begin w = w8; p = p8; end
        default: begin w = 8'd0; p = 8'd0; end
      endcase
    end

    always @(posedge clk) begin
        if(!reset) counter <= 0;
        else if (state == IDLE || state == STG_DONE) counter <= 0; // 完成後重置計數器
        else if (state == STG_ADD) counter <= counter + 1; // 非空閒狀態下遞增
    end

    // ===== 5. 運算邏輯 =====
    always @(posedge clk) begin
        
        m <= w * $signed({1'b0, p}); 
        if (!reset) begin
            done   <= 1'b0;
            result <= 32'd0;
            sum_final <= 32'd0;
        end else begin
            case (state)
                IDLE: begin
                    done <= 1'b0;
                    sum_final <= 32'd0;
                end

                STG_MUL: begin
                    
                end

                STG_ADD:begin
                  sum_final <= sum_final + {{15{m[16]}}, m};
                end

                STG_DONE: begin
                    result <= sum_final;
                    done   <= 1'b1;
                end
            endcase
        end
    end
endmodule
/*
paper 圖四PE
*/